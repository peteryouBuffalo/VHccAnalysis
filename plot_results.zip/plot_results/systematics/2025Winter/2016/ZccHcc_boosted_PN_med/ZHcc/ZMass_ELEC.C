#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_ELEC()
{
//=========Macro generated from canvas: c1_n55/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1_n55 = new TCanvas("c1_n55", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n55->SetHighLightColor(2);
   c1_n55->Range(0,0,1,1);
   c1_n55->SetFillColor(0);
   c1_n55->SetBorderMode(0);
   c1_n55->SetBorderSize(2);
   c1_n55->SetLeftMargin(0.15);
   c1_n55->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__464 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__464->Draw();
   pad1_v1__464->cd();
   pad1_v1__464->Range(-37.5,-0.2544976,337.5,2.290479);
   pad1_v1__464->SetFillColor(0);
   pad1_v1__464->SetBorderMode(0);
   pad1_v1__464->SetBorderSize(2);
   pad1_v1__464->SetFrameBorderMode(0);
   pad1_v1__464->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1161 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1161","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1161->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1161->SetMaximum(2.035981);
   ZccHcc_boosted_PN_med_ZMass__1161->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1161->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1161->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1161->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1161->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1161->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1161->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1161->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1161->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1161->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1162 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1162","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(5,0.0002698965);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(7,0.0002695607);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(9,0.02133492);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(10,0.03598096);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(11,0.005279743);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(5,0.0002698965);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(7,0.0002695607);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(9,0.006633221);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(10,0.007925344);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(11,0.002636863);
   ZccHcc_boosted_PN_med_ZMass__1162->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1162->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1162->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1162->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1162->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1162->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1162->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1162->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1162->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1163 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1163","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(5,0.0002678745);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(7,0.0002529386);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(9,0.02105593);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(10,0.03544701);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(11,0.005190555);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(5,0.0002678745);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(7,0.0002529386);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(9,0.00656178);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(10,0.007815736);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(11,0.002582018);
   ZccHcc_boosted_PN_med_ZMass__1163->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1163->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1163->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1163->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1163->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1163->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1163->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1163->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1163->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","ELEC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","ELEC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__464->Modified();
   c1_n55->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__465 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__465->Draw();
   pad1_v2__465->cd();
   pad1_v2__465->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__465->SetFillColor(0);
   pad1_v2__465->SetBorderMode(0);
   pad1_v2__465->SetBorderSize(2);
   pad1_v2__465->SetFrameBorderMode(0);
   pad1_v2__465->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1164 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1164","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(5,1.00376);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(7,1.032065);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(9,1.006597);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(10,1.007514);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(11,1.008518);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(5,1.419531);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(7,1.45956);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(8,0.8257816);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(9,0.4428425);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(10,0.3139146);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(11,0.7116089);
   ZccHcc_boosted_PN_med_ZMass__1164->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__1164->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1164->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1164->SetEntries(7.514656);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1164->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1164->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1164->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1164->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1164->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1164->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1165 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1165","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(5,0.9962401);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(7,0.9684241);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(9,0.9934346);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(10,0.9925627);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(11,0.9914818);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(5,1.408896);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(7,1.369559);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(8,0.8257816);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(9,0.437562);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(10,0.3094146);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(11,0.6981965);
   ZccHcc_boosted_PN_med_ZMass__1165->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__1165->SetEntries(7.626882);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1165->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1165->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1165->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1165->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1165->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__465->Modified();
   c1_n55->cd();
   c1_n55->Modified();
   c1_n55->SetSelected(c1_n55);
}
