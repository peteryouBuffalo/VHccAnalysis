#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_ELEC()
{
//=========Macro generated from canvas: c1_n23/
//=========  (Fri Feb 28 11:35:55 2025) by ROOT version 6.30/03
   TCanvas *c1_n23 = new TCanvas("c1_n23", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n23->SetHighLightColor(2);
   c1_n23->Range(0,0,1,1);
   c1_n23->SetFillColor(0);
   c1_n23->SetBorderMode(0);
   c1_n23->SetBorderSize(2);
   c1_n23->SetLeftMargin(0.15);
   c1_n23->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__400 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__400->Draw();
   pad1_v1__400->cd();
   pad1_v1__400->Range(-37.5,-0.2534061,337.5,2.280655);
   pad1_v1__400->SetFillColor(0);
   pad1_v1__400->SetBorderMode(0);
   pad1_v1__400->SetBorderSize(2);
   pad1_v1__400->SetFrameBorderMode(0);
   pad1_v1__400->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1001 = new TH1D("ZccHcc_boosted_PN_med_HMass__1001","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1001->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1001->SetMaximum(2.027249);
   ZccHcc_boosted_PN_med_HMass__1001->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__1001->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__1001->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1001->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1001->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1001->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__1001->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__1001->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1001->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1001->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1002 = new TH1D("ZccHcc_boosted_PN_med_HMass__1002","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(9,0.0005166571);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(11,0.0002596097);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(12,0.01449772);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(13,0.02724893);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(14,0.02218507);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(15,0.00238723);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinContent(17,0.001550427);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(9,0.0003656769);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(11,0.0002596097);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(12,0.005160504);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(13,0.007295788);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(14,0.006176267);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(15,0.001916091);
   ZccHcc_boosted_PN_med_HMass__1002->SetBinError(17,0.001550427);
   ZccHcc_boosted_PN_med_HMass__1002->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1002->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1002->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1002->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1002->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1002->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1002->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1002->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1003 = new TH1D("ZccHcc_boosted_PN_med_HMass__1003","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(9,0.0004962846);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(11,0.0002397013);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(12,0.01446453);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(13,0.02690226);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(14,0.02175088);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(15,0.002357464);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinContent(17,0.001513757);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(9,0.0003509917);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(11,0.0002397013);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(12,0.005149658);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(13,0.007215209);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(14,0.006058351);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(15,0.00188786);
   ZccHcc_boosted_PN_med_HMass__1003->SetBinError(17,0.001513757);
   ZccHcc_boosted_PN_med_HMass__1003->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1003->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1003->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1003->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1003->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1003->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1003->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1003->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","ELEC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","ELEC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__400->Modified();
   c1_n23->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__401 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__401->Draw();
   pad1_v2__401->cd();
   pad1_v2__401->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__401->SetFillColor(0);
   pad1_v2__401->SetBorderMode(0);
   pad1_v2__401->SetBorderSize(2);
   pad1_v2__401->SetFrameBorderMode(0);
   pad1_v2__401->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1004 = new TH1D("ZccHcc_boosted_PN_med_HMass__1004","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(9,1.020241);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(11,1.040327);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(12,1.001148);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(13,1.006404);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(14,1.009953);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(15,1.006274);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinContent(17,1.011968);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(9,1.020976);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(10,1.000153);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(11,1.471245);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(12,0.5039936);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(13,0.3812331);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(14,0.3976605);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(15,1.141577);
   ZccHcc_boosted_PN_med_HMass__1004->SetBinError(17,1.431138);
   ZccHcc_boosted_PN_med_HMass__1004->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__1004->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__1004->SetEntries(8.076576);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1004->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1004->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1004->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__1004->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1004->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1004->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1005 = new TH1D("ZccHcc_boosted_PN_med_HMass__1005","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(9,0.9800114);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(11,0.9605489);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(12,0.9988562);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(13,0.9935998);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(14,0.9901862);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(15,0.9937264);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinContent(17,0.9880325);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(9,0.9803463);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(10,1.000153);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(11,1.358421);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(12,0.5028871);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(13,0.3767026);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(14,0.3899731);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(15,1.12605);
   ZccHcc_boosted_PN_med_HMass__1005->SetBinError(17,1.397289);
   ZccHcc_boosted_PN_med_HMass__1005->SetEntries(8.250409);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1005->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1005->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1005->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1005->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1005->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__401->Modified();
   c1_n23->cd();
   c1_n23->Modified();
   c1_n23->SetSelected(c1_n23);
}
