#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_L1PREFIRING()
{
//=========Macro generated from canvas: c1_n31/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n31 = new TCanvas("c1_n31", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n31->SetHighLightColor(2);
   c1_n31->Range(0,0,1,1);
   c1_n31->SetFillColor(0);
   c1_n31->SetBorderMode(0);
   c1_n31->SetBorderSize(2);
   c1_n31->SetLeftMargin(0.15);
   c1_n31->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__416 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__416->Draw();
   pad1_v1__416->cd();
   pad1_v1__416->Range(-37.5,-0.2533888,337.5,2.280499);
   pad1_v1__416->SetFillColor(0);
   pad1_v1__416->SetBorderMode(0);
   pad1_v1__416->SetBorderSize(2);
   pad1_v1__416->SetFrameBorderMode(0);
   pad1_v1__416->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1041 = new TH1D("ZccHcc_boosted_PN_med_HMass__1041","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1041->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1041->SetMaximum(2.027111);
   ZccHcc_boosted_PN_med_HMass__1041->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__1041->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__1041->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1041->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1041->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1041->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__1041->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__1041->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1041->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1041->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1042 = new TH1D("ZccHcc_boosted_PN_med_HMass__1042","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(9,0.0005059704);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(10,0.003729266);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(12,0.01446335);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(13,0.02703818);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(14,0.02190866);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(15,0.002371627);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinContent(17,0.001524756);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(9,0.0003579435);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(10,0.002637325);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(12,0.005149463);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(13,0.007250501);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(14,0.006103124);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(15,0.001901886);
   ZccHcc_boosted_PN_med_HMass__1042->SetBinError(17,0.001524756);
   ZccHcc_boosted_PN_med_HMass__1042->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1042->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1042->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1042->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1042->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1042->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1042->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1042->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1043 = new TH1D("ZccHcc_boosted_PN_med_HMass__1043","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(9,0.0005064128);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(10,0.003741044);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(12,0.01449344);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(13,0.02711058);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(14,0.02201934);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(15,0.002373067);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinContent(17,0.001539428);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(9,0.0003582659);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(10,0.002645798);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(12,0.005158958);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(13,0.007259773);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(14,0.006128475);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(15,0.001902062);
   ZccHcc_boosted_PN_med_HMass__1043->SetBinError(17,0.001539428);
   ZccHcc_boosted_PN_med_HMass__1043->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1043->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1043->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1043->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1043->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1043->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1043->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1043->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","L1PREFIRING Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","L1PREFIRING Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__416->Modified();
   c1_n31->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__417 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__417->Draw();
   pad1_v2__417->cd();
   pad1_v2__417->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__417->SetFillColor(0);
   pad1_v2__417->SetBorderMode(0);
   pad1_v2__417->SetBorderSize(2);
   pad1_v2__417->SetFrameBorderMode(0);
   pad1_v2__417->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1044 = new TH1D("ZccHcc_boosted_PN_med_HMass__1044","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(9,0.999138);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(10,0.9984234);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(12,0.9987747);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(13,0.9986201);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(14,0.9973691);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(15,0.9996966);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinContent(17,0.9952116);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(9,0.9996213);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(10,0.9985635);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(11,1.414214);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(12,0.5028571);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(13,0.3785755);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(14,0.3928285);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(15,1.133615);
   ZccHcc_boosted_PN_med_HMass__1044->SetBinError(17,1.407442);
   ZccHcc_boosted_PN_med_HMass__1044->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__1044->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__1044->SetEntries(8.165514);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1044->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1044->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1044->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__1044->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1044->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1044->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1045 = new TH1D("ZccHcc_boosted_PN_med_HMass__1045","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(9,1.000012);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(10,1.001577);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(12,1.000852);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(13,1.001294);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(14,1.002408);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(15,1.000303);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinContent(17,1.004788);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(9,1.000509);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(10,1.001744);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(11,1.414214);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(12,0.5038437);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(13,0.3793243);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(14,0.3946366);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(15,1.134011);
   ZccHcc_boosted_PN_med_HMass__1045->SetBinError(17,1.420985);
   ZccHcc_boosted_PN_med_HMass__1045->SetEntries(8.162083);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1045->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1045->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1045->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1045->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1045->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__417->Modified();
   c1_n31->cd();
   c1_n31->Modified();
   c1_n31->SetSelected(c1_n31);
}
