#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n47/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n47 = new TCanvas("c1_n47", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n47->SetHighLightColor(2);
   c1_n47->Range(0,0,1,1);
   c1_n47->SetFillColor(0);
   c1_n47->SetBorderMode(0);
   c1_n47->SetBorderSize(2);
   c1_n47->SetLeftMargin(0.15);
   c1_n47->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__448 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__448->Draw();
   pad1_v1__448->cd();
   pad1_v1__448->Range(-37.5,-0.2544913,337.5,2.290421);
   pad1_v1__448->SetFillColor(0);
   pad1_v1__448->SetBorderMode(0);
   pad1_v1__448->SetBorderSize(2);
   pad1_v1__448->SetFrameBorderMode(0);
   pad1_v1__448->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1121 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1121","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1121->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1121->SetMaximum(2.03593);
   ZccHcc_boosted_PN_med_ZMass__1121->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1121->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1121->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1121->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1121->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1121->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1121->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1121->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1121->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1121->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1122 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1122","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(9,0.02319289);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(10,0.03592988);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(11,0.007487668);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinContent(12,0.005455931);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(9,0.006888652);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(10,0.007813878);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(11,0.003288325);
   ZccHcc_boosted_PN_med_ZMass__1122->SetBinError(12,0.003163073);
   ZccHcc_boosted_PN_med_ZMass__1122->SetEntries(60);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1122->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1122->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1122->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1122->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1122->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1122->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1122->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1123 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1123","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(8,0.00744388);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(9,0.01911474);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(10,0.03390451);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(11,0.004971631);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(8,0.003659092);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(9,0.006247654);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(10,0.007715503);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(11,0.002596048);
   ZccHcc_boosted_PN_med_ZMass__1123->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1123->SetEntries(52);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1123->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1123->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1123->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1123->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1123->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1123->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1123->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__448->Modified();
   c1_n47->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__449 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__449->Draw();
   pad1_v2__449->cd();
   pad1_v2__449->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__449->SetFillColor(0);
   pad1_v2__449->SetBorderMode(0);
   pad1_v2__449->SetBorderSize(2);
   pad1_v2__449->SetFrameBorderMode(0);
   pad1_v2__449->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1124 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1124","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(9,1.094258);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(10,1.006084);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(11,1.430268);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinContent(12,1.415519);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(8,0.8257816);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(9,0.4707866);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(10,0.3114915);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(11,0.9501385);
   ZccHcc_boosted_PN_med_ZMass__1124->SetBinError(12,1.29496);
   ZccHcc_boosted_PN_med_ZMass__1124->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1124->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1124->SetEntries(8.32965);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1124->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1124->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1124->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1124->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1124->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1124->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1125 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1125","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(8,1.380707);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(9,0.9018478);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(10,0.9493707);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(11,0.9496637);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(8,1.053856);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(9,0.4070459);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(10,0.3007386);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(11,0.6855378);
   ZccHcc_boosted_PN_med_ZMass__1125->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__1125->SetEntries(7.542095);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1125->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1125->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1125->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1125->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1125->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__449->Modified();
   c1_n47->cd();
   c1_n47->Modified();
   c1_n47->SetSelected(c1_n47);
}
