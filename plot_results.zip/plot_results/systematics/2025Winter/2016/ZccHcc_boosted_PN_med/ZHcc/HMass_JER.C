#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JER()
{
//=========Macro generated from canvas: c1_n43/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n43 = new TCanvas("c1_n43", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n43->SetHighLightColor(2);
   c1_n43->Range(0,0,1,1);
   c1_n43->SetFillColor(0);
   c1_n43->SetBorderMode(0);
   c1_n43->SetBorderSize(2);
   c1_n43->SetLeftMargin(0.15);
   c1_n43->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__440 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__440->Draw();
   pad1_v1__440->cd();
   pad1_v1__440->Range(-37.5,-0.253418,337.5,2.280762);
   pad1_v1__440->SetFillColor(0);
   pad1_v1__440->SetBorderMode(0);
   pad1_v1__440->SetBorderSize(2);
   pad1_v1__440->SetFrameBorderMode(0);
   pad1_v1__440->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1101 = new TH1D("ZccHcc_boosted_PN_med_HMass__1101","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1101->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1101->SetMaximum(2.027344);
   ZccHcc_boosted_PN_med_HMass__1101->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__1101->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__1101->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1101->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1101->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1101->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__1101->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__1101->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1101->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1101->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1102 = new TH1D("ZccHcc_boosted_PN_med_HMass__1102","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(13,0.02734367);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(13,0.007260213);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1102->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1102->SetEntries(55);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1102->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1102->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1102->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1102->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1102->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1102->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1102->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1103 = new TH1D("ZccHcc_boosted_PN_med_HMass__1103","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(10,0.005522001);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(13,0.02681203);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(14,0.02219882);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(15,0.002139975);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(10,0.003189146);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(13,0.007250608);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(14,0.006120696);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(15,0.001887726);
   ZccHcc_boosted_PN_med_HMass__1103->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1103->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1103->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1103->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1103->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1103->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1103->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1103->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1103->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JER Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JER Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__440->Modified();
   c1_n43->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__441 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__441->Draw();
   pad1_v2__441->cd();
   pad1_v2__441->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__441->SetFillColor(0);
   pad1_v2__441->SetBorderMode(0);
   pad1_v2__441->SetBorderSize(2);
   pad1_v2__441->SetFrameBorderMode(0);
   pad1_v2__441->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1104 = new TH1D("ZccHcc_boosted_PN_med_HMass__1104","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(13,1.009903);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(14,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(15,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(10,1.000153);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(11,1.414214);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(12,0.5034382);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(13,0.380971);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(14,0.3937701);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(15,1.133813);
   ZccHcc_boosted_PN_med_HMass__1104->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__1104->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__1104->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__1104->SetEntries(8.18299);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1104->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1104->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1104->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__1104->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1104->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1104->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1105 = new TH1D("ZccHcc_boosted_PN_med_HMass__1105","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(10,1.478386);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(13,0.9902673);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(14,1.010579);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(15,0.9020497);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(10,1.349872);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(11,1.414214);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(12,0.5034382);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(13,0.3769995);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(14,0.3959997);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(15,1.075261);
   ZccHcc_boosted_PN_med_HMass__1105->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__1105->SetEntries(8.233487);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1105->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1105->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1105->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1105->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1105->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__441->Modified();
   c1_n43->cd();
   c1_n43->Modified();
   c1_n43->SetSelected(c1_n43);
}
