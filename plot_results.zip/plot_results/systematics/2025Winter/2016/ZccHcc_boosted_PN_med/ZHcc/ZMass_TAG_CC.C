#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_TAG_CC()
{
//=========Macro generated from canvas: c1_n9/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1_n9 = new TCanvas("c1_n9", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n9->SetHighLightColor(2);
   c1_n9->Range(0,0,1,1);
   c1_n9->SetFillColor(0);
   c1_n9->SetBorderMode(0);
   c1_n9->SetBorderSize(2);
   c1_n9->SetLeftMargin(0.15);
   c1_n9->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__488 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__488->Draw();
   pad1_v1__488->cd();
   pad1_v1__488->Range(-37.5,-0.2564048,337.5,2.307643);
   pad1_v1__488->SetFillColor(0);
   pad1_v1__488->SetBorderMode(0);
   pad1_v1__488->SetBorderSize(2);
   pad1_v1__488->SetFrameBorderMode(0);
   pad1_v1__488->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1221 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1221","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1221->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1221->SetMaximum(2.051239);
   ZccHcc_boosted_PN_med_ZMass__1221->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1221->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1221->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1221->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1221->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1221->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1221->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1221->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1221->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1221->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1222 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1222","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(5,0.0004034256);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(7,0.0003400545);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(8,0.007383809);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(9,0.02972517);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(10,0.05123857);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(11,0.007205933);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinContent(12,0.00567929);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(5,0.0004034256);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(7,0.0003400545);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(8,0.004321529);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(9,0.009369387);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(10,0.01133681);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(11,0.003590083);
   ZccHcc_boosted_PN_med_ZMass__1222->SetBinError(12,0.004022872);
   ZccHcc_boosted_PN_med_ZMass__1222->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1222->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1222->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1222->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1222->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1222->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1222->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1222->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1223 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1223","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(5,0.0001509885);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(7,0.0001859067);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(8,0.003561456);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(9,0.01372103);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(10,0.02240655);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(11,0.003583793);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinContent(12,0.002280552);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(5,0.0001509885);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(7,0.0001859067);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(8,0.002091741);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(9,0.004196609);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(10,0.004930031);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(11,0.001793677);
   ZccHcc_boosted_PN_med_ZMass__1223->SetBinError(12,0.001612727);
   ZccHcc_boosted_PN_med_ZMass__1223->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1223->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1223->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1223->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1223->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1223->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1223->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1223->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","TAG_CC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","TAG_CC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__488->Modified();
   c1_n9->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__489 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__489->Draw();
   pad1_v2__489->cd();
   pad1_v2__489->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__489->SetFillColor(0);
   pad1_v2__489->SetBorderMode(0);
   pad1_v2__489->SetBorderSize(2);
   pad1_v2__489->SetFrameBorderMode(0);
   pad1_v2__489->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1224 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1224","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(5,1.500362);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(7,1.301964);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(8,1.369565);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(9,1.402456);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(10,1.434747);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(11,1.376452);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinContent(12,1.473469);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(5,2.121832);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(7,1.841256);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(8,1.132274);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(9,0.6212642);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(10,0.4480348);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(11,0.9700366);
   ZccHcc_boosted_PN_med_ZMass__1224->SetBinError(12,1.475348);
   ZccHcc_boosted_PN_med_ZMass__1224->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1224->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1224->SetEntries(7.547321);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1224->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1224->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1224->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1224->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1224->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1224->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1225 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1225","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(5,0.5615347);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(7,0.7117796);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(8,0.6605865);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(9,0.6473686);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(10,0.6274126);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(11,0.6845637);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinContent(12,0.59168);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(5,0.7941301);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(7,1.006608);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(8,0.5470961);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(9,0.2824993);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(10,0.1953793);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(11,0.4835442);
   ZccHcc_boosted_PN_med_ZMass__1225->SetBinError(12,0.5919425);
   ZccHcc_boosted_PN_med_ZMass__1225->SetEntries(7.603578);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1225->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1225->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1225->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1225->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1225->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__489->Modified();
   c1_n9->cd();
   c1_n9->Modified();
   c1_n9->SetSelected(c1_n9);
}
