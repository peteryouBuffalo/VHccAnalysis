#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n15/
//=========  (Fri Feb 28 11:35:55 2025) by ROOT version 6.30/03
   TCanvas *c1_n15 = new TCanvas("c1_n15", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n15->SetHighLightColor(2);
   c1_n15->Range(0,0,1,1);
   c1_n15->SetFillColor(0);
   c1_n15->SetBorderMode(0);
   c1_n15->SetBorderSize(2);
   c1_n15->SetLeftMargin(0.15);
   c1_n15->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__384 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__384->Draw();
   pad1_v1__384->cd();
   pad1_v1__384->Range(-37.5,-0.2533845,337.5,2.28046);
   pad1_v1__384->SetFillColor(0);
   pad1_v1__384->SetBorderMode(0);
   pad1_v1__384->SetBorderSize(2);
   pad1_v1__384->SetFrameBorderMode(0);
   pad1_v1__384->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__961 = new TH1D("ZccHcc_boosted_PN_med_HMass__961","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__961->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__961->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__961->SetMaximum(2.027076);
   ZccHcc_boosted_PN_med_HMass__961->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__961->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__961->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__961->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__961->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__961->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__961->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__961->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__961->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__961->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__961->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__961->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__961->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__961->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__961->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__962 = new TH1D("ZccHcc_boosted_PN_med_HMass__962","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(10,0.003621721);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(11,0.002149826);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(12,0.01806553);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(13,0.02587841);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(14,0.02362177);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__962->SetBinContent(17,0.001771777);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(10,0.002561169);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(11,0.001916596);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(12,0.005669841);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(13,0.007120372);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(14,0.006336326);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__962->SetBinError(17,0.001550727);
   ZccHcc_boosted_PN_med_HMass__962->SetEntries(60);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__962->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__962->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__962->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__962->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__962->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__962->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__962->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__962->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__962->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__962->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__962->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__962->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__963 = new TH1D("ZccHcc_boosted_PN_med_HMass__963","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(11,0.0002260255);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(12,0.01580885);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(13,0.02505867);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(14,0.02268006);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(15,0.0002719388);
   ZccHcc_boosted_PN_med_HMass__963->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(11,0.0002260255);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(12,0.005308629);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(13,0.007032761);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(14,0.006249107);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(15,0.0002719388);
   ZccHcc_boosted_PN_med_HMass__963->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__963->SetEntries(52);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__963->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__963->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__963->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__963->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__963->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__963->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__963->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__963->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__963->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__963->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__963->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__963->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__384->Modified();
   c1_n15->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__385 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__385->Draw();
   pad1_v2__385->cd();
   pad1_v2__385->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__385->SetFillColor(0);
   pad1_v2__385->SetBorderMode(0);
   pad1_v2__385->SetBorderSize(2);
   pad1_v2__385->SetFrameBorderMode(0);
   pad1_v2__385->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__964 = new TH1D("ZccHcc_boosted_PN_med_HMass__964","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(10,0.9696307);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(11,8.614945);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(12,1.247525);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(13,0.9557854);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(14,1.075357);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(15,1);
   ZccHcc_boosted_PN_med_HMass__964->SetBinContent(17,1.156443);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(10,0.9697477);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(11,11.54143);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(12,0.59205);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(13,0.3670927);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(14,0.4157623);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(15,1.133813);
   ZccHcc_boosted_PN_med_HMass__964->SetBinError(17,1.536826);
   ZccHcc_boosted_PN_med_HMass__964->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__964->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__964->SetEntries(1.840283);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__964->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__964->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__964->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__964->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__964->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__964->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__964->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__964->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__965 = new TH1D("ZccHcc_boosted_PN_med_HMass__965","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(11,0.9057462);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(12,1.091689);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(13,0.9255094);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(14,1.032486);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(15,0.1146286);
   ZccHcc_boosted_PN_med_HMass__965->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(10,1.000153);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(11,1.280919);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(12,0.5342446);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(13,0.3591317);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(14,0.4044474);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(15,0.14692);
   ZccHcc_boosted_PN_med_HMass__965->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__965->SetEntries(8.00847);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__965->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__965->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__965->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__965->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__965->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__965->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__965->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__965->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__965->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__385->Modified();
   c1_n15->cd();
   c1_n15->Modified();
   c1_n15->SetSelected(c1_n15);
}
