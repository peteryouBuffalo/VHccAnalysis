#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_TRIG()
{
//=========Macro generated from canvas: c1_n39/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n39 = new TCanvas("c1_n39", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n39->SetHighLightColor(2);
   c1_n39->Range(0,0,1,1);
   c1_n39->SetFillColor(0);
   c1_n39->SetBorderMode(0);
   c1_n39->SetBorderSize(2);
   c1_n39->SetLeftMargin(0.15);
   c1_n39->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__432 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__432->Draw();
   pad1_v1__432->cd();
   pad1_v1__432->Range(-37.5,-0.2536042,337.5,2.282438);
   pad1_v1__432->SetFillColor(0);
   pad1_v1__432->SetBorderMode(0);
   pad1_v1__432->SetBorderSize(2);
   pad1_v1__432->SetFrameBorderMode(0);
   pad1_v1__432->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1081 = new TH1D("ZccHcc_boosted_PN_med_HMass__1081","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1081->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1081->SetMaximum(2.028833);
   ZccHcc_boosted_PN_med_HMass__1081->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__1081->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__1081->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1081->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1081->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1081->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__1081->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__1081->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1081->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1081->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1082 = new TH1D("ZccHcc_boosted_PN_med_HMass__1082","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(9,0.000530988);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(10,0.003949497);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(11,0.0002668577);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(12,0.0153032);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(13,0.02883337);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(14,0.02377098);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(15,0.002594691);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinContent(17,0.001602278);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(9,0.0003754935);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(10,0.002792773);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(11,0.0002668577);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(12,0.005441584);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(13,0.00781958);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(14,0.006632199);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(15,0.002104741);
   ZccHcc_boosted_PN_med_HMass__1082->SetBinError(17,0.001602278);
   ZccHcc_boosted_PN_med_HMass__1082->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1082->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1082->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1082->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1082->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1082->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1082->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1082->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1083 = new TH1D("ZccHcc_boosted_PN_med_HMass__1083","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(9,0.0004818259);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(10,0.003520813);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(11,0.0002322347);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(12,0.013659);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(13,0.02531773);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(14,0.02016192);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(15,0.002150003);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinContent(17,0.001461906);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(9,0.0003411757);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(10,0.002490711);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(11,0.0002322347);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(12,0.004873904);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(13,0.006703466);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(14,0.005606654);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(15,0.001699562);
   ZccHcc_boosted_PN_med_HMass__1083->SetBinError(17,0.001461906);
   ZccHcc_boosted_PN_med_HMass__1083->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1083->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1083->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1083->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1083->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1083->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1083->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1083->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","TRIG Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","TRIG Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__432->Modified();
   c1_n39->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__433 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__433->Draw();
   pad1_v2__433->cd();
   pad1_v2__433->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__433->SetFillColor(0);
   pad1_v2__433->SetBorderMode(0);
   pad1_v2__433->SetBorderSize(2);
   pad1_v2__433->SetFrameBorderMode(0);
   pad1_v2__433->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1084 = new TH1D("ZccHcc_boosted_PN_med_HMass__1084","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(9,1.04854);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(10,1.057385);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(11,1.069372);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(12,1.05677);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(13,1.064923);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(14,1.082149);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(15,1.093723);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinContent(17,1.04581);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(9,1.04884);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(10,1.057477);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(11,1.51232);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(12,0.53172);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(13,0.4060081);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(14,0.4265518);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(15,1.247404);
   ZccHcc_boosted_PN_med_HMass__1084->SetBinError(17,1.478999);
   ZccHcc_boosted_PN_med_HMass__1084->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__1084->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__1084->SetEntries(8.173516);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1084->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1084->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1084->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__1084->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1084->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1084->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1085 = new TH1D("ZccHcc_boosted_PN_med_HMass__1085","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(9,0.9514599);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(10,0.9426151);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(11,0.930628);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(12,0.9432295);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(13,0.9350772);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(14,0.9178508);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(15,0.9062767);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinContent(17,0.9541895);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(9,0.9523573);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(10,0.9428994);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(11,1.316107);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(12,0.4754202);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(13,0.3522552);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(14,0.3611911);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(15,1.020375);
   ZccHcc_boosted_PN_med_HMass__1085->SetBinError(17,1.349428);
   ZccHcc_boosted_PN_med_HMass__1085->SetEntries(8.146024);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1085->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1085->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1085->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1085->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1085->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__433->Modified();
   c1_n39->cd();
   c1_n39->Modified();
   c1_n39->SetSelected(c1_n39);
}
