#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_MUON()
{
//=========Macro generated from canvas: c1_n59/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1_n59 = new TCanvas("c1_n59", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n59->SetHighLightColor(2);
   c1_n59->Range(0,0,1,1);
   c1_n59->SetFillColor(0);
   c1_n59->SetBorderMode(0);
   c1_n59->SetBorderSize(2);
   c1_n59->SetLeftMargin(0.15);
   c1_n59->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__472 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__472->Draw();
   pad1_v1__472->cd();
   pad1_v1__472->Range(-37.5,-0.2544679,337.5,2.290211);
   pad1_v1__472->SetFillColor(0);
   pad1_v1__472->SetBorderMode(0);
   pad1_v1__472->SetBorderSize(2);
   pad1_v1__472->SetFrameBorderMode(0);
   pad1_v1__472->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1181 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1181","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1181->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1181->SetMaximum(2.035743);
   ZccHcc_boosted_PN_med_ZMass__1181->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1181->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1181->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1181->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1181->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1181->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1181->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1181->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1181->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1181->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1182 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1182","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(7,0.0002612603);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(8,0.005401568);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(9,0.02121647);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(10,0.03574299);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(11,0.005236376);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinContent(12,0.00385812);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(7,0.0002612603);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(8,0.003154601);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(9,0.006605922);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(10,0.007876671);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(11,0.002610167);
   ZccHcc_boosted_PN_med_ZMass__1182->SetBinError(12,0.002730401);
   ZccHcc_boosted_PN_med_ZMass__1182->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1182->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1182->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1182->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1182->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1182->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1182->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1182->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1183 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1183","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(7,0.0002611111);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(8,0.005381159);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(9,0.02117377);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(10,0.03568231);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(11,0.005233922);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinContent(12,0.003850618);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(7,0.0002611111);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(8,0.003141609);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(9,0.006588487);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(10,0.007863084);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(11,0.00260861);
   ZccHcc_boosted_PN_med_ZMass__1183->SetBinError(12,0.002724887);
   ZccHcc_boosted_PN_med_ZMass__1183->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1183->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1183->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1183->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1183->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1183->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1183->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1183->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","MUON Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","MUON Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__472->Modified();
   c1_n59->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__473 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__473->Draw();
   pad1_v2__473->cd();
   pad1_v2__473->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__473->SetFillColor(0);
   pad1_v2__473->SetBorderMode(0);
   pad1_v2__473->SetBorderSize(2);
   pad1_v2__473->SetFrameBorderMode(0);
   pad1_v2__473->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1184 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1184","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(7,1.000286);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(8,1.001894);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(9,1.001009);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(10,1.00085);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(11,1.000234);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinContent(12,1.000974);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(7,1.414618);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(8,0.8274168);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(9,0.4407017);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(10,0.3119125);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(11,0.7050831);
   ZccHcc_boosted_PN_med_ZMass__1184->SetBinError(12,1.001798);
   ZccHcc_boosted_PN_med_ZMass__1184->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1184->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1184->SetEntries(7.575397);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1184->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1184->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1184->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1184->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1184->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1184->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1185 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1185","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(7,0.9997144);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(8,0.9981089);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(9,0.9989943);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(10,0.9991514);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(11,0.9997656);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinContent(12,0.9990274);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(7,1.41381);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(8,0.8241498);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(9,0.4396766);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(10,0.3113788);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(11,0.7047076);
   ZccHcc_boosted_PN_med_ZMass__1185->SetBinError(12,0.9998126);
   ZccHcc_boosted_PN_med_ZMass__1185->SetEntries(7.568414);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1185->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1185->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1185->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1185->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1185->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__473->Modified();
   c1_n59->cd();
   c1_n59->Modified();
   c1_n59->SetSelected(c1_n59);
}
