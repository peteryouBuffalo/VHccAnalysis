#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_PU()
{
//=========Macro generated from canvas: c1_n51/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n51 = new TCanvas("c1_n51", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n51->SetHighLightColor(2);
   c1_n51->Range(0,0,1,1);
   c1_n51->SetFillColor(0);
   c1_n51->SetBorderMode(0);
   c1_n51->SetBorderSize(2);
   c1_n51->SetLeftMargin(0.15);
   c1_n51->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__456 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__456->Draw();
   pad1_v1__456->cd();
   pad1_v1__456->Range(-37.5,-0.2545623,337.5,2.291061);
   pad1_v1__456->SetFillColor(0);
   pad1_v1__456->SetBorderMode(0);
   pad1_v1__456->SetBorderSize(2);
   pad1_v1__456->SetFrameBorderMode(0);
   pad1_v1__456->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1141 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1141","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1141->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1141->SetMaximum(2.036499);
   ZccHcc_boosted_PN_med_ZMass__1141->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1141->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1141->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1141->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1141->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1141->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1141->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1141->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1141->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1141->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1142 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1142","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(5,0.0002287281);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(7,0.0002075863);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(8,0.005526049);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(9,0.0196624);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(10,0.03470465);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(11,0.006654127);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinContent(12,0.003265754);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(5,0.0002287281);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(7,0.0002075863);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(8,0.00319495);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(9,0.005909987);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(10,0.007712808);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(11,0.003158789);
   ZccHcc_boosted_PN_med_ZMass__1142->SetBinError(12,0.002327448);
   ZccHcc_boosted_PN_med_ZMass__1142->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1142->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1142->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1142->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1142->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1142->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1142->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1142->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1143 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1143","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(5,0.0003071137);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(7,0.0003267536);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(8,0.005290539);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(9,0.02292496);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(10,0.03649852);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(11,0.004065108);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinContent(12,0.004526291);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(5,0.0003071137);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(7,0.0003267536);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(8,0.003244987);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(9,0.007641682);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(10,0.008106956);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(11,0.002244751);
   ZccHcc_boosted_PN_med_ZMass__1143->SetBinError(12,0.003204335);
   ZccHcc_boosted_PN_med_ZMass__1143->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1143->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1143->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1143->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1143->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1143->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1143->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1143->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__456->Modified();
   c1_n51->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__457 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__457->Draw();
   pad1_v2__457->cd();
   pad1_v2__457->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__457->SetFillColor(0);
   pad1_v2__457->SetBorderMode(0);
   pad1_v2__457->SetBorderSize(2);
   pad1_v2__457->SetFrameBorderMode(0);
   pad1_v2__457->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1144 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1144","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(5,0.8506526);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(7,0.7947844);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(8,1.024983);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(9,0.9276867);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(10,0.9717756);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(11,1.271048);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinContent(12,0.8472869);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(5,1.203005);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(7,1.123995);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(8,0.8422523);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(9,0.4014075);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(10,0.3041403);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(11,0.8748926);
   ZccHcc_boosted_PN_med_ZMass__1144->SetBinError(12,0.8509739);
   ZccHcc_boosted_PN_med_ZMass__1144->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1144->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1144->SetEntries(8.663676);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1144->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1144->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1144->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1144->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1144->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1144->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1145 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1145","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(5,1.142173);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(7,1.251039);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(8,0.9813005);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(9,1.081617);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(10,1.022006);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(11,0.7765028);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinContent(12,1.174328);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(5,1.615276);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(7,1.769237);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(8,0.8310196);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(9,0.4932868);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(10,0.3197712);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(11,0.5776278);
   ZccHcc_boosted_PN_med_ZMass__1145->SetBinError(12,1.175491);
   ZccHcc_boosted_PN_med_ZMass__1145->SetEntries(6.499825);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1145->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1145->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1145->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1145->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1145->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__457->Modified();
   c1_n51->cd();
   c1_n51->Modified();
   c1_n51->SetSelected(c1_n51);
}
