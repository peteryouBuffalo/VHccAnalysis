#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_MUON()
{
//=========Macro generated from canvas: c1_n27/
//=========  (Fri Feb 28 11:35:56 2025) by ROOT version 6.30/03
   TCanvas *c1_n27 = new TCanvas("c1_n27", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n27->SetHighLightColor(2);
   c1_n27->Range(0,0,1,1);
   c1_n27->SetFillColor(0);
   c1_n27->SetBorderMode(0);
   c1_n27->SetBorderSize(2);
   c1_n27->SetLeftMargin(0.15);
   c1_n27->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__408 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__408->Draw();
   pad1_v1__408->cd();
   pad1_v1__408->Range(-37.5,-0.2533866,337.5,2.280479);
   pad1_v1__408->SetFillColor(0);
   pad1_v1__408->SetBorderMode(0);
   pad1_v1__408->SetBorderSize(2);
   pad1_v1__408->SetFrameBorderMode(0);
   pad1_v1__408->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1021 = new TH1D("ZccHcc_boosted_PN_med_HMass__1021","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__1021->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1021->SetMaximum(2.027092);
   ZccHcc_boosted_PN_med_HMass__1021->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__1021->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__1021->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1021->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1021->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1021->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__1021->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__1021->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1021->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1021->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1022 = new TH1D("ZccHcc_boosted_PN_med_HMass__1022","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(9,0.0005073299);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(10,0.003746252);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(11,0.0002499333);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(12,0.01450579);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(13,0.02709245);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(14,0.02197155);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(15,0.002380279);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(9,0.0003588972);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(10,0.002649347);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(11,0.0002499333);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(12,0.005163232);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(13,0.007262871);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(14,0.006117912);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(15,0.001909332);
   ZccHcc_boosted_PN_med_HMass__1022->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1022->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1022->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1022->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1022->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1022->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1022->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1022->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1022->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1023 = new TH1D("ZccHcc_boosted_PN_med_HMass__1023","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(9,0.0005054859);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(10,0.003724084);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(11,0.0002491591);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(12,0.01445649);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(13,0.02705867);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(14,0.02196136);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(15,0.002364437);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(9,0.0003576283);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(10,0.002633792);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(11,0.0002491591);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(12,0.005146909);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(13,0.00724795);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(14,0.006114659);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(15,0.001894639);
   ZccHcc_boosted_PN_med_HMass__1023->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__1023->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1023->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1023->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1023->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1023->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1023->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1023->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1023->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","MUON Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","MUON Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__408->Modified();
   c1_n27->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__409 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__409->Draw();
   pad1_v2__409->cd();
   pad1_v2__409->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__409->SetFillColor(0);
   pad1_v2__409->SetBorderMode(0);
   pad1_v2__409->SetBorderSize(2);
   pad1_v2__409->SetFrameBorderMode(0);
   pad1_v2__409->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1024 = new TH1D("ZccHcc_boosted_PN_med_HMass__1024","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(9,1.001823);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(10,1.002971);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(11,1.001551);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(12,1.001705);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(13,1.000624);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(14,1.000232);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(15,1.003344);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(9,1.002296);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(10,1.003114);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(11,1.416408);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(12,0.5042671);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(13,0.3792783);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(14,0.3938682);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(15,1.137902);
   ZccHcc_boosted_PN_med_HMass__1024->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__1024->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__1024->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__1024->SetEntries(8.162118);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__1024->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1024->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1024->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__1024->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1024->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1024->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__1025 = new TH1D("ZccHcc_boosted_PN_med_HMass__1025","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(9,0.9981812);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(10,0.997036);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(11,0.998449);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(12,0.9983004);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(13,0.9993768);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(14,0.9997682);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(15,0.9966658);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(9,0.9987026);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(10,0.9972009);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(11,1.41202);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(12,0.502613);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(13,0.3786522);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(14,0.3936722);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(15,1.129736);
   ZccHcc_boosted_PN_med_HMass__1025->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__1025->SetEntries(8.166572);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__1025->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__1025->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1025->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__1025->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__1025->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__409->Modified();
   c1_n27->cd();
   c1_n27->Modified();
   c1_n27->SetSelected(c1_n27);
}
