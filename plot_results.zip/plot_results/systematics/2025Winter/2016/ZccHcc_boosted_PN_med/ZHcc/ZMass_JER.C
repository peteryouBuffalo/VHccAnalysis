#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JER()
{
//=========Macro generated from canvas: c1_n18/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1_n18 = new TCanvas("c1_n18", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n18->SetHighLightColor(2);
   c1_n18->Range(0,0,1,1);
   c1_n18->SetFillColor(0);
   c1_n18->SetBorderMode(0);
   c1_n18->SetBorderSize(2);
   c1_n18->SetLeftMargin(0.15);
   c1_n18->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__504 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__504->Draw();
   pad1_v1__504->cd();
   pad1_v1__504->Range(-37.5,-0.2544641,337.5,2.290177);
   pad1_v1__504->SetFillColor(0);
   pad1_v1__504->SetBorderMode(0);
   pad1_v1__504->SetBorderSize(2);
   pad1_v1__504->SetFrameBorderMode(0);
   pad1_v1__504->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1261 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1261","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1261->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1261->SetMaximum(2.035713);
   ZccHcc_boosted_PN_med_ZMass__1261->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1261->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1261->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1261->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1261->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1261->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1261->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1261->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1261->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1261->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1262 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1262","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(8,0.007245871);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(9,0.02104641);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(10,0.03427489);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(8,0.003653731);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(9,0.00655221);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(10,0.007691343);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1262->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1262->SetEntries(55);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1262->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1262->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1262->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1262->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1262->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1262->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1262->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1263 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1263","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(9,0.02298193);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(11,0.004971631);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(9,0.006834881);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(11,0.002596048);
   ZccHcc_boosted_PN_med_ZMass__1263->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1263->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1263->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1263->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1263->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1263->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1263->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1263->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1263->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JER Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JER Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__504->Modified();
   c1_n18->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__505 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__505->Draw();
   pad1_v2__505->cd();
   pad1_v2__505->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__505->SetFillColor(0);
   pad1_v2__505->SetBorderMode(0);
   pad1_v2__505->SetBorderSize(2);
   pad1_v2__505->SetFrameBorderMode(0);
   pad1_v2__505->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1264 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1264","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(8,1.34398);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(9,0.9929856);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(10,0.9597418);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(8,1.036892);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(9,0.4371439);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(10,0.3018498);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(11,0.7048953);
   ZccHcc_boosted_PN_med_ZMass__1264->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__1264->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1264->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1264->SetEntries(7.765924);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1264->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1264->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1264->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1264->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1264->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1264->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1265 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1265","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(9,1.084305);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(11,0.9496637);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(8,0.8257816);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(9,0.466794);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(10,0.3116452);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(11,0.6855378);
   ZccHcc_boosted_PN_med_ZMass__1265->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__1265->SetEntries(7.648862);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1265->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1265->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1265->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1265->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1265->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__505->Modified();
   c1_n18->cd();
   c1_n18->Modified();
   c1_n18->SetSelected(c1_n18);
}
