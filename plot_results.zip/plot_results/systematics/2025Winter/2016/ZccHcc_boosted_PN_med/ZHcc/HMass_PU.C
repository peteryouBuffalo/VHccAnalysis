#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_PU()
{
//=========Macro generated from canvas: c1_n19/
//=========  (Fri Feb 28 11:35:55 2025) by ROOT version 6.30/03
   TCanvas *c1_n19 = new TCanvas("c1_n19", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n19->SetHighLightColor(2);
   c1_n19->Range(0,0,1,1);
   c1_n19->SetFillColor(0);
   c1_n19->SetBorderMode(0);
   c1_n19->SetBorderSize(2);
   c1_n19->SetLeftMargin(0.15);
   c1_n19->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__392 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__392->Draw();
   pad1_v1__392->cd();
   pad1_v1__392->Range(-37.5,-0.2533954,337.5,2.280558);
   pad1_v1__392->SetFillColor(0);
   pad1_v1__392->SetBorderMode(0);
   pad1_v1__392->SetBorderSize(2);
   pad1_v1__392->SetFrameBorderMode(0);
   pad1_v1__392->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__981 = new TH1D("ZccHcc_boosted_PN_med_HMass__981","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(9,0.0005064069);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(10,0.003735155);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(12,0.0144811);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(13,0.02707555);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(14,0.02196645);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(15,0.002372347);
   ZccHcc_boosted_PN_med_HMass__981->SetBinContent(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(9,0.0003582617);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(10,0.002641558);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(11,0.0002495462);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(12,0.005155048);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(13,0.007255395);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(14,0.006116284);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(15,0.001901974);
   ZccHcc_boosted_PN_med_HMass__981->SetBinError(17,0.001532092);
   ZccHcc_boosted_PN_med_HMass__981->SetMaximum(2.027163);
   ZccHcc_boosted_PN_med_HMass__981->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__981->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__981->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__981->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__981->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__981->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__981->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__981->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__981->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__981->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__981->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__981->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__981->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__981->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__981->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__982 = new TH1D("ZccHcc_boosted_PN_med_HMass__982","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(9,0.0004253471);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(10,0.003355634);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(11,0.0001925559);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(12,0.01268767);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(13,0.02672289);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(14,0.02258499);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(15,0.002354599);
   ZccHcc_boosted_PN_med_HMass__982->SetBinContent(17,0.001925609);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(9,0.0003008518);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(10,0.002374376);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(11,0.0001925559);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(12,0.004530394);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(13,0.006890988);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(14,0.006223462);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(15,0.001974475);
   ZccHcc_boosted_PN_med_HMass__982->SetBinError(17,0.001925609);
   ZccHcc_boosted_PN_med_HMass__982->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__982->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__982->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__982->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__982->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__982->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__982->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__982->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__982->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__982->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__982->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__982->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__982->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__983 = new TH1D("ZccHcc_boosted_PN_med_HMass__983","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(9,0.000596487);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(10,0.004076334);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(11,0.0003201067);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(12,0.01677191);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(13,0.0271627);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(14,0.02152328);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(15,0.002355555);
   ZccHcc_boosted_PN_med_HMass__983->SetBinContent(17,0.001132904);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(9,0.0004237027);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(10,0.002888468);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(11,0.0003201067);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(12,0.006130877);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(13,0.007772098);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(14,0.00624935);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(15,0.001788708);
   ZccHcc_boosted_PN_med_HMass__983->SetBinError(17,0.001132904);
   ZccHcc_boosted_PN_med_HMass__983->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__983->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__983->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__983->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__983->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__983->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__983->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__983->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__983->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__983->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__983->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__983->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__983->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__392->Modified();
   c1_n19->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__393 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__393->Draw();
   pad1_v2__393->cd();
   pad1_v2__393->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__393->SetFillColor(0);
   pad1_v2__393->SetBorderMode(0);
   pad1_v2__393->SetBorderSize(2);
   pad1_v2__393->SetFrameBorderMode(0);
   pad1_v2__393->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__984 = new TH1D("ZccHcc_boosted_PN_med_HMass__984","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(9,0.8399314);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(10,0.898392);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(11,0.7716245);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(12,0.8761536);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(13,0.986975);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(14,1.028158);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(15,0.992519);
   ZccHcc_boosted_PN_med_HMass__984->SetBinContent(17,1.25685);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(9,0.8402602);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(10,0.898761);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(11,1.091242);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(12,0.4417626);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(13,0.3670476);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(14,0.4027696);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(15,1.151472);
   ZccHcc_boosted_PN_med_HMass__984->SetBinError(17,1.777454);
   ZccHcc_boosted_PN_med_HMass__984->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__984->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__984->SetEntries(7.619387);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__984->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__984->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__984->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__984->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__984->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__984->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__984->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__984->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__985 = new TH1D("ZccHcc_boosted_PN_med_HMass__985","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(9,1.177881);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(10,1.091343);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(11,1.282755);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(12,1.158193);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(13,1.003219);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(14,0.9798252);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(15,0.9929217);
   ZccHcc_boosted_PN_med_HMass__985->SetBinContent(17,0.7394492);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(9,1.18086);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(10,1.092575);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(11,1.81409);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(12,0.5909597);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(13,0.3932801);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(14,0.3941679);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(15,1.096443);
   ZccHcc_boosted_PN_med_HMass__985->SetBinError(17,1.045739);
   ZccHcc_boosted_PN_med_HMass__985->SetEntries(8.035962);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__985->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__985->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__985->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__985->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__985->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__985->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__985->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__985->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__985->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__393->Modified();
   c1_n19->cd();
   c1_n19->Modified();
   c1_n19->SetSelected(c1_n19);
}
