#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_TRIG()
{
//=========Macro generated from canvas: c1_n14/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1_n14 = new TCanvas("c1_n14", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n14->SetHighLightColor(2);
   c1_n14->Range(0,0,1,1);
   c1_n14->SetFillColor(0);
   c1_n14->SetBorderMode(0);
   c1_n14->SetBorderSize(2);
   c1_n14->SetLeftMargin(0.15);
   c1_n14->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__496 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__496->Draw();
   pad1_v1__496->cd();
   pad1_v1__496->Range(-37.5,-0.2547839,337.5,2.293055);
   pad1_v1__496->SetFillColor(0);
   pad1_v1__496->SetBorderMode(0);
   pad1_v1__496->SetBorderSize(2);
   pad1_v1__496->SetFrameBorderMode(0);
   pad1_v1__496->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1241 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1241","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1241->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1241->SetMaximum(2.038271);
   ZccHcc_boosted_PN_med_ZMass__1241->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1241->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1241->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1241->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1241->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1241->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1241->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1241->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1241->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1241->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1242 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1242","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(5,0.0002982231);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(7,0.0002687553);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(8,0.005688965);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(9,0.02253975);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(10,0.03827071);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(11,0.005584052);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinContent(12,0.004201403);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(5,0.0002982231);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(7,0.0002687553);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(8,0.003323805);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(9,0.007111858);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(10,0.008450229);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(11,0.002775265);
   ZccHcc_boosted_PN_med_ZMass__1242->SetBinError(12,0.002975888);
   ZccHcc_boosted_PN_med_ZMass__1242->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1242->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1242->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1242->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1242->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1242->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1242->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1242->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1243 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1243","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(5,0.0002395479);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(7,0.0002536162);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(8,0.005093744);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(9,0.01985042);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(10,0.03315452);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(11,0.004886247);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinContent(12,0.00350733);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(5,0.0002395479);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(7,0.0002536162);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(8,0.002976587);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(9,0.006094413);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(10,0.007297933);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(11,0.002447324);
   ZccHcc_boosted_PN_med_ZMass__1243->SetBinError(12,0.002480473);
   ZccHcc_boosted_PN_med_ZMass__1243->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1243->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1243->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1243->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1243->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1243->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1243->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1243->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","TRIG Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","TRIG Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__496->Modified();
   c1_n14->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__497 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__497->Draw();
   pad1_v2__497->cd();
   pad1_v2__497->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__497->SetFillColor(0);
   pad1_v2__497->SetBorderMode(0);
   pad1_v2__497->SetBorderSize(2);
   pad1_v2__497->SetFrameBorderMode(0);
   pad1_v2__497->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1244 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1244","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(5,1.109108);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(7,1.028981);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(8,1.055201);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(9,1.063442);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(10,1.07163);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(11,1.066646);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinContent(12,1.090037);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(5,1.568516);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(7,1.4552);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(8,0.8716188);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(9,0.4713327);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(10,0.3342981);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(11,0.7507902);
   ZccHcc_boosted_PN_med_ZMass__1244->SetBinError(12,1.091402);
   ZccHcc_boosted_PN_med_ZMass__1244->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1244->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1244->SetEntries(7.544237);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1244->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1244->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1244->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1244->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1244->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1244->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1245 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1245","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(5,0.8908919);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(7,0.9710185);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(8,0.9447986);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(9,0.9365578);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(10,0.9283701);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(11,0.9333538);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinContent(12,0.9099629);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(5,1.259911);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(7,1.373228);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(8,0.780495);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(9,0.4094611);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(10,0.2891596);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(11,0.659518);
   ZccHcc_boosted_PN_med_ZMass__1245->SetBinError(12,0.9104052);
   ZccHcc_boosted_PN_med_ZMass__1245->SetEntries(7.582949);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1245->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1245->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1245->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1245->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1245->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__497->Modified();
   c1_n14->cd();
   c1_n14->Modified();
   c1_n14->SetSelected(c1_n14);
}
