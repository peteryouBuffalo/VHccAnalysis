#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_L1PREFIRING()
{
//=========Macro generated from canvas: c1/
//=========  (Fri Feb 28 11:35:57 2025) by ROOT version 6.30/03
   TCanvas *c1 = new TCanvas("c1", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1->SetHighLightColor(2);
   c1->Range(0,0,1,1);
   c1->SetFillColor(0);
   c1->SetBorderMode(0);
   c1->SetBorderSize(2);
   c1->SetLeftMargin(0.15);
   c1->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__480 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__480->Draw();
   pad1_v1__480->cd();
   pad1_v1__480->Range(-37.5,-0.2544711,337.5,2.29024);
   pad1_v1__480->SetFillColor(0);
   pad1_v1__480->SetBorderMode(0);
   pad1_v1__480->SetBorderSize(2);
   pad1_v1__480->SetFrameBorderMode(0);
   pad1_v1__480->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1201 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1201","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(8,0.005391355);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(9,0.02119509);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(10,0.03571261);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(11,0.005235149);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinContent(12,0.003854366);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(5,0.0002688855);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(7,0.0002611857);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(8,0.003148097);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(9,0.00659718);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(10,0.007869862);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(11,0.002609388);
   ZccHcc_boosted_PN_med_ZMass__1201->SetBinError(12,0.002727641);
   ZccHcc_boosted_PN_med_ZMass__1201->SetMaximum(2.035768);
   ZccHcc_boosted_PN_med_ZMass__1201->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__1201->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1201->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1201->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1201->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1201->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__1201->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__1201->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1201->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1201->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1202 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1202","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(5,0.0002672979);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(7,0.0002607492);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(8,0.005390368);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(9,0.02115614);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(10,0.03565404);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(11,0.005214987);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinContent(12,0.00384778);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(5,0.0002672979);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(7,0.0002607492);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(8,0.003147436);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(9,0.006591573);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(10,0.007858466);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(11,0.002599415);
   ZccHcc_boosted_PN_med_ZMass__1202->SetBinError(12,0.002723178);
   ZccHcc_boosted_PN_med_ZMass__1202->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1202->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1202->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1202->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1202->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1202->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1202->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1202->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1203 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1203","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(5,0.0002701046);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(7,0.0002611916);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(8,0.005392342);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(9,0.02122629);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(10,0.03576844);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(11,0.005253542);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinContent(12,0.003860953);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(5,0.0002701046);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(7,0.0002611916);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(8,0.003148758);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(9,0.006600843);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(10,0.007880812);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(11,0.002618645);
   ZccHcc_boosted_PN_med_ZMass__1203->SetBinError(12,0.002732112);
   ZccHcc_boosted_PN_med_ZMass__1203->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1203->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1203->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1203->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1203->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1203->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1203->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1203->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","L1PREFIRING Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","L1PREFIRING Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__480->Modified();
   c1->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__481 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__481->Draw();
   pad1_v2__481->cd();
   pad1_v2__481->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__481->SetFillColor(0);
   pad1_v2__481->SetBorderMode(0);
   pad1_v2__481->SetBorderSize(2);
   pad1_v2__481->SetFrameBorderMode(0);
   pad1_v2__481->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1204 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1204","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(5,0.9940958);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(7,0.9983286);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(8,0.9998169);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(9,0.9981626);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(10,0.9983598);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(11,0.9961486);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinContent(12,0.9982911);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(5,1.405864);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(7,1.41185);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(8,0.8256193);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(9,0.4395966);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(10,0.311164);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(11,0.7021908);
   ZccHcc_boosted_PN_med_ZMass__1204->SetBinError(12,0.9991305);
   ZccHcc_boosted_PN_med_ZMass__1204->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__1204->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__1204->SetEntries(7.580674);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__1204->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1204->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1204->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__1204->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1204->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1204->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__1205 = new TH1D("ZccHcc_boosted_PN_med_ZMass__1205","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(5,1.004534);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(7,1.000022);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(8,1.000183);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(9,1.001472);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(10,1.001563);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(11,1.003513);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinContent(12,1.001709);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(5,1.420626);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(7,1.414245);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(8,0.8259439);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(9,0.4406342);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(10,0.3121056);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(11,0.7073838);
   ZccHcc_boosted_PN_med_ZMass__1205->SetBinError(12,1.00248);
   ZccHcc_boosted_PN_med_ZMass__1205->SetEntries(7.569537);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__1205->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__1205->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1205->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__1205->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__1205->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__481->Modified();
   c1->cd();
   c1->Modified();
   c1->SetSelected(c1);
}
