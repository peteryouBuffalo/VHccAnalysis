#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_ELEC()
{
//=========Macro generated from canvas: c1_n16/
//=========  (Fri Feb 28 12:19:06 2025) by ROOT version 6.30/03
   TCanvas *c1_n16 = new TCanvas("c1_n16", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n16->SetHighLightColor(2);
   c1_n16->Range(0,0,1,1);
   c1_n16->SetFillColor(0);
   c1_n16->SetBorderMode(0);
   c1_n16->SetBorderSize(2);
   c1_n16->SetLeftMargin(0.15);
   c1_n16->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__272 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__272->Draw();
   pad1_v1__272->cd();
   pad1_v1__272->Range(-37.5,-0.469438,337.5,4.224942);
   pad1_v1__272->SetFillColor(0);
   pad1_v1__272->SetBorderMode(0);
   pad1_v1__272->SetBorderSize(2);
   pad1_v1__272->SetFrameBorderMode(0);
   pad1_v1__272->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__681 = new TH1D("VHcc_boosted_PN_med_HMass__681","",30,0,300);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__681->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__681->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__681->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__681->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__681->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__681->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__681->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__681->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__681->SetMaximum(3.755504);
   VHcc_boosted_PN_med_HMass__681->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__681->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__681->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__681->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__681->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__681->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__681->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__681->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__681->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__681->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__681->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__681->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__681->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__681->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__681->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__682 = new TH1D("VHcc_boosted_PN_med_HMass__682","",30,0,300);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(7,0.2188311);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(9,1.527143);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(10,1.755504);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(11,1.481982);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(12,0.1995334);
   VHcc_boosted_PN_med_HMass__682->SetBinContent(15,0.2232279);
   VHcc_boosted_PN_med_HMass__682->SetBinError(7,0.2188311);
   VHcc_boosted_PN_med_HMass__682->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__682->SetBinError(9,0.5778125);
   VHcc_boosted_PN_med_HMass__682->SetBinError(10,0.621066);
   VHcc_boosted_PN_med_HMass__682->SetBinError(11,0.5613588);
   VHcc_boosted_PN_med_HMass__682->SetBinError(12,0.1995334);
   VHcc_boosted_PN_med_HMass__682->SetBinError(15,0.2232279);
   VHcc_boosted_PN_med_HMass__682->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__682->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__682->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__682->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__682->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__682->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__682->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__682->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__682->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__682->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__682->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__682->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__682->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__683 = new TH1D("VHcc_boosted_PN_med_HMass__683","",30,0,300);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(7,0.2176013);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(9,1.517794);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(10,1.726758);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(11,1.481101);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(12,0.1912302);
   VHcc_boosted_PN_med_HMass__683->SetBinContent(15,0.2179481);
   VHcc_boosted_PN_med_HMass__683->SetBinError(7,0.2176013);
   VHcc_boosted_PN_med_HMass__683->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__683->SetBinError(9,0.5741326);
   VHcc_boosted_PN_med_HMass__683->SetBinError(10,0.6112064);
   VHcc_boosted_PN_med_HMass__683->SetBinError(11,0.5610012);
   VHcc_boosted_PN_med_HMass__683->SetBinError(12,0.1912302);
   VHcc_boosted_PN_med_HMass__683->SetBinError(15,0.2179481);
   VHcc_boosted_PN_med_HMass__683->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__683->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__683->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__683->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__683->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__683->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__683->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__683->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__683->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__683->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__683->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__683->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__683->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","ELEC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","ELEC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__272->Modified();
   c1_n16->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__273 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__273->Draw();
   pad1_v2__273->cd();
   pad1_v2__273->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__273->SetFillColor(0);
   pad1_v2__273->SetBorderMode(0);
   pad1_v2__273->SetBorderSize(2);
   pad1_v2__273->SetFrameBorderMode(0);
   pad1_v2__273->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__684 = new TH1D("VHcc_boosted_PN_med_HMass__684","",30,0,300);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(7,1.002818);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(9,1.00307);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(10,1.008266);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(11,1.000298);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(12,1.021375);
   VHcc_boosted_PN_med_HMass__684->SetBinContent(15,1.011968);
   VHcc_boosted_PN_med_HMass__684->SetBinError(7,1.418199);
   VHcc_boosted_PN_med_HMass__684->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__684->SetBinError(9,0.5366908);
   VHcc_boosted_PN_med_HMass__684->SetBinError(10,0.5045123);
   VHcc_boosted_PN_med_HMass__684->SetBinError(11,0.5358425);
   VHcc_boosted_PN_med_HMass__684->SetBinError(12,1.444442);
   VHcc_boosted_PN_med_HMass__684->SetBinError(15,1.431138);
   VHcc_boosted_PN_med_HMass__684->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__684->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__684->SetEntries(5.534077);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__684->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__684->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__684->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__684->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__684->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__684->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__684->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__684->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__685 = new TH1D("VHcc_boosted_PN_med_HMass__685","",30,0,300);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(7,0.9971821);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(9,0.9969297);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(10,0.9917563);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(11,0.9997024);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(12,0.9788724);
   VHcc_boosted_PN_med_HMass__685->SetBinContent(15,0.9880326);
   VHcc_boosted_PN_med_HMass__685->SetBinError(7,1.410228);
   VHcc_boosted_PN_med_HMass__685->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__685->SetBinError(9,0.533339);
   VHcc_boosted_PN_med_HMass__685->SetBinError(10,0.496377);
   VHcc_boosted_PN_med_HMass__685->SetBinError(11,0.5355124);
   VHcc_boosted_PN_med_HMass__685->SetBinError(12,1.384335);
   VHcc_boosted_PN_med_HMass__685->SetBinError(15,1.397289);
   VHcc_boosted_PN_med_HMass__685->SetEntries(5.571877);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__685->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__685->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__685->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__685->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__685->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__685->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__685->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__685->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__685->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__273->Modified();
   c1_n16->cd();
   c1_n16->Modified();
   c1_n16->SetSelected(c1_n16);
}
