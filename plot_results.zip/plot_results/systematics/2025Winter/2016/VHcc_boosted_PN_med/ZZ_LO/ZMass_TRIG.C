#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_TRIG()
{
//=========Macro generated from canvas: c1_n6/
//=========  (Fri Feb 28 12:19:08 2025) by ROOT version 6.30/03
   TCanvas *c1_n6 = new TCanvas("c1_n6", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n6->SetHighLightColor(2);
   c1_n6->Range(0,0,1,1);
   c1_n6->SetFillColor(0);
   c1_n6->SetBorderMode(0);
   c1_n6->SetBorderSize(2);
   c1_n6->SetLeftMargin(0.15);
   c1_n6->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__368 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__368->Draw();
   pad1_v1__368->cd();
   pad1_v1__368->Range(-37.5,-0.5047361,337.5,4.542624);
   pad1_v1__368->SetFillColor(0);
   pad1_v1__368->SetBorderMode(0);
   pad1_v1__368->SetBorderSize(2);
   pad1_v1__368->SetFrameBorderMode(0);
   pad1_v1__368->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__921 = new TH1D("VHcc_boosted_PN_med_ZMass__921","",30,0,300);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__921->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__921->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__921->SetMaximum(4.037888);
   VHcc_boosted_PN_med_ZMass__921->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__921->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__921->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__921->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__921->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__921->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__921->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__921->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__921->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__921->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__921->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__921->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__921->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__921->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__921->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__922 = new TH1D("VHcc_boosted_PN_med_ZMass__922","",30,0,300);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(5,0.2067145);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(7,0.4605712);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(8,0.4498173);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(9,1.817818);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(10,2.037888);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(11,0.6858762);
   VHcc_boosted_PN_med_ZMass__922->SetBinContent(14,0.226981);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(5,0.2067145);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(7,0.3257744);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(8,0.3181273);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(9,0.6445756);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(10,0.680482);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(11,0.3966584);
   VHcc_boosted_PN_med_ZMass__922->SetBinError(14,0.226981);
   VHcc_boosted_PN_med_ZMass__922->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__922->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__922->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__922->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__922->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__922->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__922->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__922->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__922->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__922->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__922->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__922->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__922->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__923 = new TH1D("VHcc_boosted_PN_med_ZMass__923","",30,0,300);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(5,0.1886047);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(7,0.434627);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(8,0.4076512);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(9,1.626674);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(10,1.845015);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(11,0.5908033);
   VHcc_boosted_PN_med_ZMass__923->SetBinContent(14,0.214195);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(5,0.1886047);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(7,0.3074234);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(8,0.2883184);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(9,0.5766572);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(10,0.6162211);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(11,0.3417291);
   VHcc_boosted_PN_med_ZMass__923->SetBinError(14,0.214195);
   VHcc_boosted_PN_med_ZMass__923->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__923->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__923->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__923->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__923->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__923->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__923->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__923->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__923->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__923->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__923->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__923->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__923->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","TRIG Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","TRIG Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__368->Modified();
   c1_n6->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__369 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__369->Draw();
   pad1_v2__369->cd();
   pad1_v2__369->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__369->SetFillColor(0);
   pad1_v2__369->SetBorderMode(0);
   pad1_v2__369->SetBorderSize(2);
   pad1_v2__369->SetFrameBorderMode(0);
   pad1_v2__369->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__924 = new TH1D("VHcc_boosted_PN_med_ZMass__924","",30,0,300);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(5,1.04581);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(7,1.028981);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(8,1.049175);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(9,1.055493);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(10,1.049673);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(11,1.074469);
   VHcc_boosted_PN_med_ZMass__924->SetBinContent(14,1.028981);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(5,1.478999);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(7,1.029302);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(8,1.049272);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(9,0.5290693);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(10,0.4955506);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(11,0.8781893);
   VHcc_boosted_PN_med_ZMass__924->SetBinError(14,1.4552);
   VHcc_boosted_PN_med_ZMass__924->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__924->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__924->SetEntries(6.926763);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__924->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__924->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__924->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__924->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__924->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__924->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__924->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__924->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__925 = new TH1D("VHcc_boosted_PN_med_ZMass__925","",30,0,300);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(5,0.9541895);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(7,0.9710185);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(8,0.9508249);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(9,0.9445073);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(10,0.9503275);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(11,0.9255311);
   VHcc_boosted_PN_med_ZMass__925->SetBinContent(14,0.9710184);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(5,1.349428);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(7,0.9713207);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(8,0.9509329);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(9,0.4733795);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(10,0.4487017);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(11,0.7565182);
   VHcc_boosted_PN_med_ZMass__925->SetBinError(14,1.373227);
   VHcc_boosted_PN_med_ZMass__925->SetEntries(6.784674);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__925->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__925->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__925->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__925->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__925->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__925->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__925->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__925->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__925->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__369->Modified();
   c1_n6->cd();
   c1_n6->Modified();
   c1_n6->SetSelected(c1_n6);
}
