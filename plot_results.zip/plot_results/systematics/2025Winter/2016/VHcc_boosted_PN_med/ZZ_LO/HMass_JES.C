#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n7/
//=========  (Fri Feb 28 12:19:06 2025) by ROOT version 6.30/03
   TCanvas *c1_n7 = new TCanvas("c1_n7", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n7->SetHighLightColor(2);
   c1_n7->Range(0,0,1,1);
   c1_n7->SetFillColor(0);
   c1_n7->SetBorderMode(0);
   c1_n7->SetBorderSize(2);
   c1_n7->SetLeftMargin(0.15);
   c1_n7->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__256 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__256->Draw();
   pad1_v1__256->cd();
   pad1_v1__256->Range(-37.5,-0.4988072,337.5,4.489265);
   pad1_v1__256->SetFillColor(0);
   pad1_v1__256->SetBorderMode(0);
   pad1_v1__256->SetBorderSize(2);
   pad1_v1__256->SetFrameBorderMode(0);
   pad1_v1__256->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__641 = new TH1D("VHcc_boosted_PN_med_HMass__641","",30,0,300);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__641->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__641->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__641->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__641->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__641->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__641->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__641->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__641->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__641->SetMaximum(3.990457);
   VHcc_boosted_PN_med_HMass__641->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__641->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__641->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__641->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__641->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__641->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__641->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__641->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__641->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__641->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__641->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__641->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__641->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__641->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__641->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__642 = new TH1D("VHcc_boosted_PN_med_HMass__642","",30,0,300);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(9,1.295404);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(10,1.990457);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(11,1.501014);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__642->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__642->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__642->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__642->SetBinError(9,0.5293302);
   VHcc_boosted_PN_med_HMass__642->SetBinError(10,0.6646538);
   VHcc_boosted_PN_med_HMass__642->SetBinError(11,0.5683716);
   VHcc_boosted_PN_med_HMass__642->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__642->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__642->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__642->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__642->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__642->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__642->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__642->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__642->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__642->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__642->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__642->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__642->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__642->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__642->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__643 = new TH1D("VHcc_boosted_PN_med_HMass__643","",30,0,300);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(10,1.733232);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(11,1.049164);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__643->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__643->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__643->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__643->SetBinError(10,0.6131305);
   VHcc_boosted_PN_med_HMass__643->SetBinError(11,0.4702891);
   VHcc_boosted_PN_med_HMass__643->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__643->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__643->SetEntries(23);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__643->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__643->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__643->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__643->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__643->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__643->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__643->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__643->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__643->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__643->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__643->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__643->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__256->Modified();
   c1_n7->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__257 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__257->Draw();
   pad1_v2__257->cd();
   pad1_v2__257->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__257->SetFillColor(0);
   pad1_v2__257->SetBorderMode(0);
   pad1_v2__257->SetBorderSize(2);
   pad1_v2__257->SetFrameBorderMode(0);
   pad1_v2__257->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__644 = new TH1D("VHcc_boosted_PN_med_HMass__644","",30,0,300);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(9,0.850858);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(10,1.143211);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(11,1.013143);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(12,1);
   VHcc_boosted_PN_med_HMass__644->SetBinContent(15,1);
   VHcc_boosted_PN_med_HMass__644->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__644->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__644->SetBinError(9,0.4738067);
   VHcc_boosted_PN_med_HMass__644->SetBinError(10,0.5562129);
   VHcc_boosted_PN_med_HMass__644->SetBinError(11,0.5426301);
   VHcc_boosted_PN_med_HMass__644->SetBinError(12,1.414214);
   VHcc_boosted_PN_med_HMass__644->SetBinError(15,1.414214);
   VHcc_boosted_PN_med_HMass__644->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__644->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__644->SetEntries(5.561767);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__644->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__644->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__644->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__644->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__644->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__644->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__644->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__644->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__645 = new TH1D("VHcc_boosted_PN_med_HMass__645","",30,0,300);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(9,1);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(10,0.9954745);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(11,0.7081572);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(12,1);
   VHcc_boosted_PN_med_HMass__645->SetBinContent(15,1);
   VHcc_boosted_PN_med_HMass__645->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__645->SetBinError(9,0.5350115);
   VHcc_boosted_PN_med_HMass__645->SetBinError(10,0.4980888);
   VHcc_boosted_PN_med_HMass__645->SetBinError(11,0.4155888);
   VHcc_boosted_PN_med_HMass__645->SetBinError(12,1.414214);
   VHcc_boosted_PN_med_HMass__645->SetBinError(15,1.414214);
   VHcc_boosted_PN_med_HMass__645->SetEntries(4.850336);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__645->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__645->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__645->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__645->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__645->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__645->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__645->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__645->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__645->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__257->Modified();
   c1_n7->cd();
   c1_n7->Modified();
   c1_n7->SetSelected(c1_n7);
}
