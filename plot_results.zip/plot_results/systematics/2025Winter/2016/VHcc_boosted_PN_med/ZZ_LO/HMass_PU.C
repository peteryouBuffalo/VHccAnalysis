#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_PU()
{
//=========Macro generated from canvas: c1_n11/
//=========  (Fri Feb 28 12:19:06 2025) by ROOT version 6.30/03
   TCanvas *c1_n11 = new TCanvas("c1_n11", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n11->SetHighLightColor(2);
   c1_n11->Range(0,0,1,1);
   c1_n11->SetFillColor(0);
   c1_n11->SetBorderMode(0);
   c1_n11->SetBorderSize(2);
   c1_n11->SetLeftMargin(0.15);
   c1_n11->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__264 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__264->Draw();
   pad1_v1__264->cd();
   pad1_v1__264->Range(-37.5,-0.4782484,337.5,4.304235);
   pad1_v1__264->SetFillColor(0);
   pad1_v1__264->SetBorderMode(0);
   pad1_v1__264->SetBorderSize(2);
   pad1_v1__264->SetFrameBorderMode(0);
   pad1_v1__264->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__661 = new TH1D("VHcc_boosted_PN_med_HMass__661","",30,0,300);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__661->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__661->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__661->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__661->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__661->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__661->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__661->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__661->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__661->SetMaximum(3.825987);
   VHcc_boosted_PN_med_HMass__661->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__661->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__661->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__661->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__661->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__661->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__661->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__661->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__661->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__661->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__661->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__661->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__661->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__661->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__661->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__662 = new TH1D("VHcc_boosted_PN_med_HMass__662","",30,0,300);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(7,0.2562965);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(8,0.2059978);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(9,1.391062);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(10,1.64831);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(11,1.610191);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(12,0.1827398);
   VHcc_boosted_PN_med_HMass__662->SetBinContent(15,0.2456653);
   VHcc_boosted_PN_med_HMass__662->SetBinError(7,0.2562965);
   VHcc_boosted_PN_med_HMass__662->SetBinError(8,0.2059978);
   VHcc_boosted_PN_med_HMass__662->SetBinError(9,0.5278591);
   VHcc_boosted_PN_med_HMass__662->SetBinError(10,0.5844275);
   VHcc_boosted_PN_med_HMass__662->SetBinError(11,0.6126881);
   VHcc_boosted_PN_med_HMass__662->SetBinError(12,0.1827398);
   VHcc_boosted_PN_med_HMass__662->SetBinError(15,0.2456653);
   VHcc_boosted_PN_med_HMass__662->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__662->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__662->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__662->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__662->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__662->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__662->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__662->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__662->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__662->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__662->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__662->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__662->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__663 = new TH1D("VHcc_boosted_PN_med_HMass__663","",30,0,300);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(7,0.1748503);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(8,0.2257465);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(9,1.65725);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(10,1.825987);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(11,1.320545);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(12,0.2079757);
   VHcc_boosted_PN_med_HMass__663->SetBinContent(15,0.189742);
   VHcc_boosted_PN_med_HMass__663->SetBinError(7,0.1748503);
   VHcc_boosted_PN_med_HMass__663->SetBinError(8,0.2257465);
   VHcc_boosted_PN_med_HMass__663->SetBinError(9,0.6344983);
   VHcc_boosted_PN_med_HMass__663->SetBinError(10,0.6539233);
   VHcc_boosted_PN_med_HMass__663->SetBinError(11,0.5008332);
   VHcc_boosted_PN_med_HMass__663->SetBinError(12,0.2079757);
   VHcc_boosted_PN_med_HMass__663->SetBinError(15,0.189742);
   VHcc_boosted_PN_med_HMass__663->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__663->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__663->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__663->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__663->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__663->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__663->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__663->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__663->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__663->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__663->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__663->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__663->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__264->Modified();
   c1_n11->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__265 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__265->Draw();
   pad1_v2__265->cd();
   pad1_v2__265->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__265->SetFillColor(0);
   pad1_v2__265->SetBorderMode(0);
   pad1_v2__265->SetBorderSize(2);
   pad1_v2__265->SetFrameBorderMode(0);
   pad1_v2__265->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__664 = new TH1D("VHcc_boosted_PN_med_HMass__664","",30,0,300);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(7,1.174507);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(8,0.9478332);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(9,0.9136885);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(10,0.9466999);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(11,1.086835);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(12,0.9354114);
   VHcc_boosted_PN_med_HMass__664->SetBinContent(15,1.113684);
   VHcc_boosted_PN_med_HMass__664->SetBinError(7,1.661004);
   VHcc_boosted_PN_med_HMass__664->SetBinError(8,1.340439);
   VHcc_boosted_PN_med_HMass__664->SetBinError(9,0.4895804);
   VHcc_boosted_PN_med_HMass__664->SetBinError(10,0.474228);
   VHcc_boosted_PN_med_HMass__664->SetBinError(11,0.5835203);
   VHcc_boosted_PN_med_HMass__664->SetBinError(12,1.322871);
   VHcc_boosted_PN_med_HMass__664->SetBinError(15,1.574987);
   VHcc_boosted_PN_med_HMass__664->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__664->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__664->SetEntries(5.283433);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__664->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__664->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__664->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__664->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__664->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__664->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__664->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__664->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__665 = new TH1D("VHcc_boosted_PN_med_HMass__665","",30,0,300);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(7,0.8012712);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(8,1.038701);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(9,1.088529);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(10,1.048748);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(11,0.891332);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(12,1.06459);
   VHcc_boosted_PN_med_HMass__665->SetBinContent(15,0.8601645);
   VHcc_boosted_PN_med_HMass__665->SetBinError(7,1.133169);
   VHcc_boosted_PN_med_HMass__665->SetBinError(8,1.468945);
   VHcc_boosted_PN_med_HMass__665->SetBinError(9,0.5858894);
   VHcc_boosted_PN_med_HMass__665->SetBinError(10,0.527995);
   VHcc_boosted_PN_med_HMass__665->SetBinError(11,0.4777698);
   VHcc_boosted_PN_med_HMass__665->SetBinError(12,1.505557);
   VHcc_boosted_PN_med_HMass__665->SetBinError(15,1.216456);
   VHcc_boosted_PN_med_HMass__665->SetEntries(5.740941);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__665->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__665->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__665->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__665->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__665->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__665->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__665->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__665->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__665->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__265->Modified();
   c1_n11->cd();
   c1_n11->Modified();
   c1_n11->SetSelected(c1_n11);
}
