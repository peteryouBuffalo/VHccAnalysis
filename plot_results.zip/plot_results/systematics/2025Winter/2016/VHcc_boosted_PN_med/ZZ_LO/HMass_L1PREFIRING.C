#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_L1PREFIRING()
{
//=========Macro generated from canvas: c1_n24/
//=========  (Fri Feb 28 12:19:06 2025) by ROOT version 6.30/03
   TCanvas *c1_n24 = new TCanvas("c1_n24", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n24->SetHighLightColor(2);
   c1_n24->Range(0,0,1,1);
   c1_n24->SetFillColor(0);
   c1_n24->SetBorderMode(0);
   c1_n24->SetBorderSize(2);
   c1_n24->SetLeftMargin(0.15);
   c1_n24->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__288 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__288->Draw();
   pad1_v1__288->cd();
   pad1_v1__288->Range(-37.5,-0.4680312,337.5,4.212281);
   pad1_v1__288->SetFillColor(0);
   pad1_v1__288->SetBorderMode(0);
   pad1_v1__288->SetBorderSize(2);
   pad1_v1__288->SetFrameBorderMode(0);
   pad1_v1__288->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__721 = new TH1D("VHcc_boosted_PN_med_HMass__721","",30,0,300);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__721->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__721->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__721->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__721->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__721->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__721->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__721->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__721->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__721->SetMaximum(3.744249);
   VHcc_boosted_PN_med_HMass__721->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__721->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__721->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__721->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__721->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__721->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__721->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__721->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__721->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__721->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__721->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__721->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__721->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__721->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__721->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__722 = new TH1D("VHcc_boosted_PN_med_HMass__722","",30,0,300);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(9,1.52109);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(10,1.737352);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(11,1.47879);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(12,0.1952663);
   VHcc_boosted_PN_med_HMass__722->SetBinContent(15,0.2199515);
   VHcc_boosted_PN_med_HMass__722->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__722->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__722->SetBinError(9,0.5754525);
   VHcc_boosted_PN_med_HMass__722->SetBinError(10,0.6147799);
   VHcc_boosted_PN_med_HMass__722->SetBinError(11,0.5602198);
   VHcc_boosted_PN_med_HMass__722->SetBinError(12,0.1952663);
   VHcc_boosted_PN_med_HMass__722->SetBinError(15,0.2199515);
   VHcc_boosted_PN_med_HMass__722->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__722->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__722->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__722->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__722->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__722->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__722->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__722->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__722->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__722->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__722->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__722->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__722->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__723 = new TH1D("VHcc_boosted_PN_med_HMass__723","",30,0,300);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(9,1.523615);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(10,1.744249);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(11,1.481629);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(12,0.195449);
   VHcc_boosted_PN_med_HMass__723->SetBinContent(15,0.2212245);
   VHcc_boosted_PN_med_HMass__723->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__723->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__723->SetBinError(9,0.5763927);
   VHcc_boosted_PN_med_HMass__723->SetBinError(10,0.6172106);
   VHcc_boosted_PN_med_HMass__723->SetBinError(11,0.5612107);
   VHcc_boosted_PN_med_HMass__723->SetBinError(12,0.195449);
   VHcc_boosted_PN_med_HMass__723->SetBinError(15,0.2212245);
   VHcc_boosted_PN_med_HMass__723->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__723->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__723->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__723->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__723->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__723->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__723->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__723->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__723->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__723->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__723->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__723->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__723->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","L1PREFIRING Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","L1PREFIRING Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__288->Modified();
   c1_n24->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__289 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__289->Draw();
   pad1_v2__289->cd();
   pad1_v2__289->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__289->SetFillColor(0);
   pad1_v2__289->SetBorderMode(0);
   pad1_v2__289->SetBorderSize(2);
   pad1_v2__289->SetFrameBorderMode(0);
   pad1_v2__289->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__724 = new TH1D("VHcc_boosted_PN_med_HMass__724","",30,0,300);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(9,0.9990946);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(10,0.9978408);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(11,0.9981431);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(12,0.9995324);
   VHcc_boosted_PN_med_HMass__724->SetBinContent(15,0.9971146);
   VHcc_boosted_PN_med_HMass__724->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__724->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__724->SetBinError(9,0.5345311);
   VHcc_boosted_PN_med_HMass__724->SetBinError(10,0.4993507);
   VHcc_boosted_PN_med_HMass__724->SetBinError(11,0.5347218);
   VHcc_boosted_PN_med_HMass__724->SetBinError(12,1.413552);
   VHcc_boosted_PN_med_HMass__724->SetBinError(15,1.410133);
   VHcc_boosted_PN_med_HMass__724->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__724->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__724->SetEntries(5.550228);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__724->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__724->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__724->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__724->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__724->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__724->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__724->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__724->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__725 = new TH1D("VHcc_boosted_PN_med_HMass__725","",30,0,300);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(9,1.000753);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(10,1.001802);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(11,1.000059);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(12,1.000468);
   VHcc_boosted_PN_med_HMass__725->SetBinContent(15,1.002885);
   VHcc_boosted_PN_med_HMass__725->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__725->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__725->SetBinError(9,0.5354114);
   VHcc_boosted_PN_med_HMass__725->SetBinError(10,0.5013291);
   VHcc_boosted_PN_med_HMass__725->SetBinError(11,0.5357079);
   VHcc_boosted_PN_med_HMass__725->SetBinError(12,1.414875);
   VHcc_boosted_PN_med_HMass__725->SetBinError(15,1.418294);
   VHcc_boosted_PN_med_HMass__725->SetEntries(5.553441);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__725->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__725->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__725->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__725->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__725->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__725->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__725->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__725->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__725->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__289->Modified();
   c1_n24->cd();
   c1_n24->Modified();
   c1_n24->SetSelected(c1_n24);
}
