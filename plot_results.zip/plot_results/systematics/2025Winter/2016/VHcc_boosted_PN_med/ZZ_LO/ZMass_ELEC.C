#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_ELEC()
{
//=========Macro generated from canvas: c1_n48/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n48 = new TCanvas("c1_n48", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n48->SetHighLightColor(2);
   c1_n48->Range(0,0,1,1);
   c1_n48->SetFillColor(0);
   c1_n48->SetBorderMode(0);
   c1_n48->SetBorderSize(2);
   c1_n48->SetLeftMargin(0.15);
   c1_n48->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__336 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__336->Draw();
   pad1_v1__336->cd();
   pad1_v1__336->Range(-37.5,-0.4932081,337.5,4.438872);
   pad1_v1__336->SetFillColor(0);
   pad1_v1__336->SetBorderMode(0);
   pad1_v1__336->SetBorderSize(2);
   pad1_v1__336->SetFrameBorderMode(0);
   pad1_v1__336->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__841 = new TH1D("VHcc_boosted_PN_med_ZMass__841","",30,0,300);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__841->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__841->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__841->SetMaximum(3.945664);
   VHcc_boosted_PN_med_ZMass__841->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__841->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__841->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__841->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__841->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__841->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__841->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__841->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__841->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__841->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__841->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__841->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__841->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__841->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__841->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__842 = new TH1D("VHcc_boosted_PN_med_ZMass__842","",30,0,300);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(7,0.4511906);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(8,0.4329583);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(9,1.727249);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(10,1.945664);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(11,0.6456071);
   VHcc_boosted_PN_med_ZMass__842->SetBinContent(14,0.2232279);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(7,0.3191833);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(8,0.3061621);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(9,0.6118403);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(10,0.6493339);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(11,0.3728054);
   VHcc_boosted_PN_med_ZMass__842->SetBinError(14,0.2232279);
   VHcc_boosted_PN_med_ZMass__842->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__842->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__842->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__842->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__842->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__842->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__842->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__842->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__842->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__842->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__842->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__842->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__842->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__843 = new TH1D("VHcc_boosted_PN_med_ZMass__843","",30,0,300);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(7,0.4440076);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(8,0.4245495);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(9,1.717292);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(10,1.937238);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(11,0.6310723);
   VHcc_boosted_PN_med_ZMass__843->SetBinContent(14,0.2179481);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(7,0.3140225);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(8,0.3002166);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(9,0.6085545);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(10,0.6465386);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(11,0.3645789);
   VHcc_boosted_PN_med_ZMass__843->SetBinError(14,0.2179481);
   VHcc_boosted_PN_med_ZMass__843->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__843->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__843->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__843->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__843->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__843->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__843->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__843->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__843->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__843->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__843->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__843->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__843->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","ELEC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","ELEC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__336->Modified();
   c1_n48->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__337 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__337->Draw();
   pad1_v2__337->cd();
   pad1_v2__337->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__337->SetFillColor(0);
   pad1_v2__337->SetBorderMode(0);
   pad1_v2__337->SetBorderSize(2);
   pad1_v2__337->SetFrameBorderMode(0);
   pad1_v2__337->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__844 = new TH1D("VHcc_boosted_PN_med_ZMass__844","",30,0,300);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(7,1.008024);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(8,1.009852);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(9,1.002905);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(10,1.00217);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(11,1.011385);
   VHcc_boosted_PN_med_ZMass__844->SetBinContent(14,1.011968);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(7,1.008407);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(8,1.009876);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(9,0.5024545);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(10,0.472996);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(11,0.8260037);
   VHcc_boosted_PN_med_ZMass__844->SetBinError(14,1.431138);
   VHcc_boosted_PN_med_ZMass__844->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__844->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__844->SetEntries(6.854609);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__844->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__844->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__844->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__844->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__844->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__844->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__844->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__844->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__845 = new TH1D("VHcc_boosted_PN_med_ZMass__845","",30,0,300);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(7,0.9919761);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(8,0.9902392);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(9,0.9971234);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(10,0.99783);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(11,0.9886151);
   VHcc_boosted_PN_med_ZMass__845->SetBinContent(14,0.9880326);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(7,0.992228);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(8,0.9902637);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(9,0.4996571);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(10,0.4709537);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(11,0.8075921);
   VHcc_boosted_PN_med_ZMass__845->SetBinError(14,1.397289);
   VHcc_boosted_PN_med_ZMass__845->SetEntries(6.867503);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__845->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__845->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__845->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__845->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__845->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__845->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__845->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__845->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__845->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__337->Modified();
   c1_n48->cd();
   c1_n48->Modified();
   c1_n48->SetSelected(c1_n48);
}
