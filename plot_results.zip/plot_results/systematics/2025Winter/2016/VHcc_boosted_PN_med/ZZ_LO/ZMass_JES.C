#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n40/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n40 = new TCanvas("c1_n40", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n40->SetHighLightColor(2);
   c1_n40->Range(0,0,1,1);
   c1_n40->SetFillColor(0);
   c1_n40->SetBorderMode(0);
   c1_n40->SetBorderSize(2);
   c1_n40->SetLeftMargin(0.15);
   c1_n40->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__320 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__320->Draw();
   pad1_v1__320->cd();
   pad1_v1__320->Range(-37.5,-0.4926815,337.5,4.434133);
   pad1_v1__320->SetFillColor(0);
   pad1_v1__320->SetBorderMode(0);
   pad1_v1__320->SetBorderSize(2);
   pad1_v1__320->SetFrameBorderMode(0);
   pad1_v1__320->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__801 = new TH1D("VHcc_boosted_PN_med_ZMass__801","",30,0,300);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__801->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__801->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__801->SetMaximum(3.941451);
   VHcc_boosted_PN_med_ZMass__801->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__801->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__801->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__801->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__801->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__801->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__801->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__801->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__801->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__801->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__801->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__801->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__801->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__801->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__801->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__802 = new TH1D("VHcc_boosted_PN_med_ZMass__802","",30,0,300);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(6,0.2182285);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(7,0.229383);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(8,0.6469504);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(9,1.744667);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(10,1.719419);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(11,0.6407015);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(12,0.218435);
   VHcc_boosted_PN_med_ZMass__802->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(6,0.2182285);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(7,0.229383);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(8,0.3735302);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(9,0.6189254);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(10,0.6087001);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(11,0.3700753);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(12,0.218435);
   VHcc_boosted_PN_med_ZMass__802->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__802->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__802->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__802->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__802->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__802->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__802->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__802->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__802->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__802->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__802->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__802->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__802->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__802->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__803 = new TH1D("VHcc_boosted_PN_med_ZMass__803","",30,0,300);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(7,0.229383);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(9,1.480586);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(10,1.742855);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__803->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(7,0.229383);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(9,0.560671);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(10,0.6167442);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__803->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__803->SetEntries(23);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__803->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__803->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__803->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__803->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__803->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__803->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__803->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__803->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__803->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__803->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__803->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__803->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__320->Modified();
   c1_n40->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__321 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__321->Draw();
   pad1_v2__321->cd();
   pad1_v2__321->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__321->SetFillColor(0);
   pad1_v2__321->SetBorderMode(0);
   pad1_v2__321->SetBorderSize(2);
   pad1_v2__321->SetFrameBorderMode(0);
   pad1_v2__321->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__804 = new TH1D("VHcc_boosted_PN_med_ZMass__804","",30,0,300);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(7,0.5124741);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(8,1.508978);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(9,1.013019);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(10,0.8856359);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(11,1.0037);
   VHcc_boosted_PN_med_ZMass__804->SetBinContent(14,1);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(7,0.6277152);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(8,1.377521);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(9,0.5078973);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(10,0.4308833);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(11,0.8198411);
   VHcc_boosted_PN_med_ZMass__804->SetBinError(14,1.414214);
   VHcc_boosted_PN_med_ZMass__804->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__804->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__804->SetEntries(6.489588);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__804->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__804->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__804->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__804->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__804->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__804->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__804->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__804->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__805 = new TH1D("VHcc_boosted_PN_med_ZMass__805","",30,0,300);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(7,0.5124741);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(8,1);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(9,0.8596833);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(10,0.8977071);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(11,1);
   VHcc_boosted_PN_med_ZMass__805->SetBinContent(14,1);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(7,0.6277152);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(8,1);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(9,0.4458123);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(10,0.4366616);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(11,0.8167745);
   VHcc_boosted_PN_med_ZMass__805->SetBinError(14,1.414214);
   VHcc_boosted_PN_med_ZMass__805->SetEntries(6.094222);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__805->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__805->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__805->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__805->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__805->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__805->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__805->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__805->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__805->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__321->Modified();
   c1_n40->cd();
   c1_n40->Modified();
   c1_n40->SetSelected(c1_n40);
}
