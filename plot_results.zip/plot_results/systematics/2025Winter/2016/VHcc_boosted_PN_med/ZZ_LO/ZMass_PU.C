#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_PU()
{
//=========Macro generated from canvas: c1_n44/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n44 = new TCanvas("c1_n44", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n44->SetHighLightColor(2);
   c1_n44->Range(0,0,1,1);
   c1_n44->SetFillColor(0);
   c1_n44->SetBorderMode(0);
   c1_n44->SetBorderSize(2);
   c1_n44->SetLeftMargin(0.15);
   c1_n44->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__328 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__328->Draw();
   pad1_v1__328->cd();
   pad1_v1__328->Range(-37.5,-0.4926815,337.5,4.434133);
   pad1_v1__328->SetFillColor(0);
   pad1_v1__328->SetBorderMode(0);
   pad1_v1__328->SetBorderSize(2);
   pad1_v1__328->SetFrameBorderMode(0);
   pad1_v1__328->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__821 = new TH1D("VHcc_boosted_PN_med_ZMass__821","",30,0,300);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__821->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__821->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__821->SetMaximum(3.941451);
   VHcc_boosted_PN_med_ZMass__821->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__821->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__821->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__821->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__821->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__821->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__821->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__821->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__821->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__821->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__821->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__821->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__821->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__821->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__821->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__822 = new TH1D("VHcc_boosted_PN_med_ZMass__822","",30,0,300);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(5,0.1991067);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(7,0.4238716);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(8,0.4401123);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(9,1.665726);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(10,1.91913);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(11,0.6466498);
   VHcc_boosted_PN_med_ZMass__822->SetBinContent(14,0.2456653);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(5,0.1991067);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(7,0.3062177);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(8,0.3112604);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(9,0.5944466);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(10,0.6432846);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(11,0.3736529);
   VHcc_boosted_PN_med_ZMass__822->SetBinError(14,0.2456653);
   VHcc_boosted_PN_med_ZMass__822->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__822->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__822->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__822->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__822->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__822->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__822->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__822->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__822->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__822->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__822->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__822->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__822->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__823 = new TH1D("VHcc_boosted_PN_med_ZMass__823","",30,0,300);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(5,0.1917792);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(7,0.4819582);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(8,0.4069582);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(9,1.780552);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(10,1.93453);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(11,0.6165769);
   VHcc_boosted_PN_med_ZMass__823->SetBinContent(14,0.189742);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(5,0.1917792);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(7,0.3533948);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(8,0.2878341);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(9,0.6418004);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(10,0.6496134);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(11,0.3569379);
   VHcc_boosted_PN_med_ZMass__823->SetBinError(14,0.189742);
   VHcc_boosted_PN_med_ZMass__823->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__823->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__823->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__823->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__823->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__823->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__823->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__823->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__823->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__823->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__823->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__823->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__823->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__328->Modified();
   c1_n44->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__329 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__329->Draw();
   pad1_v2__329->cd();
   pad1_v2__329->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__329->SetFillColor(0);
   pad1_v2__329->SetBorderMode(0);
   pad1_v2__329->SetBorderSize(2);
   pad1_v2__329->SetFrameBorderMode(0);
   pad1_v2__329->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__824 = new TH1D("VHcc_boosted_PN_med_ZMass__824","",30,0,300);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(5,1.007321);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(7,0.9469893);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(8,1.026539);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(9,0.9671823);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(10,0.9885027);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(11,1.013018);
   VHcc_boosted_PN_med_ZMass__824->SetBinContent(14,1.113684);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(5,1.424568);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(7,0.9574511);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(8,1.026628);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(9,0.4863671);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(10,0.4675686);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(11,0.8276096);
   VHcc_boosted_PN_med_ZMass__824->SetBinError(14,1.574987);
   VHcc_boosted_PN_med_ZMass__824->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__824->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__824->SetEntries(6.546497);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__824->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__824->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__824->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__824->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__824->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__824->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__824->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__824->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__825 = new TH1D("VHcc_boosted_PN_med_ZMass__825","",30,0,300);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(5,0.9702498);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(7,1.076763);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(8,0.9492086);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(9,1.033855);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(10,0.9964349);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(11,0.9659072);
   VHcc_boosted_PN_med_ZMass__825->SetBinContent(14,0.8601645);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(5,1.37214);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(7,1.097012);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(8,0.9493261);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(9,0.5225284);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(10,0.4717466);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(11,0.7898548);
   VHcc_boosted_PN_med_ZMass__825->SetBinError(14,1.216456);
   VHcc_boosted_PN_med_ZMass__825->SetEntries(7.129263);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__825->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__825->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__825->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__825->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__825->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__825->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__825->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__825->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__825->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__329->Modified();
   c1_n44->cd();
   c1_n44->Modified();
   c1_n44->SetSelected(c1_n44);
}
