#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_TAG_CC()
{
//=========Macro generated from canvas: c1_n61/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n61 = new TCanvas("c1_n61", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n61->SetHighLightColor(2);
   c1_n61->Range(0,0,1,1);
   c1_n61->SetFillColor(0);
   c1_n61->SetBorderMode(0);
   c1_n61->SetBorderSize(2);
   c1_n61->SetLeftMargin(0.15);
   c1_n61->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__360 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__360->Draw();
   pad1_v1__360->cd();
   pad1_v1__360->Range(-37.5,-0.5300963,337.5,4.770866);
   pad1_v1__360->SetFillColor(0);
   pad1_v1__360->SetBorderMode(0);
   pad1_v1__360->SetBorderSize(2);
   pad1_v1__360->SetFrameBorderMode(0);
   pad1_v1__360->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__901 = new TH1D("VHcc_boosted_PN_med_ZMass__901","",30,0,300);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__901->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__901->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__901->SetMaximum(4.24077);
   VHcc_boosted_PN_med_ZMass__901->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__901->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__901->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__901->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__901->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__901->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__901->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__901->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__901->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__901->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__901->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__901->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__901->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__901->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__901->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__902 = new TH1D("VHcc_boosted_PN_med_ZMass__902","",30,0,300);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(5,0.231099);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(7,0.5075751);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(8,0.4840866);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(9,1.992809);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(10,2.24077);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(11,0.746996);
   VHcc_boosted_PN_med_ZMass__902->SetBinContent(14,0.2498228);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(5,0.231099);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(7,0.3590857);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(8,0.3423203);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(9,0.7071264);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(10,0.7478274);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(11,0.4315078);
   VHcc_boosted_PN_med_ZMass__902->SetBinError(14,0.2498228);
   VHcc_boosted_PN_med_ZMass__902->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__902->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__902->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__902->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__902->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__902->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__902->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__902->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__902->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__902->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__902->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__902->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__902->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__903 = new TH1D("VHcc_boosted_PN_med_ZMass__903","",30,0,300);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(5,0.1659818);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(7,0.3802093);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(8,0.354648);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(9,1.427029);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(10,1.622747);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(11,0.5212614);
   VHcc_boosted_PN_med_ZMass__903->SetBinContent(14,0.1876412);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(5,0.1659818);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(7,0.268892);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(8,0.2508241);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(9,0.5056204);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(10,0.5418556);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(11,0.3013831);
   VHcc_boosted_PN_med_ZMass__903->SetBinError(14,0.1876412);
   VHcc_boosted_PN_med_ZMass__903->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__903->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__903->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__903->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__903->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__903->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__903->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__903->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__903->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__903->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__903->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__903->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__903->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","TAG_CC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","TAG_CC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__360->Modified();
   c1_n61->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__361 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__361->Draw();
   pad1_v2__361->cd();
   pad1_v2__361->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__361->SetFillColor(0);
   pad1_v2__361->SetBorderMode(0);
   pad1_v2__361->SetBorderSize(2);
   pad1_v2__361->SetFrameBorderMode(0);
   pad1_v2__361->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__904 = new TH1D("VHcc_boosted_PN_med_ZMass__904","",30,0,300);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(5,1.169177);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(7,1.133995);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(8,1.129106);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(9,1.157099);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(10,1.154173);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(11,1.170217);
   VHcc_boosted_PN_med_ZMass__904->SetBinContent(14,1.132531);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(5,1.653466);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(7,1.134449);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(8,1.129138);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(9,0.5802056);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(10,0.5447394);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(11,0.955895);
   VHcc_boosted_PN_med_ZMass__904->SetBinError(14,1.601641);
   VHcc_boosted_PN_med_ZMass__904->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__904->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__904->SetEntries(6.881507);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__904->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__904->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__904->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__904->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__904->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__904->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__904->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__904->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__905 = new TH1D("VHcc_boosted_PN_med_ZMass__905","",30,0,300);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(5,0.8397356);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(7,0.8494415);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(8,0.8271978);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(9,0.8285858);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(10,0.8358422);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(11,0.8165893);
   VHcc_boosted_PN_med_ZMass__905->SetBinContent(14,0.8506411);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(5,1.187565);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(7,0.8496423);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(8,0.8272804);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(9,0.4151729);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(10,0.3945996);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(11,0.6673353);
   VHcc_boosted_PN_med_ZMass__905->SetBinError(14,1.202988);
   VHcc_boosted_PN_med_ZMass__905->SetEntries(6.789398);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__905->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__905->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__905->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__905->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__905->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__905->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__905->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__905->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__905->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__361->Modified();
   c1_n61->cd();
   c1_n61->Modified();
   c1_n61->SetSelected(c1_n61);
}
