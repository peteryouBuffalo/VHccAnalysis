#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JER()
{
//=========Macro generated from canvas: c1_n36/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n36 = new TCanvas("c1_n36", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n36->SetHighLightColor(2);
   c1_n36->Range(0,0,1,1);
   c1_n36->SetFillColor(0);
   c1_n36->SetBorderMode(0);
   c1_n36->SetBorderSize(2);
   c1_n36->SetLeftMargin(0.15);
   c1_n36->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__312 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__312->Draw();
   pad1_v1__312->cd();
   pad1_v1__312->Range(-37.5,-0.4705786,337.5,4.235208);
   pad1_v1__312->SetFillColor(0);
   pad1_v1__312->SetBorderMode(0);
   pad1_v1__312->SetBorderSize(2);
   pad1_v1__312->SetFrameBorderMode(0);
   pad1_v1__312->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__781 = new TH1D("VHcc_boosted_PN_med_HMass__781","",30,0,300);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__781->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__781->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__781->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__781->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__781->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__781->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__781->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__781->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__781->SetMaximum(3.764629);
   VHcc_boosted_PN_med_HMass__781->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__781->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__781->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__781->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__781->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__781->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__781->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__781->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__781->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__781->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__781->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__781->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__781->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__781->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__781->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__782 = new TH1D("VHcc_boosted_PN_med_HMass__782","",30,0,300);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__782->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__782->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__782->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__782->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__782->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__782->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__782->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__782->SetEntries(25);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__782->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__782->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__782->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__782->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__782->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__782->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__782->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__782->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__782->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__782->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__782->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__782->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__783 = new TH1D("VHcc_boosted_PN_med_HMass__783","",30,0,300);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(10,1.764629);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(11,1.50211);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__783->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__783->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__783->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__783->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__783->SetBinError(10,0.6251129);
   VHcc_boosted_PN_med_HMass__783->SetBinError(11,0.5687506);
   VHcc_boosted_PN_med_HMass__783->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__783->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__783->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__783->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__783->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__783->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__783->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__783->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__783->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__783->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__783->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__783->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__783->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__783->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__783->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","JER Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","JER Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__312->Modified();
   c1_n36->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__313 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__313->Draw();
   pad1_v2__313->cd();
   pad1_v2__313->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__313->SetFillColor(0);
   pad1_v2__313->SetBorderMode(0);
   pad1_v2__313->SetBorderSize(2);
   pad1_v2__313->SetFrameBorderMode(0);
   pad1_v2__313->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__784 = new TH1D("VHcc_boosted_PN_med_HMass__784","",30,0,300);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(9,1);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(10,1);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(11,1);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(12,1);
   VHcc_boosted_PN_med_HMass__784->SetBinContent(15,1);
   VHcc_boosted_PN_med_HMass__784->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__784->SetBinError(9,0.5350115);
   VHcc_boosted_PN_med_HMass__784->SetBinError(10,0.5004284);
   VHcc_boosted_PN_med_HMass__784->SetBinError(11,0.5356774);
   VHcc_boosted_PN_med_HMass__784->SetBinError(12,1.414214);
   VHcc_boosted_PN_med_HMass__784->SetBinError(15,1.414214);
   VHcc_boosted_PN_med_HMass__784->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__784->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__784->SetEntries(5.275795);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__784->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__784->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__784->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__784->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__784->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__784->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__784->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__784->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__785 = new TH1D("VHcc_boosted_PN_med_HMass__785","",30,0,300);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(8,1);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(9,1);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(10,1.013507);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(11,1.013883);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(12,1);
   VHcc_boosted_PN_med_HMass__785->SetBinContent(15,1);
   VHcc_boosted_PN_med_HMass__785->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__785->SetBinError(8,1.414214);
   VHcc_boosted_PN_med_HMass__785->SetBinError(9,0.5350115);
   VHcc_boosted_PN_med_HMass__785->SetBinError(10,0.5074673);
   VHcc_boosted_PN_med_HMass__785->SetBinError(11,0.5430092);
   VHcc_boosted_PN_med_HMass__785->SetBinError(12,1.414214);
   VHcc_boosted_PN_med_HMass__785->SetBinError(15,1.414214);
   VHcc_boosted_PN_med_HMass__785->SetEntries(5.587323);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__785->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__785->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__785->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__785->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__785->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__785->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__785->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__785->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__785->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__313->Modified();
   c1_n36->cd();
   c1_n36->Modified();
   c1_n36->SetSelected(c1_n36);
}
