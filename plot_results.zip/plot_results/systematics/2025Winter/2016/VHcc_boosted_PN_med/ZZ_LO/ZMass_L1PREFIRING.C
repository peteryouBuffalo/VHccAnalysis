#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_L1PREFIRING()
{
//=========Macro generated from canvas: c1_n56/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n56 = new TCanvas("c1_n56", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n56->SetHighLightColor(2);
   c1_n56->Range(0,0,1,1);
   c1_n56->SetFillColor(0);
   c1_n56->SetBorderMode(0);
   c1_n56->SetBorderSize(2);
   c1_n56->SetLeftMargin(0.15);
   c1_n56->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__352 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__352->Draw();
   pad1_v1__352->cd();
   pad1_v1__352->Range(-37.5,-0.4929041,337.5,4.436136);
   pad1_v1__352->SetFillColor(0);
   pad1_v1__352->SetBorderMode(0);
   pad1_v1__352->SetBorderSize(2);
   pad1_v1__352->SetFrameBorderMode(0);
   pad1_v1__352->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__881 = new TH1D("VHcc_boosted_PN_med_ZMass__881","",30,0,300);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__881->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__881->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__881->SetMaximum(3.943232);
   VHcc_boosted_PN_med_ZMass__881->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__881->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__881->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__881->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__881->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__881->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__881->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__881->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__881->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__881->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__881->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__881->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__881->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__881->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__881->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__882 = new TH1D("VHcc_boosted_PN_med_ZMass__882","",30,0,300);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(8,0.4274406);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(9,1.718096);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(10,1.939674);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(11,0.6375795);
   VHcc_boosted_PN_med_ZMass__882->SetBinContent(14,0.2199515);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(8,0.3022462);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(9,0.608782);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(10,0.6473507);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(11,0.3682289);
   VHcc_boosted_PN_med_ZMass__882->SetBinError(14,0.2199515);
   VHcc_boosted_PN_med_ZMass__882->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__882->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__882->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__882->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__882->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__882->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__882->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__882->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__882->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__882->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__882->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__882->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__882->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__883 = new TH1D("VHcc_boosted_PN_med_ZMass__883","",30,0,300);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(8,0.429672);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(9,1.723463);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(10,1.943232);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(11,0.6388678);
   VHcc_boosted_PN_med_ZMass__883->SetBinContent(14,0.2212245);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(8,0.3038241);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(9,0.6106217);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(10,0.6485143);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(11,0.3689788);
   VHcc_boosted_PN_med_ZMass__883->SetBinError(14,0.2212245);
   VHcc_boosted_PN_med_ZMass__883->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__883->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__883->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__883->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__883->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__883->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__883->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__883->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__883->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__883->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__883->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__883->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__883->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","L1PREFIRING Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","L1PREFIRING Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__352->Modified();
   c1_n56->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__353 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__353->Draw();
   pad1_v2__353->cd();
   pad1_v2__353->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__353->SetFillColor(0);
   pad1_v2__353->SetBorderMode(0);
   pad1_v2__353->SetBorderSize(2);
   pad1_v2__353->SetFrameBorderMode(0);
   pad1_v2__353->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__884 = new TH1D("VHcc_boosted_PN_med_ZMass__884","",30,0,300);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(7,1);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(8,0.9969827);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(9,0.9975907);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(10,0.9990846);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(11,0.9988091);
   VHcc_boosted_PN_med_ZMass__884->SetBinContent(14,0.9971146);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(7,1.000311);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(8,0.9969828);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(9,0.4998676);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(10,0.4715456);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(11,0.8157984);
   VHcc_boosted_PN_med_ZMass__884->SetBinError(14,1.410133);
   VHcc_boosted_PN_med_ZMass__884->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__884->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__884->SetEntries(6.86076);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__884->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__884->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__884->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__884->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__884->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__884->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__884->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__884->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__885 = new TH1D("VHcc_boosted_PN_med_ZMass__885","",30,0,300);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(7,1);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(8,1.002187);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(9,1.000707);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(10,1.000917);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(11,1.000827);
   VHcc_boosted_PN_med_ZMass__885->SetBinContent(14,1.002885);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(7,1.000311);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(8,1.002187);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(9,0.5014036);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(10,0.4724019);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(11,0.8174533);
   VHcc_boosted_PN_med_ZMass__885->SetBinError(14,1.418294);
   VHcc_boosted_PN_med_ZMass__885->SetEntries(6.858909);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__885->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__885->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__885->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__885->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__885->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__885->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__885->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__885->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__885->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__353->Modified();
   c1_n56->cd();
   c1_n56->Modified();
   c1_n56->SetSelected(c1_n56);
}
