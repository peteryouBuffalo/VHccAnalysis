#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_MUON()
{
//=========Macro generated from canvas: c1_n52/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n52 = new TCanvas("c1_n52", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n52->SetHighLightColor(2);
   c1_n52->Range(0,0,1,1);
   c1_n52->SetFillColor(0);
   c1_n52->SetBorderMode(0);
   c1_n52->SetBorderSize(2);
   c1_n52->SetLeftMargin(0.15);
   c1_n52->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__344 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__344->Draw();
   pad1_v1__344->cd();
   pad1_v1__344->Range(-37.5,-0.4928489,337.5,4.43564);
   pad1_v1__344->SetFillColor(0);
   pad1_v1__344->SetBorderMode(0);
   pad1_v1__344->SetBorderSize(2);
   pad1_v1__344->SetFrameBorderMode(0);
   pad1_v1__344->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__861 = new TH1D("VHcc_boosted_PN_med_ZMass__861","",30,0,300);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__861->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__861->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__861->SetMaximum(3.942791);
   VHcc_boosted_PN_med_ZMass__861->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__861->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__861->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__861->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__861->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__861->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__861->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__861->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__861->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__861->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__861->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__861->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__861->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__861->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__861->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__862 = new TH1D("VHcc_boosted_PN_med_ZMass__862","",30,0,300);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(5,0.1983397);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(8,0.4289303);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(9,1.725328);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(10,1.942791);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(11,0.6400842);
   VHcc_boosted_PN_med_ZMass__862->SetBinContent(14,0.2212433);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(5,0.1983397);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(8,0.3032995);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(9,0.6112822);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(10,0.6483702);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(11,0.3696848);
   VHcc_boosted_PN_med_ZMass__862->SetBinError(14,0.2212433);
   VHcc_boosted_PN_med_ZMass__862->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__862->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__862->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__862->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__862->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__862->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__862->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__862->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__862->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__862->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__862->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__862->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__862->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__863 = new TH1D("VHcc_boosted_PN_med_ZMass__863","",30,0,300);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(5,0.196981);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(8,0.4285383);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(9,1.719169);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(10,1.940114);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(11,0.6366048);
   VHcc_boosted_PN_med_ZMass__863->SetBinContent(14,0.2199338);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(5,0.196981);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(8,0.3030224);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(9,0.6090761);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(10,0.6474929);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(11,0.367667);
   VHcc_boosted_PN_med_ZMass__863->SetBinError(14,0.2199338);
   VHcc_boosted_PN_med_ZMass__863->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__863->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__863->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__863->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__863->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__863->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__863->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__863->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__863->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__863->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__863->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__863->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__863->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","MUON Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","MUON Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__344->Modified();
   c1_n52->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__345 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__345->Draw();
   pad1_v2__345->cd();
   pad1_v2__345->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__345->SetFillColor(0);
   pad1_v2__345->SetBorderMode(0);
   pad1_v2__345->SetBorderSize(2);
   pad1_v2__345->SetFrameBorderMode(0);
   pad1_v2__345->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__864 = new TH1D("VHcc_boosted_PN_med_ZMass__864","",30,0,300);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(5,1.003441);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(7,1);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(8,1.000457);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(9,1.00179);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(10,1.00069);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(11,1.002733);
   VHcc_boosted_PN_med_ZMass__864->SetBinContent(14,1.002971);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(5,1.419079);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(7,1.000311);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(8,1.000457);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(9,0.5019461);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(10,0.4722958);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(11,0.8190135);
   VHcc_boosted_PN_med_ZMass__864->SetBinError(14,1.418415);
   VHcc_boosted_PN_med_ZMass__864->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__864->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__864->SetEntries(6.854754);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__864->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__864->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__864->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__864->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__864->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__864->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__864->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__864->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__865 = new TH1D("VHcc_boosted_PN_med_ZMass__865","",30,0,300);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(5,0.9965671);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(7,1);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(8,0.9995429);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(9,0.9982136);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(10,0.9993111);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(11,0.9972821);
   VHcc_boosted_PN_med_ZMass__865->SetBinContent(14,0.9970343);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(5,1.409359);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(7,1.000311);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(8,0.9995429);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(9,0.5001444);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(10,0.4716508);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(11,0.8145524);
   VHcc_boosted_PN_med_ZMass__865->SetBinError(14,1.410019);
   VHcc_boosted_PN_med_ZMass__865->SetEntries(6.867756);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__865->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__865->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__865->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__865->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__865->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__865->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__865->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__865->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__865->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__345->Modified();
   c1_n52->cd();
   c1_n52->Modified();
   c1_n52->SetSelected(c1_n52);
}
