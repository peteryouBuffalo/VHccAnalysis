#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JER()
{
//=========Macro generated from canvas: c1_n10/
//=========  (Fri Feb 28 12:19:08 2025) by ROOT version 6.30/03
   TCanvas *c1_n10 = new TCanvas("c1_n10", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n10->SetHighLightColor(2);
   c1_n10->Range(0,0,1,1);
   c1_n10->SetFillColor(0);
   c1_n10->SetBorderMode(0);
   c1_n10->SetBorderSize(2);
   c1_n10->SetLeftMargin(0.15);
   c1_n10->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__376 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__376->Draw();
   pad1_v1__376->cd();
   pad1_v1__376->Range(-37.5,-0.4926815,337.5,4.434133);
   pad1_v1__376->SetFillColor(0);
   pad1_v1__376->SetBorderMode(0);
   pad1_v1__376->SetBorderSize(2);
   pad1_v1__376->SetFrameBorderMode(0);
   pad1_v1__376->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__941 = new TH1D("VHcc_boosted_PN_med_ZMass__941","",30,0,300);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(7,0.4475991);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__941->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(7,0.3165989);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__941->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__941->SetMaximum(3.941451);
   VHcc_boosted_PN_med_ZMass__941->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_ZMass__941->SetFillColor(ci);
   VHcc_boosted_PN_med_ZMass__941->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__941->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__941->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__941->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__941->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_ZMass__941->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__941->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_ZMass__941->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__941->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__941->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__941->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__941->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__941->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__942 = new TH1D("VHcc_boosted_PN_med_ZMass__942","",30,0,300);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(7,0.229383);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(8,0.4287343);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(9,1.722246);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(10,1.719419);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(11,0.641937);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(12,0.218435);
   VHcc_boosted_PN_med_ZMass__942->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(5,0.1976596);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(7,0.229383);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(8,0.3031609);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(9,0.6101775);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(10,0.6087001);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(11,0.3708138);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(12,0.218435);
   VHcc_boosted_PN_med_ZMass__942->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__942->SetEntries(25);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__942->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__942->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__942->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__942->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__942->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__942->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__942->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__942->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__942->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__942->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__942->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__942->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__943 = new TH1D("VHcc_boosted_PN_med_ZMass__943","",30,0,300);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(5,0.2182285);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(7,0.229383);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(8,0.6469504);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(9,1.745764);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(10,1.941451);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(11,0.6383397);
   VHcc_boosted_PN_med_ZMass__943->SetBinContent(14,0.220588);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(5,0.2182285);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(7,0.229383);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(8,0.3735302);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(9,0.6192734);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(10,0.6479306);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(11,0.3686711);
   VHcc_boosted_PN_med_ZMass__943->SetBinError(14,0.220588);
   VHcc_boosted_PN_med_ZMass__943->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__943->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__943->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__943->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__943->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__943->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__943->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__943->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__943->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__943->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__943->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__943->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__943->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","JER Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_ZMass","JER Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__376->Modified();
   c1_n10->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__377 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__377->Draw();
   pad1_v2__377->cd();
   pad1_v2__377->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__377->SetFillColor(0);
   pad1_v2__377->SetBorderMode(0);
   pad1_v2__377->SetBorderSize(2);
   pad1_v2__377->SetFrameBorderMode(0);
   pad1_v2__377->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_ZMass__944 = new TH1D("VHcc_boosted_PN_med_ZMass__944","",30,0,300);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(5,1);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(7,0.5124741);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(8,1);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(9,1);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(10,0.8856359);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(11,1.005635);
   VHcc_boosted_PN_med_ZMass__944->SetBinContent(14,1);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(5,1.414214);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(7,0.6277152);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(8,1);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(9,0.5010441);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(10,0.4308833);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(11,0.8214495);
   VHcc_boosted_PN_med_ZMass__944->SetBinError(14,1.414214);
   VHcc_boosted_PN_med_ZMass__944->SetMinimum(0.8);
   VHcc_boosted_PN_med_ZMass__944->SetMaximum(1.2);
   VHcc_boosted_PN_med_ZMass__944->SetEntries(6.303572);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_ZMass__944->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__944->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__944->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_ZMass__944->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__944->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__944->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__944->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__944->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_ZMass__945 = new TH1D("VHcc_boosted_PN_med_ZMass__945","",30,0,300);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(5,1.104062);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(7,0.5124741);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(8,1.508978);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(9,1.013655);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(10,1);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(11,1);
   VHcc_boosted_PN_med_ZMass__945->SetBinContent(14,1);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(5,1.56138);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(7,0.6277152);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(8,1.377521);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(9,0.5081997);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(10,0.4719728);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(11,0.8167745);
   VHcc_boosted_PN_med_ZMass__945->SetBinError(14,1.414214);
   VHcc_boosted_PN_med_ZMass__945->SetEntries(6.469922);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_ZMass__945->SetLineColor(ci);
   VHcc_boosted_PN_med_ZMass__945->SetLineWidth(2);
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetTitle("M_{Z} [GeV]");
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__945->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__945->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__945->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__945->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_ZMass__945->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_ZMass__945->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_ZMass__945->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__377->Modified();
   c1_n10->cd();
   c1_n10->Modified();
   c1_n10->SetSelected(c1_n10);
}
