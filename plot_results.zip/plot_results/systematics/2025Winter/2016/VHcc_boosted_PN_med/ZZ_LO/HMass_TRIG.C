#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_TRIG()
{
//=========Macro generated from canvas: c1_n32/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n32 = new TCanvas("c1_n32", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n32->SetHighLightColor(2);
   c1_n32->Range(0,0,1,1);
   c1_n32->SetFillColor(0);
   c1_n32->SetBorderMode(0);
   c1_n32->SetBorderSize(2);
   c1_n32->SetLeftMargin(0.15);
   c1_n32->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__304 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__304->Draw();
   pad1_v1__304->cd();
   pad1_v1__304->Range(-37.5,-0.4791933,337.5,4.312739);
   pad1_v1__304->SetFillColor(0);
   pad1_v1__304->SetBorderMode(0);
   pad1_v1__304->SetBorderSize(2);
   pad1_v1__304->SetFrameBorderMode(0);
   pad1_v1__304->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__761 = new TH1D("VHcc_boosted_PN_med_HMass__761","",30,0,300);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__761->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__761->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__761->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__761->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__761->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__761->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__761->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__761->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__761->SetMaximum(3.833546);
   VHcc_boosted_PN_med_HMass__761->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__761->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__761->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__761->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__761->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__761->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__761->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__761->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__761->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__761->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__761->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__761->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__761->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__761->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__761->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__762 = new TH1D("VHcc_boosted_PN_med_HMass__762","",30,0,300);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(7,0.2245404);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(8,0.2236342);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(9,1.628982);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(10,1.833546);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(11,1.543676);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(12,0.2043071);
   VHcc_boosted_PN_med_HMass__762->SetBinContent(15,0.226981);
   VHcc_boosted_PN_med_HMass__762->SetBinError(7,0.2245404);
   VHcc_boosted_PN_med_HMass__762->SetBinError(8,0.2236342);
   VHcc_boosted_PN_med_HMass__762->SetBinError(9,0.6167339);
   VHcc_boosted_PN_med_HMass__762->SetBinError(10,0.6491986);
   VHcc_boosted_PN_med_HMass__762->SetBinError(11,0.5847604);
   VHcc_boosted_PN_med_HMass__762->SetBinError(12,0.2043071);
   VHcc_boosted_PN_med_HMass__762->SetBinError(15,0.226981);
   VHcc_boosted_PN_med_HMass__762->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__762->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__762->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__762->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__762->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__762->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__762->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__762->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__762->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__762->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__762->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__762->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__762->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__763 = new TH1D("VHcc_boosted_PN_med_HMass__763","",30,0,300);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(7,0.2118919);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(8,0.2110368);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(9,1.415955);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(10,1.648676);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(11,1.419407);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(12,0.1864082);
   VHcc_boosted_PN_med_HMass__763->SetBinContent(15,0.214195);
   VHcc_boosted_PN_med_HMass__763->SetBinError(7,0.2118919);
   VHcc_boosted_PN_med_HMass__763->SetBinError(8,0.2110368);
   VHcc_boosted_PN_med_HMass__763->SetBinError(9,0.5366234);
   VHcc_boosted_PN_med_HMass__763->SetBinError(10,0.5839209);
   VHcc_boosted_PN_med_HMass__763->SetBinError(11,0.5377156);
   VHcc_boosted_PN_med_HMass__763->SetBinError(12,0.1864082);
   VHcc_boosted_PN_med_HMass__763->SetBinError(15,0.214195);
   VHcc_boosted_PN_med_HMass__763->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__763->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__763->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__763->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__763->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__763->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__763->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__763->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__763->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__763->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__763->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__763->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__763->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","TRIG Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","TRIG Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__304->Modified();
   c1_n32->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__305 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__305->Draw();
   pad1_v2__305->cd();
   pad1_v2__305->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__305->SetFillColor(0);
   pad1_v2__305->SetBorderMode(0);
   pad1_v2__305->SetBorderSize(2);
   pad1_v2__305->SetFrameBorderMode(0);
   pad1_v2__305->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__764 = new TH1D("VHcc_boosted_PN_med_HMass__764","",30,0,300);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(7,1.028981);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(8,1.028982);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(9,1.069961);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(10,1.05309);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(11,1.041939);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(12,1.04581);
   VHcc_boosted_PN_med_HMass__764->SetBinContent(15,1.028981);
   VHcc_boosted_PN_med_HMass__764->SetBinError(7,1.4552);
   VHcc_boosted_PN_med_HMass__764->SetBinError(8,1.4552);
   VHcc_boosted_PN_med_HMass__764->SetBinError(9,0.5726614);
   VHcc_boosted_PN_med_HMass__764->SetBinError(10,0.5271531);
   VHcc_boosted_PN_med_HMass__764->SetBinError(11,0.5581647);
   VHcc_boosted_PN_med_HMass__764->SetBinError(12,1.478999);
   VHcc_boosted_PN_med_HMass__764->SetBinError(15,1.4552);
   VHcc_boosted_PN_med_HMass__764->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__764->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__764->SetEntries(5.63112);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__764->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__764->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__764->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__764->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__764->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__764->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__764->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__764->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__765 = new TH1D("VHcc_boosted_PN_med_HMass__765","",30,0,300);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(7,0.9710185);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(8,0.9710185);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(9,0.9300389);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(10,0.9469104);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(11,0.9580609);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(12,0.9541896);
   VHcc_boosted_PN_med_HMass__765->SetBinContent(15,0.9710184);
   VHcc_boosted_PN_med_HMass__765->SetBinError(7,1.373228);
   VHcc_boosted_PN_med_HMass__765->SetBinError(8,1.373228);
   VHcc_boosted_PN_med_HMass__765->SetBinError(9,0.4980244);
   VHcc_boosted_PN_med_HMass__765->SetBinError(10,0.4740747);
   VHcc_boosted_PN_med_HMass__765->SetBinError(11,0.5132455);
   VHcc_boosted_PN_med_HMass__765->SetBinError(12,1.349428);
   VHcc_boosted_PN_med_HMass__765->SetBinError(15,1.373227);
   VHcc_boosted_PN_med_HMass__765->SetEntries(5.468464);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__765->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__765->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__765->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__765->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__765->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__765->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__765->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__765->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__765->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__305->Modified();
   c1_n32->cd();
   c1_n32->Modified();
   c1_n32->SetSelected(c1_n32);
}
