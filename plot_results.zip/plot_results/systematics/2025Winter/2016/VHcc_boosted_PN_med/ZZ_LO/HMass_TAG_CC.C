#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_TAG_CC()
{
//=========Macro generated from canvas: c1_n28/
//=========  (Fri Feb 28 12:19:07 2025) by ROOT version 6.30/03
   TCanvas *c1_n28 = new TCanvas("c1_n28", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n28->SetHighLightColor(2);
   c1_n28->Range(0,0,1,1);
   c1_n28->SetFillColor(0);
   c1_n28->SetBorderMode(0);
   c1_n28->SetBorderSize(2);
   c1_n28->SetLeftMargin(0.15);
   c1_n28->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__296 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__296->Draw();
   pad1_v1__296->cd();
   pad1_v1__296->Range(-37.5,-0.5002364,337.5,4.502127);
   pad1_v1__296->SetFillColor(0);
   pad1_v1__296->SetBorderMode(0);
   pad1_v1__296->SetBorderSize(2);
   pad1_v1__296->SetFrameBorderMode(0);
   pad1_v1__296->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__741 = new TH1D("VHcc_boosted_PN_med_HMass__741","",30,0,300);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__741->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__741->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__741->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__741->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__741->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__741->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__741->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__741->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__741->SetMaximum(4.001891);
   VHcc_boosted_PN_med_HMass__741->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__741->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__741->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__741->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__741->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__741->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__741->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__741->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__741->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__741->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__741->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__741->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__741->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__741->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__741->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__742 = new TH1D("VHcc_boosted_PN_med_HMass__742","",30,0,300);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(7,0.2458407);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(8,0.2479877);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(9,1.776878);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(10,2.001891);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(11,1.720641);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(12,0.2100977);
   VHcc_boosted_PN_med_HMass__742->SetBinContent(15,0.2498228);
   VHcc_boosted_PN_med_HMass__742->SetBinError(7,0.2458407);
   VHcc_boosted_PN_med_HMass__742->SetBinError(8,0.2479877);
   VHcc_boosted_PN_med_HMass__742->SetBinError(9,0.6722314);
   VHcc_boosted_PN_med_HMass__742->SetBinError(10,0.7085419);
   VHcc_boosted_PN_med_HMass__742->SetBinError(11,0.6519215);
   VHcc_boosted_PN_med_HMass__742->SetBinError(12,0.2100977);
   VHcc_boosted_PN_med_HMass__742->SetBinError(15,0.2498228);
   VHcc_boosted_PN_med_HMass__742->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__742->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__742->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__742->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__742->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__742->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__742->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__742->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__742->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__742->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__742->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__742->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__742->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__743 = new TH1D("VHcc_boosted_PN_med_HMass__743","",30,0,300);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(7,0.1866857);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(8,0.1833595);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(9,1.248092);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(10,1.447679);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(11,1.229963);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(12,0.1760965);
   VHcc_boosted_PN_med_HMass__743->SetBinContent(15,0.1876412);
   VHcc_boosted_PN_med_HMass__743->SetBinError(7,0.1866857);
   VHcc_boosted_PN_med_HMass__743->SetBinError(8,0.1833595);
   VHcc_boosted_PN_med_HMass__743->SetBinError(9,0.4728048);
   VHcc_boosted_PN_med_HMass__743->SetBinError(10,0.5126979);
   VHcc_boosted_PN_med_HMass__743->SetBinError(11,0.4658016);
   VHcc_boosted_PN_med_HMass__743->SetBinError(12,0.1760965);
   VHcc_boosted_PN_med_HMass__743->SetBinError(15,0.1876412);
   VHcc_boosted_PN_med_HMass__743->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__743->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__743->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__743->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__743->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__743->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__743->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__743->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__743->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__743->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__743->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__743->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__743->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","TAG_CC Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","TAG_CC Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__296->Modified();
   c1_n28->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__297 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__297->Draw();
   pad1_v2__297->cd();
   pad1_v2__297->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__297->SetFillColor(0);
   pad1_v2__297->SetBorderMode(0);
   pad1_v2__297->SetBorderSize(2);
   pad1_v2__297->SetFrameBorderMode(0);
   pad1_v2__297->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__744 = new TH1D("VHcc_boosted_PN_med_HMass__744","",30,0,300);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(7,1.126593);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(8,1.141037);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(9,1.167103);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(10,1.149778);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(11,1.161385);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(12,1.075452);
   VHcc_boosted_PN_med_HMass__744->SetBinContent(15,1.132531);
   VHcc_boosted_PN_med_HMass__744->SetBinError(7,1.593243);
   VHcc_boosted_PN_med_HMass__744->SetBinError(8,1.613669);
   VHcc_boosted_PN_med_HMass__744->SetBinError(9,0.6244232);
   VHcc_boosted_PN_med_HMass__744->SetBinError(10,0.5754465);
   VHcc_boosted_PN_med_HMass__744->SetBinError(11,0.6222116);
   VHcc_boosted_PN_med_HMass__744->SetBinError(12,1.520918);
   VHcc_boosted_PN_med_HMass__744->SetBinError(15,1.601641);
   VHcc_boosted_PN_med_HMass__744->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__744->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__744->SetEntries(5.684631);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__744->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__744->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__744->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__744->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__744->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__744->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__744->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__744->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__745 = new TH1D("VHcc_boosted_PN_med_HMass__745","",30,0,300);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(7,0.855508);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(8,0.8436703);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(9,0.8197819);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(10,0.8314685);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(11,0.8301917);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(12,0.9014058);
   VHcc_boosted_PN_med_HMass__745->SetBinContent(15,0.8506411);
   VHcc_boosted_PN_med_HMass__745->SetBinError(7,1.209871);
   VHcc_boosted_PN_med_HMass__745->SetBinError(8,1.19313);
   VHcc_boosted_PN_med_HMass__745->SetBinError(9,0.4388896);
   VHcc_boosted_PN_med_HMass__745->SetBinError(10,0.4162641);
   VHcc_boosted_PN_med_HMass__745->SetBinError(11,0.4446742);
   VHcc_boosted_PN_med_HMass__745->SetBinError(12,1.27478);
   VHcc_boosted_PN_med_HMass__745->SetBinError(15,1.202988);
   VHcc_boosted_PN_med_HMass__745->SetEntries(5.395572);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__745->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__745->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__745->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__745->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__745->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__745->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__745->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__745->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__745->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__297->Modified();
   c1_n28->cd();
   c1_n28->Modified();
   c1_n28->SetSelected(c1_n28);
}
