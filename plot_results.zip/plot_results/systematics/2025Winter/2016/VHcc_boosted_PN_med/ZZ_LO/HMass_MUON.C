#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_MUON()
{
//=========Macro generated from canvas: c1_n20/
//=========  (Fri Feb 28 12:19:06 2025) by ROOT version 6.30/03
   TCanvas *c1_n20 = new TCanvas("c1_n20", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n20->SetHighLightColor(2);
   c1_n20->Range(0,0,1,1);
   c1_n20->SetFillColor(0);
   c1_n20->SetBorderMode(0);
   c1_n20->SetBorderSize(2);
   c1_n20->SetLeftMargin(0.15);
   c1_n20->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__280 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__280->Draw();
   pad1_v1__280->cd();
   pad1_v1__280->Range(-37.5,-0.4680292,337.5,4.212262);
   pad1_v1__280->SetFillColor(0);
   pad1_v1__280->SetBorderMode(0);
   pad1_v1__280->SetBorderSize(2);
   pad1_v1__280->SetFrameBorderMode(0);
   pad1_v1__280->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__701 = new TH1D("VHcc_boosted_PN_med_HMass__701","",30,0,300);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(8,0.2173355);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(9,1.522468);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(10,1.741111);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(11,1.481541);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(12,0.1953577);
   VHcc_boosted_PN_med_HMass__701->SetBinContent(15,0.220588);
   VHcc_boosted_PN_med_HMass__701->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__701->SetBinError(8,0.2173355);
   VHcc_boosted_PN_med_HMass__701->SetBinError(9,0.5759653);
   VHcc_boosted_PN_med_HMass__701->SetBinError(10,0.6161032);
   VHcc_boosted_PN_med_HMass__701->SetBinError(11,0.5611799);
   VHcc_boosted_PN_med_HMass__701->SetBinError(12,0.1953577);
   VHcc_boosted_PN_med_HMass__701->SetBinError(15,0.220588);
   VHcc_boosted_PN_med_HMass__701->SetMaximum(3.744233);
   VHcc_boosted_PN_med_HMass__701->SetEntries(26);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   VHcc_boosted_PN_med_HMass__701->SetFillColor(ci);
   VHcc_boosted_PN_med_HMass__701->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__701->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__701->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__701->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__701->GetXaxis()->SetTitleOffset(1.15);
   VHcc_boosted_PN_med_HMass__701->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__701->GetYaxis()->SetTitle("Events/10.0 GeV");
   VHcc_boosted_PN_med_HMass__701->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__701->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__701->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__701->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__701->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__701->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__702 = new TH1D("VHcc_boosted_PN_med_HMass__702","",30,0,300);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(8,0.2173487);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(9,1.52419);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(10,1.744233);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(11,1.483447);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(12,0.1956378);
   VHcc_boosted_PN_med_HMass__702->SetBinContent(15,0.2212433);
   VHcc_boosted_PN_med_HMass__702->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__702->SetBinError(8,0.2173487);
   VHcc_boosted_PN_med_HMass__702->SetBinError(9,0.5766096);
   VHcc_boosted_PN_med_HMass__702->SetBinError(10,0.6172156);
   VHcc_boosted_PN_med_HMass__702->SetBinError(11,0.5618845);
   VHcc_boosted_PN_med_HMass__702->SetBinError(12,0.1956378);
   VHcc_boosted_PN_med_HMass__702->SetBinError(15,0.2212433);
   VHcc_boosted_PN_med_HMass__702->SetEntries(26);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__702->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__702->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__702->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__702->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__702->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__702->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__702->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__702->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__702->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__702->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__702->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__702->Draw("same hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__703 = new TH1D("VHcc_boosted_PN_med_HMass__703","",30,0,300);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(7,0.2182162);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(8,0.2173223);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(9,1.520756);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(10,1.737995);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(11,1.47964);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(12,0.1950775);
   VHcc_boosted_PN_med_HMass__703->SetBinContent(15,0.2199338);
   VHcc_boosted_PN_med_HMass__703->SetBinError(7,0.2182162);
   VHcc_boosted_PN_med_HMass__703->SetBinError(8,0.2173223);
   VHcc_boosted_PN_med_HMass__703->SetBinError(9,0.5753283);
   VHcc_boosted_PN_med_HMass__703->SetBinError(10,0.6149942);
   VHcc_boosted_PN_med_HMass__703->SetBinError(11,0.560478);
   VHcc_boosted_PN_med_HMass__703->SetBinError(12,0.1950775);
   VHcc_boosted_PN_med_HMass__703->SetBinError(15,0.2199338);
   VHcc_boosted_PN_med_HMass__703->SetEntries(26);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__703->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__703->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__703->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__703->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__703->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__703->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__703->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__703->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__703->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__703->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__703->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__703->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","MUON Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("VHcc_boosted_PN_med_HMass","MUON Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__280->Modified();
   c1_n20->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__281 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__281->Draw();
   pad1_v2__281->cd();
   pad1_v2__281->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__281->SetFillColor(0);
   pad1_v2__281->SetBorderMode(0);
   pad1_v2__281->SetBorderSize(2);
   pad1_v2__281->SetFrameBorderMode(0);
   pad1_v2__281->SetFrameBorderMode(0);
   
   TH1D *VHcc_boosted_PN_med_HMass__704 = new TH1D("VHcc_boosted_PN_med_HMass__704","",30,0,300);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(8,1.000061);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(9,1.001131);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(10,1.001793);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(11,1.001286);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(12,1.001434);
   VHcc_boosted_PN_med_HMass__704->SetBinContent(15,1.002971);
   VHcc_boosted_PN_med_HMass__704->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__704->SetBinError(8,1.4143);
   VHcc_boosted_PN_med_HMass__704->SetBinError(9,0.5356133);
   VHcc_boosted_PN_med_HMass__704->SetBinError(10,0.5013288);
   VHcc_boosted_PN_med_HMass__704->SetBinError(11,0.5363582);
   VHcc_boosted_PN_med_HMass__704->SetBinError(12,1.416242);
   VHcc_boosted_PN_med_HMass__704->SetBinError(15,1.418415);
   VHcc_boosted_PN_med_HMass__704->SetMinimum(0.8);
   VHcc_boosted_PN_med_HMass__704->SetMaximum(1.2);
   VHcc_boosted_PN_med_HMass__704->SetEntries(5.554362);

   ci = TColor::GetColor("#0000ff");
   VHcc_boosted_PN_med_HMass__704->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__704->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetRange(1,30);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetLabelSize(0.1);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__704->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->CenterTitle(true);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetLabelSize(0.09);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetTitleSize(0.12);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetTitleOffset(0.35);
   VHcc_boosted_PN_med_HMass__704->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__704->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__704->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__704->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__704->Draw("hist");
   
   TH1D *VHcc_boosted_PN_med_HMass__705 = new TH1D("VHcc_boosted_PN_med_HMass__705","",30,0,300);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(7,1);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(8,0.9999393);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(9,0.9988754);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(10,0.9982103);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(11,0.9987163);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(12,0.9985661);
   VHcc_boosted_PN_med_HMass__705->SetBinContent(15,0.9970343);
   VHcc_boosted_PN_med_HMass__705->SetBinError(7,1.414214);
   VHcc_boosted_PN_med_HMass__705->SetBinError(8,1.414128);
   VHcc_boosted_PN_med_HMass__705->SetBinError(9,0.5344148);
   VHcc_boosted_PN_med_HMass__705->SetBinError(10,0.4995302);
   VHcc_boosted_PN_med_HMass__705->SetBinError(11,0.5349985);
   VHcc_boosted_PN_med_HMass__705->SetBinError(12,1.412186);
   VHcc_boosted_PN_med_HMass__705->SetBinError(15,1.410019);
   VHcc_boosted_PN_med_HMass__705->SetEntries(5.552186);

   ci = TColor::GetColor("#ff0000");
   VHcc_boosted_PN_med_HMass__705->SetLineColor(ci);
   VHcc_boosted_PN_med_HMass__705->SetLineWidth(2);
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetTitle("M_{H} [GeV]");
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetRange(1,300);
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetTitleSize(0.13);
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__705->GetXaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__705->GetYaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__705->GetYaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__705->GetZaxis()->SetLabelFont(42);
   VHcc_boosted_PN_med_HMass__705->GetZaxis()->SetTitleOffset(1);
   VHcc_boosted_PN_med_HMass__705->GetZaxis()->SetTitleFont(42);
   VHcc_boosted_PN_med_HMass__705->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__281->Modified();
   c1_n20->cd();
   c1_n20->Modified();
   c1_n20->SetSelected(c1_n20);
}
