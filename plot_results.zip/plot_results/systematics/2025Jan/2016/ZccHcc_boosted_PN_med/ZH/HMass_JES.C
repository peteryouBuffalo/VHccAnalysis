#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n15/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n15 = new TCanvas("c1_n15", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n15->SetHighLightColor(2);
   c1_n15->Range(0,0,1,1);
   c1_n15->SetFillColor(0);
   c1_n15->SetBorderMode(0);
   c1_n15->SetBorderSize(2);
   c1_n15->SetLeftMargin(0.15);
   c1_n15->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__160 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__160->Draw();
   pad1_v1__160->cd();
   pad1_v1__160->Range(-37.5,-3.433886,337.5,30.90497);
   pad1_v1__160->SetFillColor(0);
   pad1_v1__160->SetBorderMode(0);
   pad1_v1__160->SetBorderSize(2);
   pad1_v1__160->SetFrameBorderMode(0);
   pad1_v1__160->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__401 = new TH1D("ZccHcc_boosted_PN_med_HMass__401","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(9,2.99403);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(10,2.884683);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(11,1.475392);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(12,11.18384);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(13,25.0175);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(14,19.72229);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(15,4.424333);
   ZccHcc_boosted_PN_med_HMass__401->SetBinContent(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(9,2.118151);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(10,2.040092);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(11,1.475392);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(12,3.981275);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(13,6.074113);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(14,5.220836);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(15,2.560042);
   ZccHcc_boosted_PN_med_HMass__401->SetBinError(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__401->SetMaximum(27.47109);
   ZccHcc_boosted_PN_med_HMass__401->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__401->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__401->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__401->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__401->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__401->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__401->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__401->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__401->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__401->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__401->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__401->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__401->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__401->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__401->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__402 = new TH1D("ZccHcc_boosted_PN_med_HMass__402","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(9,2.99403);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(10,2.797077);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(11,2.94299);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(12,15.33857);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(13,25.47109);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(14,21.00071);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(15,4.424333);
   ZccHcc_boosted_PN_med_HMass__402->SetBinContent(17,2.600336);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(9,2.118151);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(10,1.978006);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(11,2.081015);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(12,4.655561);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(13,6.175783);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(14,5.37508);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(15,2.560042);
   ZccHcc_boosted_PN_med_HMass__402->SetBinError(17,1.846136);
   ZccHcc_boosted_PN_med_HMass__402->SetEntries(60);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__402->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__402->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__402->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__402->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__402->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__402->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__402->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__402->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__402->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__402->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__402->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__402->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__403 = new TH1D("ZccHcc_boosted_PN_med_HMass__403","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(9,2.99403);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(10,2.884683);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(11,1.336331);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(12,12.20927);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(13,23.45986);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(14,21.46781);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(15,1.607784);
   ZccHcc_boosted_PN_med_HMass__403->SetBinContent(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(9,2.118151);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(10,2.040092);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(11,1.336331);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(12,4.099887);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(13,5.915869);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(14,5.48562);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(15,1.607784);
   ZccHcc_boosted_PN_med_HMass__403->SetBinError(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__403->SetEntries(52);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__403->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__403->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__403->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__403->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__403->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__403->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__403->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__403->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__403->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__403->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__403->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__403->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__160->Modified();
   c1_n15->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__161 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__161->Draw();
   pad1_v2__161->cd();
   pad1_v2__161->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__161->SetFillColor(0);
   pad1_v2__161->SetBorderMode(0);
   pad1_v2__161->SetBorderSize(2);
   pad1_v2__161->SetFrameBorderMode(0);
   pad1_v2__161->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__404 = new TH1D("ZccHcc_boosted_PN_med_HMass__404","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(10,0.9696307);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(11,1.994717);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(12,1.371494);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(13,1.018131);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(14,1.064821);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(15,1);
   ZccHcc_boosted_PN_med_HMass__404->SetBinContent(17,2.197633);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(10,0.9697477);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(11,2.443023);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(12,0.6416032);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(13,0.3493497);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(14,0.3920862);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(15,0.8183031);
   ZccHcc_boosted_PN_med_HMass__404->SetBinError(17,2.695166);
   ZccHcc_boosted_PN_med_HMass__404->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__404->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__404->SetEntries(6.818119);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__404->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__404->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__404->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__404->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__404->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__404->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__404->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__404->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__405 = new TH1D("ZccHcc_boosted_PN_med_HMass__405","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(11,0.9057462);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(12,1.091689);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(13,0.9377378);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(14,1.088505);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(15,0.3633957);
   ZccHcc_boosted_PN_med_HMass__405->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(9,1.000497);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(10,1.000153);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(11,1.280919);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(12,0.5342446);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(13,0.3282602);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(14,0.4004895);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(15,0.4198456);
   ZccHcc_boosted_PN_med_HMass__405->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__405->SetEntries(8.564002);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__405->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__405->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__405->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__405->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__405->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__405->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__405->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__405->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__405->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__161->Modified();
   c1_n15->cd();
   c1_n15->Modified();
   c1_n15->SetSelected(c1_n15);
}
