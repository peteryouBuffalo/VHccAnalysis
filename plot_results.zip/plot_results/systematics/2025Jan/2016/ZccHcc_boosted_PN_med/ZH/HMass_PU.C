#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_PU()
{
//=========Macro generated from canvas: c1_n19/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n19 = new TCanvas("c1_n19", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n19->SetHighLightColor(2);
   c1_n19->Range(0,0,1,1);
   c1_n19->SetFillColor(0);
   c1_n19->SetBorderMode(0);
   c1_n19->SetBorderSize(2);
   c1_n19->SetLeftMargin(0.15);
   c1_n19->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__168 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__168->Draw();
   pad1_v1__168->cd();
   pad1_v1__168->Range(-37.5,-3.457749,337.5,31.11974);
   pad1_v1__168->SetFillColor(0);
   pad1_v1__168->SetBorderMode(0);
   pad1_v1__168->SetBorderSize(2);
   pad1_v1__168->SetFrameBorderMode(0);
   pad1_v1__168->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__421 = new TH1D("ZccHcc_boosted_PN_med_HMass__421","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(9,2.99403);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(10,2.884683);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(11,1.475392);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(12,11.18384);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(13,25.0175);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(14,19.72229);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(15,4.424333);
   ZccHcc_boosted_PN_med_HMass__421->SetBinContent(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(9,2.118151);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(10,2.040092);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(11,1.475392);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(12,3.981275);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(13,6.074113);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(14,5.220836);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(15,2.560042);
   ZccHcc_boosted_PN_med_HMass__421->SetBinError(17,1.183244);
   ZccHcc_boosted_PN_med_HMass__421->SetMaximum(27.66199);
   ZccHcc_boosted_PN_med_HMass__421->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__421->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__421->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__421->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__421->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__421->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__421->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__421->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__421->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__421->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__421->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__421->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__421->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__421->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__421->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__422 = new TH1D("ZccHcc_boosted_PN_med_HMass__422","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(9,2.51478);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(10,2.591576);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(11,1.138448);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(12,9.798762);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(13,24.31857);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(14,19.83957);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(15,3.880042);
   ZccHcc_boosted_PN_med_HMass__422->SetBinContent(17,1.48716);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(9,1.778726);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(10,1.833745);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(11,1.138448);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(12,3.498851);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(13,5.733398);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(14,5.18066);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(15,2.270256);
   ZccHcc_boosted_PN_med_HMass__422->SetBinError(17,1.48716);
   ZccHcc_boosted_PN_med_HMass__422->SetEntries(54);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__422->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__422->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__422->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__422->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__422->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__422->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__422->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__422->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__422->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__422->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__422->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__422->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__423 = new TH1D("ZccHcc_boosted_PN_med_HMass__423","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(9,3.52661);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(10,3.148178);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(11,1.892567);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(12,12.95305);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(13,25.66199);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(14,19.71401);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(15,5.0148);
   ZccHcc_boosted_PN_med_HMass__423->SetBinContent(17,0.8749489);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(9,2.505058);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(10,2.230781);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(11,1.892567);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(12,4.734913);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(13,6.593528);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(14,5.432454);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(15,2.923803);
   ZccHcc_boosted_PN_med_HMass__423->SetBinError(17,0.8749489);
   ZccHcc_boosted_PN_med_HMass__423->SetEntries(54);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__423->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__423->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__423->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__423->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__423->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__423->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__423->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__423->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__423->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__423->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__423->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__423->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__168->Modified();
   c1_n19->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__169 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__169->Draw();
   pad1_v2__169->cd();
   pad1_v2__169->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__169->SetFillColor(0);
   pad1_v2__169->SetBorderMode(0);
   pad1_v2__169->SetBorderSize(2);
   pad1_v2__169->SetFrameBorderMode(0);
   pad1_v2__169->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__424 = new TH1D("ZccHcc_boosted_PN_med_HMass__424","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(9,0.8399314);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(10,0.898392);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(11,0.7716245);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(12,0.8761536);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(13,0.9720623);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(14,1.005946);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(15,0.8769778);
   ZccHcc_boosted_PN_med_HMass__424->SetBinContent(17,1.25685);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(9,0.8402602);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(10,0.898761);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(11,1.091242);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(12,0.4417626);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(13,0.3289723);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(14,0.3740484);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(15,0.7216654);
   ZccHcc_boosted_PN_med_HMass__424->SetBinError(17,1.777454);
   ZccHcc_boosted_PN_med_HMass__424->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__424->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__424->SetEntries(8.233547);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__424->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__424->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__424->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__424->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__424->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__424->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__424->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__424->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__425 = new TH1D("ZccHcc_boosted_PN_med_HMass__425","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(9,1.177881);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(10,1.091343);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(11,1.282755);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(12,1.158193);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(13,1.025762);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(14,0.9995799);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(15,1.133459);
   ZccHcc_boosted_PN_med_HMass__425->SetBinContent(17,0.7394492);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(9,1.18086);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(10,1.092575);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(11,1.81409);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(12,0.5909597);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(13,0.3626122);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(14,0.3819526);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(15,0.9310518);
   ZccHcc_boosted_PN_med_HMass__425->SetBinError(17,1.045739);
   ZccHcc_boosted_PN_med_HMass__425->SetEntries(8.753125);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__425->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__425->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__425->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__425->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__425->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__425->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__425->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__425->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__425->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__169->Modified();
   c1_n19->cd();
   c1_n19->Modified();
   c1_n19->SetSelected(c1_n19);
}
