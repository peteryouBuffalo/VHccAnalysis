#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n23/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n23 = new TCanvas("c1_n23", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n23->SetHighLightColor(2);
   c1_n23->Range(0,0,1,1);
   c1_n23->SetFillColor(0);
   c1_n23->SetBorderMode(0);
   c1_n23->SetBorderSize(2);
   c1_n23->SetLeftMargin(0.15);
   c1_n23->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__176 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__176->Draw();
   pad1_v1__176->cd();
   pad1_v1__176->Range(-37.5,-4.513013,337.5,40.61711);
   pad1_v1__176->SetFillColor(0);
   pad1_v1__176->SetBorderMode(0);
   pad1_v1__176->SetBorderSize(2);
   pad1_v1__176->SetFrameBorderMode(0);
   pad1_v1__176->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__441 = new TH1D("ZccHcc_boosted_PN_med_ZMass__441","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(8,4.163776);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(9,23.13419);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(10,31.43353);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(11,4.043138);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinContent(12,2.976751);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(8,2.431295);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(9,6.005277);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(10,6.587601);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(11,2.015246);
   ZccHcc_boosted_PN_med_ZMass__441->SetBinError(12,2.106574);
   ZccHcc_boosted_PN_med_ZMass__441->SetMaximum(36.1041);
   ZccHcc_boosted_PN_med_ZMass__441->SetEntries(54);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__441->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__441->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__441->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__441->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__441->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__441->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__441->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__441->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__441->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__442 = new TH1D("ZccHcc_boosted_PN_med_ZMass__442","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(8,4.163776);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(9,24.78445);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(10,34.1041);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(11,7.169224);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinContent(12,4.213649);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(8,2.431295);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(9,6.221806);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(10,6.851778);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(11,2.991561);
   ZccHcc_boosted_PN_med_ZMass__442->SetBinError(12,2.442861);
   ZccHcc_boosted_PN_med_ZMass__442->SetEntries(60);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__442->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__442->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__442->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__442->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__442->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__442->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__442->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__443 = new TH1D("ZccHcc_boosted_PN_med_ZMass__443","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(8,6.766717);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(9,21.88516);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(10,28.54082);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(11,3.839621);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinContent(12,2.976751);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(5,1.589732);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(7,1.544208);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(8,3.055004);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(9,5.873549);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(10,6.254362);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(11,2.004944);
   ZccHcc_boosted_PN_med_ZMass__443->SetBinError(12,2.106574);
   ZccHcc_boosted_PN_med_ZMass__443->SetEntries(52);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__443->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__443->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__443->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__443->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__443->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__443->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__443->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__176->Modified();
   c1_n23->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__177 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__177->Draw();
   pad1_v2__177->cd();
   pad1_v2__177->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__177->SetFillColor(0);
   pad1_v2__177->SetBorderMode(0);
   pad1_v2__177->SetBorderSize(2);
   pad1_v2__177->SetFrameBorderMode(0);
   pad1_v2__177->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__444 = new TH1D("ZccHcc_boosted_PN_med_ZMass__444","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(9,1.071334);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(10,1.084959);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(11,1.773183);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinContent(12,1.415519);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(8,0.8257816);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(9,0.3868741);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(10,0.3149832);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(11,1.152651);
   ZccHcc_boosted_PN_med_ZMass__444->SetBinError(12,1.29496);
   ZccHcc_boosted_PN_med_ZMass__444->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__444->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__444->SetEntries(8.77471);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__444->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__444->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__444->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__444->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__444->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__444->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__445 = new TH1D("ZccHcc_boosted_PN_med_ZMass__445","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(8,1.625139);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(9,0.9460095);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(10,0.9079739);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(11,0.9496637);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(8,1.199511);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(9,0.3532205);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(10,0.275315);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(11,0.6855378);
   ZccHcc_boosted_PN_med_ZMass__445->SetBinError(12,1.000804);
   ZccHcc_boosted_PN_med_ZMass__445->SetEntries(7.760817);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__445->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__445->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__445->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__445->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__445->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__177->Modified();
   c1_n23->cd();
   c1_n23->Modified();
   c1_n23->SetSelected(c1_n23);
}
