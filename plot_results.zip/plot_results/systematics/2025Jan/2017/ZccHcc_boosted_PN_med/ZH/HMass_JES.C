#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n17/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n17 = new TCanvas("c1_n17", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n17->SetHighLightColor(2);
   c1_n17->Range(0,0,1,1);
   c1_n17->SetFillColor(0);
   c1_n17->SetBorderMode(0);
   c1_n17->SetBorderSize(2);
   c1_n17->SetLeftMargin(0.15);
   c1_n17->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__164 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__164->Draw();
   pad1_v1__164->cd();
   pad1_v1__164->Range(-37.5,-8.077326,337.5,72.69593);
   pad1_v1__164->SetFillColor(0);
   pad1_v1__164->SetBorderMode(0);
   pad1_v1__164->SetBorderSize(2);
   pad1_v1__164->SetFrameBorderMode(0);
   pad1_v1__164->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__411 = new TH1D("ZccHcc_boosted_PN_med_HMass__411","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(10,3.644143);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(11,1.567044);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(12,20.47408);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(13,60.48841);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(14,21.61731);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(15,4.664136);
   ZccHcc_boosted_PN_med_HMass__411->SetBinContent(16,5.897465);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(10,2.604297);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(11,1.567044);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(12,5.677081);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(13,9.896401);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(14,6.365582);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(15,2.71605);
   ZccHcc_boosted_PN_med_HMass__411->SetBinError(16,2.884406);
   ZccHcc_boosted_PN_med_HMass__411->SetMaximum(64.61861);
   ZccHcc_boosted_PN_med_HMass__411->SetEntries(86);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__411->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__411->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__411->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__411->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__411->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__411->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__411->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__411->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__411->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__411->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__411->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__411->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__411->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__411->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__412 = new TH1D("ZccHcc_boosted_PN_med_HMass__412","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(10,3.644143);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(11,1.567044);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(12,20.47408);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(13,57.59807);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(14,26.77913);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(15,5.437428);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(16,6.989446);
   ZccHcc_boosted_PN_med_HMass__412->SetBinContent(17,0.1971294);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(10,2.604297);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(11,1.567044);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(12,5.677081);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(13,9.507685);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(14,7.110475);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(15,3.157313);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(16,3.153211);
   ZccHcc_boosted_PN_med_HMass__412->SetBinError(17,0.1971294);
   ZccHcc_boosted_PN_med_HMass__412->SetEntries(89);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__412->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__412->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__412->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__412->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__412->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__412->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__412->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__412->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__412->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__412->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__412->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__412->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__413 = new TH1D("ZccHcc_boosted_PN_med_HMass__413","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(10,3.644143);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(11,3.982041);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(12,18.05908);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(13,62.61861);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(14,17.47405);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(15,5.786773);
   ZccHcc_boosted_PN_med_HMass__413->SetBinContent(16,4.774828);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(9,2.276426);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(10,2.604297);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(11,2.878861);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(12,5.137805);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(13,10.03159);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(14,5.874274);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(15,2.938919);
   ZccHcc_boosted_PN_med_HMass__413->SetBinError(16,2.656969);
   ZccHcc_boosted_PN_med_HMass__413->SetEntries(85);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__413->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__413->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__413->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__413->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__413->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__413->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__413->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__413->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__413->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__413->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__413->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__413->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__164->Modified();
   c1_n17->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__165 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__165->Draw();
   pad1_v2__165->cd();
   pad1_v2__165->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__165->SetFillColor(0);
   pad1_v2__165->SetBorderMode(0);
   pad1_v2__165->SetBorderSize(2);
   pad1_v2__165->SetFrameBorderMode(0);
   pad1_v2__165->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__414 = new TH1D("ZccHcc_boosted_PN_med_HMass__414","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(13,0.9522166);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(14,1.238782);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(15,1.165795);
   ZccHcc_boosted_PN_med_HMass__414->SetBinContent(16,1.185161);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(9,1.414214);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(10,1.010672);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(11,1.414214);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(12,0.3921351);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(13,0.2213071);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(14,0.4911783);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(15,0.9587018);
   ZccHcc_boosted_PN_med_HMass__414->SetBinError(16,0.7885888);
   ZccHcc_boosted_PN_med_HMass__414->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__414->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__414->SetEntries(10.41399);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__414->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__414->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__414->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__414->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__414->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__414->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__414->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__414->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__415 = new TH1D("ZccHcc_boosted_PN_med_HMass__415","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(9,1);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(11,2.541117);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(12,0.8820461);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(13,1.035217);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(14,0.8083359);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(15,1.240696);
   ZccHcc_boosted_PN_med_HMass__415->SetBinContent(16,0.8096407);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(9,1.414214);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(10,1.010672);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(11,3.135652);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(12,0.3504123);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(13,0.2370446);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(14,0.3612474);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(15,0.9586607);
   ZccHcc_boosted_PN_med_HMass__415->SetBinError(16,0.5998185);
   ZccHcc_boosted_PN_med_HMass__415->SetEntries(6.010737);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__415->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__415->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__415->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__415->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__415->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__415->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__415->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__415->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__415->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__165->Modified();
   c1_n17->cd();
   c1_n17->Modified();
   c1_n17->SetSelected(c1_n17);
}
