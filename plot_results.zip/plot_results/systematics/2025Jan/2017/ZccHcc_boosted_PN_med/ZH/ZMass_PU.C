#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_PU()
{
//=========Macro generated from canvas: c1_n29/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n29 = new TCanvas("c1_n29", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n29->SetHighLightColor(2);
   c1_n29->Range(0,0,1,1);
   c1_n29->SetFillColor(0);
   c1_n29->SetBorderMode(0);
   c1_n29->SetBorderSize(2);
   c1_n29->SetLeftMargin(0.15);
   c1_n29->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__188 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__188->Draw();
   pad1_v1__188->cd();
   pad1_v1__188->Range(-37.5,-5.817637,337.5,52.35873);
   pad1_v1__188->SetFillColor(0);
   pad1_v1__188->SetBorderMode(0);
   pad1_v1__188->SetBorderSize(2);
   pad1_v1__188->SetFrameBorderMode(0);
   pad1_v1__188->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__471 = new TH1D("ZccHcc_boosted_PN_med_ZMass__471","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(7,2.254161);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(8,12.6428);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(9,42.27318);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(10,43.03154);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(11,15.9478);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinContent(14,1.849771);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(7,1.594642);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(8,4.518262);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(9,8.381382);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(10,8.7821);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(11,4.923891);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__471->SetBinError(14,1.664357);
   ZccHcc_boosted_PN_med_ZMass__471->SetMaximum(46.5411);
   ZccHcc_boosted_PN_med_ZMass__471->SetEntries(86);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__471->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__471->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__471->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__471->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__471->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__471->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__471->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__471->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__471->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__472 = new TH1D("ZccHcc_boosted_PN_med_ZMass__472","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(6,1.03387);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(7,2.438191);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(8,12.73834);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(9,40.26854);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(10,43.58951);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(11,17.3864);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(12,1.356568);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinContent(14,1.889832);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(6,1.03387);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(7,1.724436);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(8,4.398444);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(9,7.906696);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(10,8.701928);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(11,5.203965);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(12,1.356568);
   ZccHcc_boosted_PN_med_ZMass__472->SetBinError(14,1.462672);
   ZccHcc_boosted_PN_med_ZMass__472->SetEntries(86);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__472->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__472->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__472->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__472->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__472->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__472->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__472->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__473 = new TH1D("ZccHcc_boosted_PN_med_ZMass__473","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(6,1.721247);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(7,2.027003);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(8,12.60181);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(9,44.5411);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(10,41.0008);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(11,14.57526);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(12,1.336582);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinContent(14,2.018945);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(6,1.721247);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(7,1.43418);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(8,4.630828);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(9,8.997997);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(10,8.652842);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(11,4.667532);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(12,1.336582);
   ZccHcc_boosted_PN_med_ZMass__473->SetBinError(14,1.96274);
   ZccHcc_boosted_PN_med_ZMass__473->SetEntries(86);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__473->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__473->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__473->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__473->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__473->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__473->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__473->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__188->Modified();
   c1_n29->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__189 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__189->Draw();
   pad1_v2__189->cd();
   pad1_v2__189->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__189->SetFillColor(0);
   pad1_v2__189->SetBorderMode(0);
   pad1_v2__189->SetBorderSize(2);
   pad1_v2__189->SetFrameBorderMode(0);
   pad1_v2__189->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__474 = new TH1D("ZccHcc_boosted_PN_med_ZMass__474","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(6,0.7659499);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(7,1.08164);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(8,1.007556);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(9,0.9525791);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(10,1.012966);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(11,1.090207);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(12,1.05984);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinContent(14,1.021658);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(6,1.083217);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(7,1.081999);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(8,0.5006912);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(9,0.2658069);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(10,0.2891914);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(11,0.4688076);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(12,1.49884);
   ZccHcc_boosted_PN_med_ZMass__474->SetBinError(14,1.21255);
   ZccHcc_boosted_PN_med_ZMass__474->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__474->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__474->SetEntries(9.554573);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__474->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__474->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__474->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__474->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__474->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__474->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__475 = new TH1D("ZccHcc_boosted_PN_med_ZMass__475","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(6,1.275198);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(7,0.8992276);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(8,0.9967572);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(9,1.053649);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(10,0.952808);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(11,0.9139355);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(12,1.044225);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinContent(14,1.091457);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(6,1.803402);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(7,0.8997016);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(8,0.5109349);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(9,0.2982407);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(10,0.279725);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(11,0.4065506);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(12,1.476757);
   ZccHcc_boosted_PN_med_ZMass__475->SetBinError(14,1.445788);
   ZccHcc_boosted_PN_med_ZMass__475->SetEntries(7.582901);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__475->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__475->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__475->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__475->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__475->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__189->Modified();
   c1_n29->cd();
   c1_n29->Modified();
   c1_n29->SetSelected(c1_n29);
}
