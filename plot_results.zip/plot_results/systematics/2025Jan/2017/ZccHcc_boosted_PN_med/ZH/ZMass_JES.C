#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n25/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n25 = new TCanvas("c1_n25", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n25->SetHighLightColor(2);
   c1_n25->Range(0,0,1,1);
   c1_n25->SetFillColor(0);
   c1_n25->SetBorderMode(0);
   c1_n25->SetBorderSize(2);
   c1_n25->SetLeftMargin(0.15);
   c1_n25->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__180 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__180->Draw();
   pad1_v1__180->cd();
   pad1_v1__180->Range(-37.5,-6.341059,337.5,57.06953);
   pad1_v1__180->SetFillColor(0);
   pad1_v1__180->SetBorderMode(0);
   pad1_v1__180->SetBorderSize(2);
   pad1_v1__180->SetFrameBorderMode(0);
   pad1_v1__180->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__451 = new TH1D("ZccHcc_boosted_PN_med_ZMass__451","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(7,2.254161);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(8,12.6428);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(9,42.27318);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(10,43.03154);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(11,15.9478);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinContent(14,1.849771);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(7,1.594642);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(8,4.518262);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(9,8.381382);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(10,8.7821);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(11,4.923891);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__451->SetBinError(14,1.664357);
   ZccHcc_boosted_PN_med_ZMass__451->SetMaximum(50.72847);
   ZccHcc_boosted_PN_med_ZMass__451->SetEntries(86);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__451->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__451->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__451->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__451->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__451->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__451->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__451->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__451->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__451->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__452 = new TH1D("ZccHcc_boosted_PN_med_ZMass__452","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(7,2.254161);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(8,12.6428);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(9,36.56156);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(10,48.47469);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(11,18.48775);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(14,1.849771);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinContent(15,2.062402);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(7,1.594642);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(8,4.518262);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(9,7.772459);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(10,9.282776);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(11,5.247098);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(12,1.279975);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(14,1.664357);
   ZccHcc_boosted_PN_med_ZMass__452->SetBinError(15,2.062402);
   ZccHcc_boosted_PN_med_ZMass__452->SetEntries(89);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__452->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__452->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__452->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__452->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__452->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__452->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__452->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__453 = new TH1D("ZccHcc_boosted_PN_med_ZMass__453","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(7,2.254161);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(8,12.1781);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(9,48.72847);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(10,37.2426);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(11,15.01306);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(13,0.1971294);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinContent(14,1.652641);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(6,1.349789);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(7,1.594642);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(8,4.413178);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(9,8.964509);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(10,8.179186);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(11,4.859374);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(13,0.1971294);
   ZccHcc_boosted_PN_med_ZMass__453->SetBinError(14,1.652641);
   ZccHcc_boosted_PN_med_ZMass__453->SetEntries(85);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__453->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__453->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__453->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__453->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__453->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__453->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__453->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__180->Modified();
   c1_n25->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__181 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__181->Draw();
   pad1_v2__181->cd();
   pad1_v2__181->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__181->SetFillColor(0);
   pad1_v2__181->SetBorderMode(0);
   pad1_v2__181->SetBorderSize(2);
   pad1_v2__181->SetFrameBorderMode(0);
   pad1_v2__181->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__454 = new TH1D("ZccHcc_boosted_PN_med_ZMass__454","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(6,1);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(8,1);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(9,0.8648879);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(10,1.126492);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(11,1.159266);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinContent(14,1);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(6,1.414214);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(7,1.000445);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(8,0.505409);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(9,0.2514169);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(10,0.3152608);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(11,0.4861705);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(12,1.414214);
   ZccHcc_boosted_PN_med_ZMass__454->SetBinError(14,1.272458);
   ZccHcc_boosted_PN_med_ZMass__454->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__454->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__454->SetEntries(9.13239);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__454->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__454->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__454->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__454->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__454->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__454->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__455 = new TH1D("ZccHcc_boosted_PN_med_ZMass__455","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(6,1);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(8,0.9632439);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(9,1.152704);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(10,0.865472);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(11,0.9413873);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinContent(14,0.8934303);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(6,1.414214);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(7,1.000445);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(8,0.4902552);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(9,0.3117725);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(10,0.2594732);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(11,0.4210994);
   ZccHcc_boosted_PN_med_ZMass__455->SetBinError(14,1.201846);
   ZccHcc_boosted_PN_med_ZMass__455->SetEntries(9.241338);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__455->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__455->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__455->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__455->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__455->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__181->Modified();
   c1_n25->cd();
   c1_n25->Modified();
   c1_n25->SetSelected(c1_n25);
}
