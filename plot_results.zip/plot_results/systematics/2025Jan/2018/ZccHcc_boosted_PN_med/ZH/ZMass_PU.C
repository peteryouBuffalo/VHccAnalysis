#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_PU()
{
//=========Macro generated from canvas: c1_n30/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n30 = new TCanvas("c1_n30", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n30->SetHighLightColor(2);
   c1_n30->Range(0,0,1,1);
   c1_n30->SetFillColor(0);
   c1_n30->SetBorderMode(0);
   c1_n30->SetBorderSize(2);
   c1_n30->SetLeftMargin(0.15);
   c1_n30->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__190 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__190->Draw();
   pad1_v1__190->cd();
   pad1_v1__190->Range(-37.5,-3.618815,337.5,32.56933);
   pad1_v1__190->SetFillColor(0);
   pad1_v1__190->SetBorderMode(0);
   pad1_v1__190->SetBorderSize(2);
   pad1_v1__190->SetFrameBorderMode(0);
   pad1_v1__190->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__476 = new TH1D("ZccHcc_boosted_PN_med_ZMass__476","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(8,9.956567);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(9,24.79753);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(10,24.97791);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(11,17.60882);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(12,3.520086);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinContent(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(8,3.087229);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(9,5.35836);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(10,5.844413);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(11,4.371486);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(12,2.051739);
   ZccHcc_boosted_PN_med_ZMass__476->SetBinError(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__476->SetMaximum(28.95052);
   ZccHcc_boosted_PN_med_ZMass__476->SetEntries(89);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__476->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__476->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__476->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__476->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__476->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__476->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__476->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__476->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__476->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__477 = new TH1D("ZccHcc_boosted_PN_med_ZMass__477","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(5,0.9752371);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(8,9.962917);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(9,22.97752);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(10,23.22146);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(11,16.44399);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(12,3.070907);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinContent(13,1.020858);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(5,0.9752371);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(8,3.024252);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(9,4.92654);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(10,5.356508);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(11,4.021786);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(12,1.77708);
   ZccHcc_boosted_PN_med_ZMass__477->SetBinError(13,1.020858);
   ZccHcc_boosted_PN_med_ZMass__477->SetEntries(89);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__477->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__477->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__477->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__477->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__477->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__477->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__477->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__478 = new TH1D("ZccHcc_boosted_PN_med_ZMass__478","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(5,0.8354295);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(8,9.829296);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(9,26.73718);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(10,26.95052);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(11,18.71257);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(12,4.071343);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinContent(13,1.309238);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(5,0.8354295);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(8,3.182196);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(9,5.857122);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(10,6.485086);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(11,4.752651);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(12,2.407936);
   ZccHcc_boosted_PN_med_ZMass__478->SetBinError(13,1.309238);
   ZccHcc_boosted_PN_med_ZMass__478->SetEntries(89);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__478->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__478->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__478->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__478->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__478->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__478->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__478->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__190->Modified();
   c1_n30->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__191 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__191->Draw();
   pad1_v2__191->cd();
   pad1_v2__191->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__191->SetFillColor(0);
   pad1_v2__191->SetBorderMode(0);
   pad1_v2__191->SetBorderSize(2);
   pad1_v2__191->SetFrameBorderMode(0);
   pad1_v2__191->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__479 = new TH1D("ZccHcc_boosted_PN_med_ZMass__479","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(5,1.043209);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(8,1.000638);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(9,0.9266052);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(10,0.9296798);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(11,0.9338497);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(12,0.8723955);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinContent(13,0.8758663);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(5,1.47532);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(8,0.4341964);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(9,0.2820639);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(10,0.3054633);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(11,0.3254403);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(12,0.7165371);
   ZccHcc_boosted_PN_med_ZMass__479->SetBinError(13,1.238662);
   ZccHcc_boosted_PN_med_ZMass__479->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__479->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__479->SetEntries(9.234818);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__479->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__479->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__479->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__479->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__479->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__479->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__480 = new TH1D("ZccHcc_boosted_PN_med_ZMass__480","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(5,0.893657);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(8,0.9872174);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(9,1.078219);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(10,1.078974);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(11,1.062681);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(12,1.156603);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinContent(13,1.123288);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(5,1.263822);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(8,0.4425495);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(9,0.3317711);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(10,0.3621412);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(11,0.3774202);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(12,0.9604186);
   ZccHcc_boosted_PN_med_ZMass__480->SetBinError(13,1.58857);
   ZccHcc_boosted_PN_med_ZMass__480->SetEntries(9.688172);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__480->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__480->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__480->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__480->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__480->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__191->Modified();
   c1_n30->cd();
   c1_n30->Modified();
   c1_n30->SetSelected(c1_n30);
}
