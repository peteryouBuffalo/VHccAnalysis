#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_PU()
{
//=========Macro generated from canvas: c1_n22/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n22 = new TCanvas("c1_n22", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n22->SetHighLightColor(2);
   c1_n22->Range(0,0,1,1);
   c1_n22->SetFillColor(0);
   c1_n22->SetBorderMode(0);
   c1_n22->SetBorderSize(2);
   c1_n22->SetLeftMargin(0.15);
   c1_n22->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__174 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__174->Draw();
   pad1_v1__174->cd();
   pad1_v1__174->Range(-37.5,-3.658239,337.5,32.92415);
   pad1_v1__174->SetFillColor(0);
   pad1_v1__174->SetBorderMode(0);
   pad1_v1__174->SetBorderSize(2);
   pad1_v1__174->SetFrameBorderMode(0);
   pad1_v1__174->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__436 = new TH1D("ZccHcc_boosted_PN_med_HMass__436","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(11,5.658487);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(12,16.31254);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(13,25.45225);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(14,23.44508);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(15,7.936473);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(16,2.298641);
   ZccHcc_boosted_PN_med_HMass__436->SetBinContent(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(11,2.365857);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(12,4.262026);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(13,5.803766);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(14,5.067724);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(15,2.839881);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(16,2.242123);
   ZccHcc_boosted_PN_med_HMass__436->SetBinError(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__436->SetMaximum(29.26591);
   ZccHcc_boosted_PN_med_HMass__436->SetEntries(89);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__436->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__436->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__436->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__436->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__436->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__436->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__436->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__436->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__436->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__436->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__436->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__436->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__436->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__436->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__437 = new TH1D("ZccHcc_boosted_PN_med_HMass__437","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(10,0.9781706);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(11,5.551569);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(12,14.55971);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(13,23.8445);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(14,21.9374);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(15,7.787554);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(16,2.040495);
   ZccHcc_boosted_PN_med_HMass__437->SetBinContent(17,0.9734867);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(10,0.9781706);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(11,2.281615);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(12,3.775049);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(13,5.379231);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(14,4.637739);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(15,2.758978);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(16,2.004276);
   ZccHcc_boosted_PN_med_HMass__437->SetBinError(17,0.9734867);
   ZccHcc_boosted_PN_med_HMass__437->SetEntries(89);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__437->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__437->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__437->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__437->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__437->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__437->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__437->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__437->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__437->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__437->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__437->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__437->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__438 = new TH1D("ZccHcc_boosted_PN_med_HMass__438","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(10,0.9492775);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(11,5.655874);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(12,18.24791);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(13,27.26591);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(14,25.06372);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(15,7.963404);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(16,2.589662);
   ZccHcc_boosted_PN_med_HMass__438->SetBinContent(17,0.7098054);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(10,0.9492775);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(11,2.448112);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(12,4.842296);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(13,6.32114);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(14,5.605906);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(15,2.92481);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(16,2.55009);
   ZccHcc_boosted_PN_med_HMass__438->SetBinError(17,0.7098054);
   ZccHcc_boosted_PN_med_HMass__438->SetEntries(89);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__438->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__438->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__438->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__438->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__438->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__438->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__438->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__438->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__438->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__438->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__438->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__438->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__174->Modified();
   c1_n22->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__175 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__175->Draw();
   pad1_v2__175->cd();
   pad1_v2__175->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__175->SetFillColor(0);
   pad1_v2__175->SetBorderMode(0);
   pad1_v2__175->SetBorderSize(2);
   pad1_v2__175->SetFrameBorderMode(0);
   pad1_v2__175->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__439 = new TH1D("ZccHcc_boosted_PN_med_HMass__439","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(10,0.9915892);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(11,0.9811047);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(12,0.8925474);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(13,0.9368328);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(14,0.9356933);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(15,0.9812362);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(16,0.8876966);
   ZccHcc_boosted_PN_med_HMass__439->SetBinContent(17,1.117193);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(10,1.402319);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(11,0.5752012);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(12,0.3285374);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(13,0.300502);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(14,0.2829067);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(15,0.4940936);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(16,1.228825);
   ZccHcc_boosted_PN_med_HMass__439->SetBinError(17,1.579949);
   ZccHcc_boosted_PN_med_HMass__439->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__439->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__439->SetEntries(8.739885);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__439->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__439->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__439->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__439->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__439->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__439->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__439->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__439->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__440 = new TH1D("ZccHcc_boosted_PN_med_HMass__440","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(10,0.9622997);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(11,0.9995381);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(12,1.118644);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(13,1.071257);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(14,1.06904);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(15,1.003393);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(16,1.126606);
   ZccHcc_boosted_PN_med_HMass__440->SetBinContent(17,0.814587);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(10,1.360897);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(11,0.6015261);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(12,0.4165808);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(13,0.3483519);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(14,0.3325189);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(15,0.5145124);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(16,1.561519);
   ZccHcc_boosted_PN_med_HMass__440->SetBinError(17,1.152);
   ZccHcc_boosted_PN_med_HMass__440->SetEntries(10.0268);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__440->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__440->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__440->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__440->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__440->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__440->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__440->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__440->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__440->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__175->Modified();
   c1_n22->cd();
   c1_n22->Modified();
   c1_n22->SetSelected(c1_n22);
}
