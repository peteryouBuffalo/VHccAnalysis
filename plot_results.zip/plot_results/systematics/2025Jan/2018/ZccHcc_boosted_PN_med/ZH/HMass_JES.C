#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n18/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n18 = new TCanvas("c1_n18", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n18->SetHighLightColor(2);
   c1_n18->Range(0,0,1,1);
   c1_n18->SetFillColor(0);
   c1_n18->SetBorderMode(0);
   c1_n18->SetBorderSize(2);
   c1_n18->SetLeftMargin(0.15);
   c1_n18->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__166 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__166->Draw();
   pad1_v1__166->cd();
   pad1_v1__166->Range(-37.5,-4.537303,337.5,40.83572);
   pad1_v1__166->SetFillColor(0);
   pad1_v1__166->SetBorderMode(0);
   pad1_v1__166->SetBorderSize(2);
   pad1_v1__166->SetFrameBorderMode(0);
   pad1_v1__166->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__416 = new TH1D("ZccHcc_boosted_PN_med_HMass__416","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(11,5.658487);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(12,16.31254);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(13,25.45225);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(14,23.44508);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(15,7.936473);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(16,2.298641);
   ZccHcc_boosted_PN_med_HMass__416->SetBinContent(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(11,2.365857);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(12,4.262026);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(13,5.803766);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(14,5.067724);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(15,2.839881);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(16,2.242123);
   ZccHcc_boosted_PN_med_HMass__416->SetBinError(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__416->SetMaximum(36.29842);
   ZccHcc_boosted_PN_med_HMass__416->SetEntries(89);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__416->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__416->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__416->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__416->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__416->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__416->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__416->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__416->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__416->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__416->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__416->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__416->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__416->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__416->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__417 = new TH1D("ZccHcc_boosted_PN_med_HMass__417","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(11,5.64882);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(12,15.53336);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(13,18.24139);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(14,34.29842);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(15,8.716961);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(16,3.129574);
   ZccHcc_boosted_PN_med_HMass__417->SetBinContent(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(11,2.360396);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(12,4.190197);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(13,5.055594);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(14,6.079038);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(15,3.159195);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(16,2.391143);
   ZccHcc_boosted_PN_med_HMass__417->SetBinError(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__417->SetEntries(93);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__417->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__417->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__417->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__417->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__417->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__417->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__417->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__417->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__417->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__417->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__417->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__417->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__418 = new TH1D("ZccHcc_boosted_PN_med_HMass__418","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(11,5.591726);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(12,16.45714);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(13,27.16862);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(14,18.72914);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(15,7.950109);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(16,2.306233);
   ZccHcc_boosted_PN_med_HMass__418->SetBinContent(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(10,0.9864676);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(11,2.33906);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(12,4.295272);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(13,5.963066);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(14,4.560477);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(15,2.845078);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(16,2.246915);
   ZccHcc_boosted_PN_med_HMass__418->SetBinError(17,0.8713684);
   ZccHcc_boosted_PN_med_HMass__418->SetEntries(86);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__418->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__418->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__418->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__418->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__418->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__418->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__418->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__418->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__418->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__418->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__418->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__418->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__166->Modified();
   c1_n18->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__167 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__167->Draw();
   pad1_v2__167->cd();
   pad1_v2__167->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__167->SetFillColor(0);
   pad1_v2__167->SetBorderMode(0);
   pad1_v2__167->SetBorderSize(2);
   pad1_v2__167->SetFrameBorderMode(0);
   pad1_v2__167->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__419 = new TH1D("ZccHcc_boosted_PN_med_HMass__419","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(11,0.9982915);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(12,0.9522344);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(13,0.7166908);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(14,1.462926);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(15,1.098342);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(16,1.361489);
   ZccHcc_boosted_PN_med_HMass__419->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(10,1.414214);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(11,0.590106);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(12,0.3576032);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(13,0.2572187);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(14,0.4089291);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(15,0.5593868);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(16,1.686927);
   ZccHcc_boosted_PN_med_HMass__419->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__419->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__419->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__419->SetEntries(9.378046);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__419->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__419->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__419->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__419->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__419->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__419->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__419->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__419->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__420 = new TH1D("ZccHcc_boosted_PN_med_HMass__420","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(11,0.9882015);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(12,1.008864);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(13,1.067435);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(14,0.7988515);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(15,1.001718);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(16,1.003303);
   ZccHcc_boosted_PN_med_HMass__420->SetBinContent(17,1);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(10,1.414214);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(11,0.5844566);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(12,0.3725747);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(13,0.3378372);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(14,0.2601027);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(15,0.506941);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(16,1.383194);
   ZccHcc_boosted_PN_med_HMass__420->SetBinError(17,1.414214);
   ZccHcc_boosted_PN_med_HMass__420->SetEntries(9.061423);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__420->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__420->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__420->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__420->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__420->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__420->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__420->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__420->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__420->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__167->Modified();
   c1_n18->cd();
   c1_n18->Modified();
   c1_n18->SetSelected(c1_n18);
}
