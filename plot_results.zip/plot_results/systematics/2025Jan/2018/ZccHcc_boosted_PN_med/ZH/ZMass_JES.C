#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n26/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n26 = new TCanvas("c1_n26", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n26->SetHighLightColor(2);
   c1_n26->Range(0,0,1,1);
   c1_n26->SetFillColor(0);
   c1_n26->SetBorderMode(0);
   c1_n26->SetBorderSize(2);
   c1_n26->SetLeftMargin(0.15);
   c1_n26->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__182 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__182->Draw();
   pad1_v1__182->cd();
   pad1_v1__182->Range(-37.5,-3.833877,337.5,34.50489);
   pad1_v1__182->SetFillColor(0);
   pad1_v1__182->SetBorderMode(0);
   pad1_v1__182->SetBorderSize(2);
   pad1_v1__182->SetFrameBorderMode(0);
   pad1_v1__182->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__456 = new TH1D("ZccHcc_boosted_PN_med_ZMass__456","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(8,9.956567);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(9,24.79753);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(10,24.97791);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(11,17.60882);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(12,3.520086);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinContent(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(8,3.087229);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(9,5.35836);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(10,5.844413);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(11,4.371486);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(12,2.051739);
   ZccHcc_boosted_PN_med_ZMass__456->SetBinError(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__456->SetMaximum(30.67101);
   ZccHcc_boosted_PN_med_ZMass__456->SetEntries(89);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__456->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__456->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__456->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__456->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__456->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__456->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__456->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__456->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__456->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__457 = new TH1D("ZccHcc_boosted_PN_med_ZMass__457","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(8,9.134598);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(9,26.39146);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(10,28.67101);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(11,17.60882);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(12,3.520086);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinContent(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(5,0.9348436);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(8,2.974439);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(9,5.312112);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(10,6.360478);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(11,4.371486);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(12,2.051739);
   ZccHcc_boosted_PN_med_ZMass__457->SetBinError(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__457->SetEntries(93);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__457->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__457->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__457->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__457->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__457->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__457->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__457->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__458 = new TH1D("ZccHcc_boosted_PN_med_ZMass__458","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(8,9.964853);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(9,23.82593);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(10,28.20298);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(11,15.89528);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(12,1.006212);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinContent(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(8,3.089876);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(9,5.26967);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(10,6.14125);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(11,4.213017);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(12,1.006212);
   ZccHcc_boosted_PN_med_ZMass__458->SetBinError(13,1.165541);
   ZccHcc_boosted_PN_med_ZMass__458->SetEntries(86);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__458->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__458->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__458->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__458->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__458->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__458->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__458->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__182->Modified();
   c1_n26->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__183 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__183->Draw();
   pad1_v2__183->cd();
   pad1_v2__183->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__183->SetFillColor(0);
   pad1_v2__183->SetBorderMode(0);
   pad1_v2__183->SetBorderSize(2);
   pad1_v2__183->SetFrameBorderMode(0);
   pad1_v2__183->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__459 = new TH1D("ZccHcc_boosted_PN_med_ZMass__459","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(8,0.9174446);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(9,1.064278);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(10,1.147855);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(11,1);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(12,1);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinContent(13,1);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(8,0.4125174);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(9,0.3142895);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(10,0.3701057);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(11,0.3510862);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(12,0.8242972);
   ZccHcc_boosted_PN_med_ZMass__459->SetBinError(13,1.414214);
   ZccHcc_boosted_PN_med_ZMass__459->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__459->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__459->SetEntries(9.758926);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__459->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__459->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__459->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__459->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__459->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__459->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__460 = new TH1D("ZccHcc_boosted_PN_med_ZMass__460","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(8,1.000832);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(9,0.9608184);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(10,1.129117);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(11,0.9026885);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(12,0.2858488);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinContent(13,1);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(8,0.4388752);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(9,0.2970939);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(10,0.3609009);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(11,0.3278156);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(12,0.3308609);
   ZccHcc_boosted_PN_med_ZMass__460->SetBinError(13,1.414214);
   ZccHcc_boosted_PN_med_ZMass__460->SetEntries(10.60519);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__460->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__460->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__460->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__460->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__460->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__183->Modified();
   c1_n26->cd();
   c1_n26->Modified();
   c1_n26->SetSelected(c1_n26);
}
