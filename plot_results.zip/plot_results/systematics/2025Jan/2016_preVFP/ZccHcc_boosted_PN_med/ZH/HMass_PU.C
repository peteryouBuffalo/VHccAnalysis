#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_PU()
{
//=========Macro generated from canvas: c1_n20/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n20 = new TCanvas("c1_n20", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n20->SetHighLightColor(2);
   c1_n20->Range(0,0,1,1);
   c1_n20->SetFillColor(0);
   c1_n20->SetBorderMode(0);
   c1_n20->SetBorderSize(2);
   c1_n20->SetLeftMargin(0.15);
   c1_n20->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__170 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__170->Draw();
   pad1_v1__170->cd();
   pad1_v1__170->Range(-37.5,-1.932107,337.5,17.38896);
   pad1_v1__170->SetFillColor(0);
   pad1_v1__170->SetBorderMode(0);
   pad1_v1__170->SetBorderSize(2);
   pad1_v1__170->SetFrameBorderMode(0);
   pad1_v1__170->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__426 = new TH1D("ZccHcc_boosted_PN_med_HMass__426","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(11,4.304931);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(12,4.006251);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(13,12.70104);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(14,12.68416);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(15,5.738796);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__426->SetBinContent(17,1.063023);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(11,2.184795);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(12,2.749297);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(13,5.102735);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(14,4.621875);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(15,2.601438);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__426->SetBinError(17,1.063023);
   ZccHcc_boosted_PN_med_HMass__426->SetMaximum(15.45685);
   ZccHcc_boosted_PN_med_HMass__426->SetEntries(46);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__426->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__426->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__426->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__426->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__426->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__426->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__426->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__426->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__426->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__426->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__426->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__426->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__426->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__426->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__427 = new TH1D("ZccHcc_boosted_PN_med_HMass__427","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(10,1.042302);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(11,3.642488);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(12,3.953517);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(13,11.90081);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(14,12.24862);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(15,5.247554);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(16,1.644379);
   ZccHcc_boosted_PN_med_HMass__427->SetBinContent(17,1.070806);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(10,1.042302);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(11,1.880207);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(12,2.595195);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(13,4.790189);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(14,4.296825);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(15,2.40754);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(16,1.644379);
   ZccHcc_boosted_PN_med_HMass__427->SetBinError(17,1.070806);
   ZccHcc_boosted_PN_med_HMass__427->SetEntries(46);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__427->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__427->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__427->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__427->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__427->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__427->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__427->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__427->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__427->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__427->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__427->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__427->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__428 = new TH1D("ZccHcc_boosted_PN_med_HMass__428","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(10,1.399501);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(11,5.106352);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(12,4.074932);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(13,13.45685);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(14,13.20117);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(15,6.235757);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(16,1.335437);
   ZccHcc_boosted_PN_med_HMass__428->SetBinContent(17,1.031398);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(10,1.399501);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(11,2.585208);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(12,2.932032);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(13,5.425257);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(14,5.141861);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(15,2.81481);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(16,1.335437);
   ZccHcc_boosted_PN_med_HMass__428->SetBinError(17,1.031398);
   ZccHcc_boosted_PN_med_HMass__428->SetEntries(46);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__428->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__428->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__428->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__428->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__428->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__428->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__428->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__428->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__428->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__428->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__428->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__428->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__170->Modified();
   c1_n20->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__171 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__171->Draw();
   pad1_v2__171->cd();
   pad1_v2__171->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__171->SetFillColor(0);
   pad1_v2__171->SetBorderMode(0);
   pad1_v2__171->SetBorderSize(2);
   pad1_v2__171->SetFrameBorderMode(0);
   pad1_v2__171->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__429 = new TH1D("ZccHcc_boosted_PN_med_HMass__429","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(10,0.8506526);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(11,0.8461198);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(12,0.9868371);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(13,0.9369946);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(14,0.965663);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(15,0.9143998);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(16,1.089956);
   ZccHcc_boosted_PN_med_HMass__429->SetBinContent(17,1.007321);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(10,1.203004);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(11,0.6124971);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(12,0.9371513);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(13,0.5328715);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(14,0.4884337);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(15,0.5897548);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(16,1.54143);
   ZccHcc_boosted_PN_med_HMass__429->SetBinError(17,1.424568);
   ZccHcc_boosted_PN_med_HMass__429->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__429->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__429->SetEntries(7.237486);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__429->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__429->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__429->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__429->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__429->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__429->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__429->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__429->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__430 = new TH1D("ZccHcc_boosted_PN_med_HMass__430","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(10,1.142173);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(11,1.186163);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(12,1.017143);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(13,1.059508);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(14,1.04076);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(15,1.086597);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(16,0.8851778);
   ZccHcc_boosted_PN_med_HMass__430->SetBinContent(17,0.9702498);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(10,1.615276);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(11,0.8503051);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(12,1.011362);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(13,0.6030327);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(14,0.5551113);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(15,0.6951229);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(16,1.25183);
   ZccHcc_boosted_PN_med_HMass__430->SetBinError(17,1.37214);
   ZccHcc_boosted_PN_med_HMass__430->SetEntries(7.852239);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__430->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__430->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__430->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__430->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__430->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__430->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__430->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__430->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__430->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__171->Modified();
   c1_n20->cd();
   c1_n20->Modified();
   c1_n20->SetSelected(c1_n20);
}
