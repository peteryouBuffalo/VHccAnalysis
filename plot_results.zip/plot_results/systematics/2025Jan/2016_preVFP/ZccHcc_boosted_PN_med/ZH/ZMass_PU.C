#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_PU()
{
//=========Macro generated from canvas: c1_n28/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n28 = new TCanvas("c1_n28", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n28->SetHighLightColor(2);
   c1_n28->Range(0,0,1,1);
   c1_n28->SetFillColor(0);
   c1_n28->SetBorderMode(0);
   c1_n28->SetBorderSize(2);
   c1_n28->SetLeftMargin(0.15);
   c1_n28->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__186 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__186->Draw();
   pad1_v1__186->cd();
   pad1_v1__186->Range(-37.5,-2.49446,337.5,22.45014);
   pad1_v1__186->SetFillColor(0);
   pad1_v1__186->SetBorderMode(0);
   pad1_v1__186->SetBorderSize(2);
   pad1_v1__186->SetFrameBorderMode(0);
   pad1_v1__186->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__466 = new TH1D("ZccHcc_boosted_PN_med_ZMass__466","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(8,8.010736);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(9,17.8426);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(10,10.54566);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinContent(11,4.600439);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(8,3.332086);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(9,4.641019);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(10,4.649782);
   ZccHcc_boosted_PN_med_ZMass__466->SetBinError(11,3.796102);
   ZccHcc_boosted_PN_med_ZMass__466->SetMaximum(19.95568);
   ZccHcc_boosted_PN_med_ZMass__466->SetEntries(46);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__466->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__466->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__466->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__466->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__466->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__466->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__466->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__466->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__466->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__467 = new TH1D("ZccHcc_boosted_PN_med_ZMass__467","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(5,0.5140863);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(7,1.41043);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(8,6.983596);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(9,17.95568);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(10,9.640421);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinContent(11,4.246262);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(5,0.5140863);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(7,1.41043);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(8,2.890628);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(9,4.619527);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(10,4.370473);
   ZccHcc_boosted_PN_med_ZMass__467->SetBinError(11,3.370711);
   ZccHcc_boosted_PN_med_ZMass__467->SetEntries(46);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__467->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__467->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__467->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__467->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__467->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__467->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__467->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__468 = new TH1D("ZccHcc_boosted_PN_med_ZMass__468","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(5,1.142026);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(7,1.481883);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(8,9.11801);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(9,17.50594);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(10,11.69385);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinContent(11,4.899704);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(5,1.142026);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(7,1.481883);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(8,3.833801);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(9,4.650657);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(10,5.05732);
   ZccHcc_boosted_PN_med_ZMass__468->SetBinError(11,4.298588);
   ZccHcc_boosted_PN_med_ZMass__468->SetEntries(46);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__468->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__468->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__468->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__468->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__468->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__468->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__468->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","PU Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__186->Modified();
   c1_n28->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__187 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__187->Draw();
   pad1_v2__187->cd();
   pad1_v2__187->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__187->SetFillColor(0);
   pad1_v2__187->SetBorderMode(0);
   pad1_v2__187->SetBorderSize(2);
   pad1_v2__187->SetFrameBorderMode(0);
   pad1_v2__187->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__469 = new TH1D("ZccHcc_boosted_PN_med_ZMass__469","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(5,0.6684815);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(7,0.9636136);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(8,0.8717796);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(9,1.006337);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(10,0.9141601);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinContent(11,0.9230124);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(5,0.9453756);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(7,1.362755);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(8,0.5115673);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(9,0.3681688);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(10,0.5781184);
   ZccHcc_boosted_PN_med_ZMass__469->SetBinError(11,1.056847);
   ZccHcc_boosted_PN_med_ZMass__469->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__469->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__469->SetEntries(6.217237);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__469->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__469->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__469->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__469->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__469->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__469->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__470 = new TH1D("ZccHcc_boosted_PN_med_ZMass__470","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(5,1.48501);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(7,1.01243);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(8,1.138224);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(9,0.9811312);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(10,1.108878);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinContent(11,1.065051);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(5,2.100121);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(7,1.431793);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(8,0.6731966);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(9,0.3647813);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(10,0.6848575);
   ZccHcc_boosted_PN_med_ZMass__470->SetBinError(11,1.282745);
   ZccHcc_boosted_PN_med_ZMass__470->SetEntries(5.033578);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__470->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__470->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__470->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__470->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__470->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__187->Modified();
   c1_n28->cd();
   c1_n28->Modified();
   c1_n28->SetSelected(c1_n28);
}
