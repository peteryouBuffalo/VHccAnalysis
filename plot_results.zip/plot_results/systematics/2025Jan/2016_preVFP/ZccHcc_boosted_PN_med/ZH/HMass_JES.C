#ifdef __CLING__
#pragma cling optimize(0)
#endif
void HMass_JES()
{
//=========Macro generated from canvas: c1_n16/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n16 = new TCanvas("c1_n16", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n16->SetHighLightColor(2);
   c1_n16->Range(0,0,1,1);
   c1_n16->SetFillColor(0);
   c1_n16->SetBorderMode(0);
   c1_n16->SetBorderSize(2);
   c1_n16->SetLeftMargin(0.15);
   c1_n16->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__162 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__162->Draw();
   pad1_v1__162->cd();
   pad1_v1__162->Range(-37.5,-2.132319,337.5,19.19087);
   pad1_v1__162->SetFillColor(0);
   pad1_v1__162->SetBorderMode(0);
   pad1_v1__162->SetBorderSize(2);
   pad1_v1__162->SetFrameBorderMode(0);
   pad1_v1__162->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__406 = new TH1D("ZccHcc_boosted_PN_med_HMass__406","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(11,4.304931);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(12,4.006251);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(13,12.70104);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(14,12.68416);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(15,5.738796);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__406->SetBinContent(17,1.063023);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(11,2.184795);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(12,2.749297);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(13,5.102735);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(14,4.621875);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(15,2.601438);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__406->SetBinError(17,1.063023);
   ZccHcc_boosted_PN_med_HMass__406->SetMaximum(17.05855);
   ZccHcc_boosted_PN_med_HMass__406->SetEntries(46);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_HMass__406->SetFillColor(ci);
   ZccHcc_boosted_PN_med_HMass__406->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__406->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__406->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__406->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__406->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_HMass__406->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__406->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_HMass__406->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__406->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__406->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__406->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__406->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__406->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__407 = new TH1D("ZccHcc_boosted_PN_med_HMass__407","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(11,2.91386);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(12,4.637385);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(13,15.05855);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(14,9.927746);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(15,7.836108);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__407->SetBinContent(17,1.459529);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(10,1.225297);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(11,1.714147);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(12,3.164238);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(13,5.392798);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(14,4.172597);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(15,3.039143);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__407->SetBinError(17,1.459529);
   ZccHcc_boosted_PN_med_HMass__407->SetEntries(48);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__407->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__407->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__407->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__407->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__407->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__407->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__407->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__407->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__407->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__407->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__407->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__407->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__408 = new TH1D("ZccHcc_boosted_PN_med_HMass__408","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(10,1.670121);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(11,3.224226);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(12,5.219422);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(13,12.31914);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(14,8.158325);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(15,5.738796);
   ZccHcc_boosted_PN_med_HMass__408->SetBinContent(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(10,1.670121);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(11,1.898791);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(12,3.005065);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(13,5.061587);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(14,3.790746);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(15,2.601438);
   ZccHcc_boosted_PN_med_HMass__408->SetBinError(16,1.508666);
   ZccHcc_boosted_PN_med_HMass__408->SetEntries(42);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__408->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__408->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__408->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__408->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__408->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__408->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__408->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__408->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__408->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__408->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__408->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__408->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_HMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__162->Modified();
   c1_n16->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__163 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__163->Draw();
   pad1_v2__163->cd();
   pad1_v2__163->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__163->SetFillColor(0);
   pad1_v2__163->SetBorderMode(0);
   pad1_v2__163->SetBorderSize(2);
   pad1_v2__163->SetFrameBorderMode(0);
   pad1_v2__163->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_HMass__409 = new TH1D("ZccHcc_boosted_PN_med_HMass__409","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(10,1);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(11,0.6768656);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(12,1.157537);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(13,1.185615);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(14,0.7826885);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(15,1.365462);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(16,1);
   ZccHcc_boosted_PN_med_HMass__409->SetBinContent(17,1.372998);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(10,1.414214);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(11,0.5258823);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(12,1.120194);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(13,0.6380994);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(14,0.4353769);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(15,0.8146055);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(16,1.414214);
   ZccHcc_boosted_PN_med_HMass__409->SetBinError(17,1.941712);
   ZccHcc_boosted_PN_med_HMass__409->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_HMass__409->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_HMass__409->SetEntries(6.90702);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_HMass__409->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__409->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__409->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_HMass__409->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__409->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__409->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__409->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__409->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_HMass__410 = new TH1D("ZccHcc_boosted_PN_med_HMass__410","",30,0,300);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(10,1.363033);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(11,0.7489612);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(12,1.302819);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(13,0.9699319);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(14,0.6431901);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(15,1);
   ZccHcc_boosted_PN_med_HMass__410->SetBinContent(16,1);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(10,1.92762);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(11,0.5822592);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(12,1.167043);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(13,0.5573729);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(14,0.3797934);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(15,0.6410734);
   ZccHcc_boosted_PN_med_HMass__410->SetBinError(16,1.414214);
   ZccHcc_boosted_PN_med_HMass__410->SetEntries(5.963319);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_HMass__410->SetLineColor(ci);
   ZccHcc_boosted_PN_med_HMass__410->SetLineWidth(2);
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetTitle("M_{H} [GeV]");
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__410->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__410->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__410->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__410->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_HMass__410->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_HMass__410->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_HMass__410->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__163->Modified();
   c1_n16->cd();
   c1_n16->Modified();
   c1_n16->SetSelected(c1_n16);
}
