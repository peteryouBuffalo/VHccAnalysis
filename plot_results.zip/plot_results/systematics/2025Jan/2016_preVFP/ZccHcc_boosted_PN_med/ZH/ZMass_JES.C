#ifdef __CLING__
#pragma cling optimize(0)
#endif
void ZMass_JES()
{
//=========Macro generated from canvas: c1_n24/
//=========  (Tue Feb 25 14:55:47 2025) by ROOT version 6.30/03
   TCanvas *c1_n24 = new TCanvas("c1_n24", "",0,0,600,600);
   gStyle->SetOptStat(0);
   c1_n24->SetHighLightColor(2);
   c1_n24->Range(0,0,1,1);
   c1_n24->SetFillColor(0);
   c1_n24->SetBorderMode(0);
   c1_n24->SetBorderSize(2);
   c1_n24->SetLeftMargin(0.15);
   c1_n24->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: pad1_v1
   TPad *pad1_v1__178 = new TPad("pad1_v1", "pad1_v1",0,0.3,1,1);
   pad1_v1__178->Draw();
   pad1_v1__178->cd();
   pad1_v1__178->Range(-37.5,-2.480326,337.5,22.32293);
   pad1_v1__178->SetFillColor(0);
   pad1_v1__178->SetBorderMode(0);
   pad1_v1__178->SetBorderSize(2);
   pad1_v1__178->SetFrameBorderMode(0);
   pad1_v1__178->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__446 = new TH1D("ZccHcc_boosted_PN_med_ZMass__446","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(8,8.010736);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(9,17.8426);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(10,10.54566);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinContent(11,4.600439);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(8,3.332086);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(9,4.641019);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(10,4.649782);
   ZccHcc_boosted_PN_med_ZMass__446->SetBinError(11,3.796102);
   ZccHcc_boosted_PN_med_ZMass__446->SetMaximum(19.8426);
   ZccHcc_boosted_PN_med_ZMass__446->SetEntries(46);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#cccccc");
   ZccHcc_boosted_PN_med_ZMass__446->SetFillColor(ci);
   ZccHcc_boosted_PN_med_ZMass__446->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__446->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__446->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__446->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->GetXaxis()->SetTitleOffset(1.15);
   ZccHcc_boosted_PN_med_ZMass__446->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->GetYaxis()->SetTitle("Events/10.0 GeV");
   ZccHcc_boosted_PN_med_ZMass__446->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__446->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__446->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__447 = new TH1D("ZccHcc_boosted_PN_med_ZMass__447","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(8,9.63248);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(9,14.98935);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(10,12.4691);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(11,4.327394);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinContent(12,0.9160906);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(7,1.463688);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(8,3.714025);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(9,4.22287);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(10,4.83085);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(11,4.006348);
   ZccHcc_boosted_PN_med_ZMass__447->SetBinError(12,0.9160906);
   ZccHcc_boosted_PN_med_ZMass__447->SetEntries(48);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__447->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__447->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__447->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__447->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__447->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__447->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__447->Draw("same hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__448 = new TH1D("ZccHcc_boosted_PN_med_ZMass__448","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinContent(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinContent(8,6.647432);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinContent(9,16.7619);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinContent(10,11.58716);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinContent(11,2.073174);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinError(5,0.7690359);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinError(8,3.0658);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinError(9,4.513439);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinError(10,4.815031);
   ZccHcc_boosted_PN_med_ZMass__448->SetBinError(11,3.303316);
   ZccHcc_boosted_PN_med_ZMass__448->SetEntries(42);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__448->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__448->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__448->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__448->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__448->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__448->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__448->Draw("same hist");
   
   TLegend *leg = new TLegend(0.53,0.7,0.89,0.87,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.035);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(2);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","Nominal","F");

   ci = TColor::GetColor("#cccccc");
   entry->SetFillColor(ci);
   entry->SetFillStyle(1001);
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Up","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#0000ff");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   entry=leg->AddEntry("ZccHcc_boosted_PN_med_ZMass","JES Down","F");
   entry->SetFillStyle(1001);

   ci = TColor::GetColor("#ff0000");
   entry->SetLineColor(ci);
   entry->SetLineStyle(1);
   entry->SetLineWidth(2);
   entry->SetMarkerColor(1);
   entry->SetMarkerStyle(21);
   entry->SetMarkerSize(1);
   entry->SetTextFont(42);
   leg->Draw();
   pad1_v1__178->Modified();
   c1_n24->cd();
   TLatex *   tex = new TLatex(0.5,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.025);
   tex->SetLineWidth(2);
   tex->Draw();
  
// ------------>Primitives in pad: pad1_v2
   TPad *pad1_v2__179 = new TPad("pad1_v2", "pad1_v2",0,0.1,1,0.3);
   pad1_v2__179->Draw();
   pad1_v2__179->cd();
   pad1_v2__179->Range(-37.5,0.75,337.5,1.25);
   pad1_v2__179->SetFillColor(0);
   pad1_v2__179->SetBorderMode(0);
   pad1_v2__179->SetBorderSize(2);
   pad1_v2__179->SetFrameBorderMode(0);
   pad1_v2__179->SetFrameBorderMode(0);
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__449 = new TH1D("ZccHcc_boosted_PN_med_ZMass__449","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(7,1);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(8,1.202446);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(9,0.8400876);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(10,1.182392);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinContent(11,0.940648);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(7,1.414214);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(8,0.6819928);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(9,0.3221223);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(10,0.6940028);
   ZccHcc_boosted_PN_med_ZMass__449->SetBinError(11,1.166561);
   ZccHcc_boosted_PN_med_ZMass__449->SetMinimum(0.8);
   ZccHcc_boosted_PN_med_ZMass__449->SetMaximum(1.2);
   ZccHcc_boosted_PN_med_ZMass__449->SetEntries(5.929189);

   ci = TColor::GetColor("#0000ff");
   ZccHcc_boosted_PN_med_ZMass__449->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__449->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetRange(1,30);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetLabelSize(0.1);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__449->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetTitle("#frac{Up/Down}{Nominal}");
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->CenterTitle(true);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetLabelSize(0.09);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetTitleSize(0.12);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetTitleOffset(0.35);
   ZccHcc_boosted_PN_med_ZMass__449->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__449->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__449->Draw("hist");
   
   TH1D *ZccHcc_boosted_PN_med_ZMass__450 = new TH1D("ZccHcc_boosted_PN_med_ZMass__450","",30,0,300);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinContent(5,1);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinContent(8,0.8298153);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinContent(9,0.9394312);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinContent(10,1.098761);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinContent(11,0.4506469);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinError(5,1.414214);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinError(8,0.5153698);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinError(9,0.3517059);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinError(10,0.6657172);
   ZccHcc_boosted_PN_med_ZMass__450->SetBinError(11,0.8086184);
   ZccHcc_boosted_PN_med_ZMass__450->SetEntries(5.349662);

   ci = TColor::GetColor("#ff0000");
   ZccHcc_boosted_PN_med_ZMass__450->SetLineColor(ci);
   ZccHcc_boosted_PN_med_ZMass__450->SetLineWidth(2);
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetTitle("M_{Z} [GeV]");
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetRange(1,300);
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetTitleSize(0.13);
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__450->GetXaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->GetYaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->GetYaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->GetZaxis()->SetLabelFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->GetZaxis()->SetTitleOffset(1);
   ZccHcc_boosted_PN_med_ZMass__450->GetZaxis()->SetTitleFont(42);
   ZccHcc_boosted_PN_med_ZMass__450->Draw("same hist");
   TLine *line = new TLine(0,1,300,1);
   line->SetLineStyle(2);
   line->Draw();
   pad1_v2__179->Modified();
   c1_n24->cd();
   c1_n24->Modified();
   c1_n24->SetSelected(c1_n24);
}
